open Command

let rmlc = A"/Users/ccpasteur/Desktop/rml-these/compiler/rpmlc.native";;
let rmldep = A "/Users/ccpasteur/Desktop/rml-these/tools/rpmldep/rpmldep.native";;

let rpmllib_dir = "/Users/ccpasteur/Desktop/rml-these/interpreter/_build"
let mlmpilib_dir = "/Users/ccpasteur/Desktop/rml-these/mpi"

let mpicc = "mpicc"
