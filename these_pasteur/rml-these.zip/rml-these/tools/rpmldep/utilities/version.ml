(* version of the compiler *)
let version = "0.2"
let standard_lib = "/Users/ccpasteur/Documents/work/git/rml/lib"

