#include <caml/mlvalues.h>
#include <caml/custom.h>
#include <caml/intext.h>
#include <caml/memory.h>
#include <mpi.h>

#define Local_value_val(v) ((char*) Data_custom_val(v))

#define VALUE_FIELD 0
#define ID_FIELD 1
#define VALID_FIELD 2
#define BLOCK_SIZE (3*sizeof(value))

value allocate_func;

void my_serialize(value v, uintnat * wsize_32 /*size in bytes*/,
                     uintnat * wsize_64 /*size in bytes*/)
{
  caml_serialize_int_4(Int_val(Field(v, ID_FIELD)));
  *wsize_32 = BLOCK_SIZE;
  *wsize_64 = BLOCK_SIZE;
}

unsigned long my_deserialize(void* dst)
{
  int32 id = caml_deserialize_sint_4();
  ;


  return BLOCK_SIZE;
}


static struct custom_operations local_value_ops = {
 identifier: "rml.local_value",
 finalize:  custom_finalize_default,
 compare:     custom_compare_default,
 hash:        custom_hash_default,
 serialize:   my_serialize,
 deserialize: my_deserialize
};

void init_locality_token()
{
  caml_register_custom_operations(&token_ops);
}

value mk_local_value(value v, value id)
{
  CAMLparam1(v);
  CAMLlocal1(res);

  res = caml_alloc_custom(&local_value_ops, 3*sizeof(value), 0, 1);

  Store_field(res, VALUE_FIELD, id);
  Store_field(res, ID_FIELD, v);
  Store_field(res, VALID_FIELD, Val_bool(1));

  CAMLreturn (res);
}

value get(value v)
{
  CAMLparam1(v);
  CAMLlocal1(res, tmp);

  bool is_valid = Bool_val (Field(v, VALID_FIELD));
  if(is_valid)
    res = Field(v, VALUE_FIELD);
  else {
    tmp = caml_callback(allocate_func, Val_unit);
    Store_field(v, VALUE_FIELD, tmp);
  }

  CAMLreturn (res);
}

value set_allocate_func(value f)
{
  CAMLparam1(f);

  allocate_func = f;
  caml_register_generational_global_root(&f);

  CAMLreturn (Val_unit);
}
