
external init : int -> 'a -> unit = "caml_mpi_init_local_ref"
external get : int -> 'a = "caml_mpi_get_local_ref"
