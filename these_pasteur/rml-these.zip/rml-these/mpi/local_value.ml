type ('id, 'a) local_value

val mk_value : 'id -> 'a -> ('id, 'a) local_value
val set_local_fetcher : ('id -> 'a) -> unit
val get : ('id, 'a) local_value -> 'a
