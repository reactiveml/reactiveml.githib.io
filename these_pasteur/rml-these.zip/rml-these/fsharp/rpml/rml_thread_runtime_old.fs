module Rml_thread_runtime

open System
open System.Threading
open System.Collections.Concurrent
open Types
open Seq_runtime

module Join = 
  type join_point = int ref

  let new_join_point nb = ref nb
  let incr (j:join_point) (nb:int) =
    Interlocked.Add (j, nb)
  let decr (j:join_point) =
    Interlocked.Decrement j 
    
module Step =
  type 'a t = 'a -> unit    
  
module E = Event
module D =
  type next = ConcurrentStack<unit Step.t>
  type current = ConcurrentBag<unit Step.t>
  type waiting_list = ConcurrentStack<unit Step.t>

  let dummy_step _ = ()
  let tmp = new ThreadLocal<unit Step.t ref> (fun () -> ref dummy_step)

  let mk_current () = new current()
  let add_current p (c:current) =
    c.Add p
  let add_current_list pl (c:current) =
    List.iter c.Add pl
  let add_current_waiting_list (w:waiting_list) (c:current) =
    Array.iter c.Add (w.ToArray ());
    w.Clear ()
  let add_current_next (next:next) (c:current) =
    Array.iter c.Add (next.ToArray ());
    next.Clear ()

  let current_length (c:current) =
    c.Count

  let take_current (c:current) = 
    if c.TryTake tmp.Value then
      Some !tmp.Value
    else
      None

  let mk_waiting_list () = new waiting_list()
  let add_waiting p (w:waiting_list) =
    w.Push p
  let take_all (w:waiting_list) =
    let a = w.ToArray () in
    w.Clear ();
    List.ofArray a
  let waiting_length (w:waiting_list) =
    w.Count

  let mk_next () = new next ()
  let add_next p (next:next) =
    next.Push p
  let add_next_next (n1:next) (n2:next) =
    n2.PushRange (n1.ToArray ());
    n1.Clear ()
  let clear_next (next:next) =
    next.Clear ()
  let is_empty_next (next:next) =
    next.IsEmpty
    
type 'a step = 'a -> unit

type control_tree =
    { kind: (unit step, clock) control_type;
      mutable alive: bool;
      mutable susp: bool;
      mutable cond: (unit -> bool);
      mutable cond_v : bool;
      mutable children: control_tree list;
      next: D.next;
      next_control : D.next; (* contains control processes that should not be
                              taken into account to see if macro step is done *)
      mutable last_activation : (clock_domain * E.clock_index) list;
      mutable instance : int;
      lock: ReaderWriterLockSlim;
    }

and clock_domain =
    { cd_current : D.current;
      cd_eoi : bool ref; (* is it the eoi of this clock *)
      cd_weoi : D.waiting_list; (* processes waiting for eoi *)
      cd_next_instant : D.waiting_list; (* processes waiting for the move to next instant *)
      cd_wake_up : ConcurrentStack<D.waiting_list>;
      (* waiting lists to wake up at the end of the instant*)
      cd_clock : E.clock;
      mutable cd_top : control_tree;
      mutable cd_parent : clock_domain option;
      mutable cd_counter : int;
    }

and clock = clock_domain
and region = clock

type ('a, 'b) event = ('a,'b) E.t * clock_domain * D.waiting_list * D.waiting_list
type event_cfg =
  | Cevent of (bool -> bool) * clock_domain * D.waiting_list * D.waiting_list
  (* status, cd, wa, wp*)
  | Cand of event_cfg * event_cfg
  | Cor of event_cfg * event_cfg

let unit_value = ()

let top_clock_ref = ref (None:clock_domain option)
let get_top_clock_domain () =
  match !top_clock_ref with
    | None -> raise Types.RML
    | Some cd -> cd

(**************************************)
(* control tree                       *)
(**************************************)

let new_ctrl_cond cond kind =
  { kind = kind;
    alive = true;
    susp = false;
    children = [];
    cond = cond;
    cond_v = false;
    next = D.mk_next ();
    next_control = D.mk_next ();
    last_activation = [];
    instance = 0;
    lock = new ReaderWriterLockSlim() }
let new_ctrl kind = new_ctrl_cond (fun () -> false) kind

(* tuer un arbre p *)
let rec set_kill p =
  p.lock.EnterWriteLock ();
  p.alive <- true; (* set to true, to show that the node is no longer attached to its parent
                   and needs to be reattaced if the node is reused *)
  p.susp <- false;
  let children = p.children in
  p.children <- [];
  p.instance <- p.instance + 1;
  D.clear_next p.next;
  p.lock.ExitWriteLock ();
  List.iter set_kill children

let rec save_clock_state cd =
  let l = match cd.cd_parent with
    | None -> []
    | Some cd -> save_clock_state cd
  in
    (cd, E.get cd.cd_clock)::l

let start_ctrl cd ctrl new_ctrl =
  new_ctrl.last_activation <- save_clock_state cd;
  if new_ctrl.alive then (
    ctrl.lock.EnterWriteLock ();
    ctrl.children <- new_ctrl :: ctrl.children;
    ctrl.lock.ExitWriteLock ()
  ) else (* reset new_ctrl *)
    (new_ctrl.alive <- true;
     new_ctrl.susp <- false;
     D.clear_next new_ctrl.next)

let end_ctrl new_ctrl f_k x =
  set_kill new_ctrl;
  new_ctrl.lock.EnterWriteLock ();
  new_ctrl.alive <- false;
  new_ctrl.lock.ExitWriteLock ();
  f_k x
 
 
 (* calculer le nouvel etat de l'arbre de control *)
(* et deplacer dans la liste current les processus qui sont dans  *)
(* les listes next *)
let eval_control_and_next_to_current cd =
  let rec eval pere p active =
    if p.alive then
      match p.kind with
      | Clock_domain _ -> true
      | Kill f_k ->
          if p.cond_v
          then
            (D.add_next f_k pere.next;
             set_kill p;
             false)
          else
            (p.children <- eval_children p p.children active;
             if active then next_to_current cd p
             else next_to_father pere p;
             true)
      | Kill_handler handler ->
          if p.cond_v
          then
            false
          else
            (p.children <- eval_children p p.children active;
             if active then next_to_current cd p
             else next_to_father pere p;
             true)
      | Susp ->
          let pre_susp = p.susp in
          if p.cond_v then p.susp <- not pre_susp;
          let active = active && not p.susp in
          if pre_susp
          then
            (if active then next_to_current cd p;
             true)
          else
            (p.children <- eval_children p p.children active;
             if active then next_to_current cd p
             else if not p.susp then next_to_father pere p;
             true)
      | When ->
          if p.susp
          then true
          else
            (p.susp <- true;
             p.children <- eval_children p p.children false;
             true)
    else
      (set_kill p;
       false)

  and eval_children p nodes active =
    List.filter (fun node -> eval p node active) nodes

  and next_to_current ck node =
    node.last_activation <- save_clock_state ck;
    D.add_current_next node.next ck.cd_current;
    D.add_current_next node.next_control ck.cd_current;
  and next_to_father pere node = ()
   (* D.add_next_next node.next pere.next;
    D.add_next_next node.next_control pere.next_control
    *)
    (* TODO: ne marche plus si on veut que last_activation soit correct *)
  in
    cd.cd_top.children <- eval_children cd.cd_top cd.cd_top.children true;
    next_to_current cd cd.cd_top
 
 
 (* deplacer dans la liste current les processus qui sont dans  *)
(* les listes next *)
let rec next_to_current cd p =
  p.lock.EnterUpgradeableReadLock ();
  if p.alive && not p.susp then
    (D.add_current_next p.next cd.cd_current;
     D.add_current_next p.next_control cd.cd_current;
     p.lock.EnterWriteLock ();
     p.last_activation <- save_clock_state cd;
     p.lock.ExitWriteLock ();
     List.iter (next_to_current cd) p.children);
  p.lock.ExitUpgradeableReadLock ()  

(** Evaluates the condition of control nodes. This can be called several
    times for a same control node, when doing the eoi of several clocks.
    We can keep the last condition (if it was true for the eoi of the fast clock,
    it is also true for the eoi of the slow clock), but we have to make sure
    to fire the handler only once. *)
let eoi_control ctrl =
  let rec _eoi_control pere ctrl =
    if ctrl.alive then (
      ctrl.cond_v <- ctrl.cond ();
      (match ctrl.kind with
        | Kill_handler handler ->
            if ctrl.cond_v then (
              D.add_next (handler()) pere.next;
              set_kill ctrl
            )
        | _ -> ());
      List.iter (_eoi_control ctrl) ctrl.children;
    )
  in
    List.iter (_eoi_control ctrl) ctrl.children

let wake_up_ctrl new_ctrl cd =
  new_ctrl.lock.EnterWriteLock ();
  new_ctrl.susp <- false;
  next_to_current cd new_ctrl;
  new_ctrl.lock.ExitWriteLock ()

let is_active ctrl =
  ctrl.alive && not ctrl.susp

let mk_clock_domain parent =
  let cd = 
    { cd_current = D.mk_current ();
      cd_eoi = ref false;
      cd_weoi = D.mk_waiting_list ();
      cd_next_instant = D.mk_waiting_list ();
      cd_wake_up = new ConcurrentStack<D.waiting_list>();
      cd_clock = E.init_clock ();
      cd_top = new_ctrl Susp;
      cd_parent = parent;
      cd_counter = 0; } 
  in
  cd.cd_top <- new_ctrl (Clock_domain cd);
  cd.cd_top.last_activation <- save_clock_state cd;
  cd

let finalize_top_clock_domain _ =
  ()
let init () =
  match !top_clock_ref with
    | None ->
        (* create top clock domain *)
        let cd = mk_clock_domain None in
        top_clock_ref := Some cd
    | Some _ -> () (* init already done *)

let is_eoi cd = !(cd.cd_eoi)
let control_tree cd = cd.cd_top
let clock cd = cd
(* let rec top_clock cd = match cd.cd_parent with
  | None -> cd
  | Some cd -> top_clock cd *)
let top_clock () = match !top_clock_ref with
  | None -> raise Types.RML
  | Some ck -> ck

let add_weoi cd p =
  D.add_waiting p cd.cd_weoi
let add_weoi_waiting_list cd w =
  cd.cd_wake_up.Push w
  
(* debloquer les processus en attent d'un evt *)
let wake_up ck w =
  D.add_current_waiting_list w ck.cd_current

let wake_up_all ck =
  Array.iter  (fun w -> D.add_current_waiting_list w ck.cd_current) (ck.cd_wake_up.ToArray ())
  ck.cd_wake_up.Clear ()

(* ------------------------------------------------------------------------ *)

module Event =
  struct
    let new_evt_expr cd _ kind _default combine =
      (E.create cd.cd_clock kind _default combine, cd,
       D.mk_waiting_list (), D.mk_waiting_list ())

    let new_evt _ cd r kind _default (combine : 'a -> 'b -> 'b) reset k =
      let evt = new_evt_expr cd r kind _default combine in
      let k =
     (* create a callback to reset the signal at each eoi of the reset *)
        match reset with
          | None -> k
          | Some rck ->
            fun evt _ ->
              let (n, _, _, _) = evt in
              let rec reset_evt () =
                E.reset n;
                add_weoi rck reset_evt
              in
              add_weoi rck reset_evt;
              k evt ()
      in
      k evt

    let new_evt_global kind _default combine =
      let cd = get_top_clock_domain () in
      new_evt_expr cd cd kind _default combine

    let status_only_at_eoi only_at_eoi (n,sig_cd,_,_) =
      E.status n && (not only_at_eoi || !(sig_cd.cd_eoi))
    let status ev = status_only_at_eoi false ev

    let value (n,_,_,_) =
      if E.status n then
        E.value n
      else
        raise Types.RML

    let one (n,_,_,_) = E.one n
    let pre_status (n,_,_,_) = E.pre_status n
    let pre_value (n,_,_,_) = E.pre_value n
    let last (n,_,_,_) = E.last n
    let _default (n,_,_,_) = E._default n
    let clock (_,sig_cd,_,_) = sig_cd

    let region_of_clock cd = cd

    let emit (n,sig_cd,wa,wp) v =
      Monitor.Enter n;
      E.emit n v;
      D.add_current_waiting_list wa sig_cd.cd_current;
      D.add_current_waiting_list wp sig_cd.cd_current;
      Monitor.Exit n

    let cfg_present ((n,sig_cd,wa,wp) as evt) =
      Cevent ((fun eoi -> status_only_at_eoi eoi evt), sig_cd, wa, wp)
    let cfg_or ev1 ev2 =
      Cor (ev1, ev2)
    let cfg_and ev1 ev2 =
      Cand (ev1, ev2)

    let cfg_status_only_at_eoi only_at_eoi evt_cfg =
      let rec status k = match k with
        | Cevent (c, _, _, _) -> c only_at_eoi
        | Cand (cfg1, cfg2) -> status cfg1 && status cfg2
        | Cor (cfg1, cfg2) -> status cfg1 || status cfg2
      in
      status evt_cfg
    let cfg_status evt_cfg = cfg_status_only_at_eoi false evt_cfg

    let cfg_events evt_cfg long_wait =
      let rec events k = match k with
        | Cevent (_, cd, wa, wp) -> [(if long_wait then wa else wp), cd]
        | Cand (cfg1, cfg2) | Cor (cfg1, cfg2) ->
          List.rev_append (events cfg1) (events cfg2)
      in
      events evt_cfg
  end

 
exception Wait_again

let on_current_instant cd f = D.add_current f cd.cd_current
let on_current_instant_list cd fl = D.add_current_list fl cd.cd_current
let on_next_instant_kind kind ctrl f =
  match kind with
    | Strong -> D.add_next f ctrl.next
    | Weak -> D.add_next f ctrl.next_control
let on_next_instant ctrl f = on_next_instant_kind Strong ctrl f

(** [on_eoi cd f] executes 'f ()' during the eoi of cd. *)
let on_eoi cd f =
  if is_eoi cd then
    f unit_value
  else
    add_weoi cd f

(** [on_event_or_next evt f_w cd ctrl f_next] executes 'f_w ()' if
  evt is emitted before the end of instant of cd.
  Otherwise, executes 'f_next ()' during the next instant. *)
let _on_event_or_next ((n,_,_,w) as evt) f_w cd ctrl f_next =
  let act _ =
    if is_eoi cd then
      (*eoi was reached, launch fallback*)
      D.add_next f_next ctrl.next
    else
      (* signal activated *)
      f_w ()
  in
  Monitor.Enter n;
  if Event.status evt then
    Monitor.Exit n
    f_w ()
  else
    D.add_waiting act w;
    Monitor.Exit n;
    add_weoi_waiting_list cd w

(** [on_event_cfg_or_next evt_cfg f_w v_w cd ctrl f_next] executes 'f_w ()' if
  evt_cfg is true before the end of instant of cd.
  Otherwise, executes 'f_next ()' during the next instant. *)
let on_event_cfg_or_next evt_cfg f_w cd ctrl f_next = () (*TODO*)

let has_been_active ctrl sig_cd =
  let rec check_last_activation l = match l with
    | [] -> false
    | (cd, ck)::l ->
        if cd == sig_cd then (
          ck = (E.get sig_cd.cd_clock)
        ) else
          check_last_activation l
  in
    check_last_activation ctrl.last_activation

(** [on_event evt ctrl f] executes 'f ()' if evt is emitted and
    ctrl is active in the same step.
    It waits for the next activation of w otherwise,
    or if the call raises Wait_again *)
let _on_event n w sig_cd ctrl f =
  let instance = ctrl.instance in
  let rec self _ =
    if ctrl.instance = instance then (
      if has_been_active ctrl sig_cd then
        (*ctrl is activated, run continuation*)
        (try
            f ()
          with
            | Wait_again -> 
                Monitor.Enter n;
                D.add_waiting self w;
                Monitor.Exit n)
      else ((*ctrl is not active, wait end of instant*)
        let is_fired = ref false in
        D.add_next (ctrl_await is_fired) ctrl.next_control;
        add_weoi sig_cd (eoi_await is_fired)
      )
    )
  and eoi_await is_fired _ =
    if not !is_fired then
        (*ctrl was not activated, await the signal again *)
      (is_fired := true;
       D.add_waiting self w)
  and ctrl_await is_fired _ =
    if not !is_fired then
      (* ctrl was activated, signal is present*)
      (try
         is_fired := true; f ()
       with
         | Wait_again -> D.add_waiting self w)
  in
  D.add_waiting self w

let on_event (n,sig_cd,w,_) ctrl f =
  Monitor.Enter n;
  if E.status n then
    (try
       Monitor.Exit n; f ()
     with
       | Wait_again -> _on_event n w sig_cd ctrl f; Monitor.Exit n)
  else
    _on_event n w sig_cd ctrl f;
    Monitor.Exit n

(** [on_event_cfg evt_cfg ctrl f ()] executes 'f ()' if evt_cfg is true and
    ctrl is active in the same step.
    It waits for the next activation of evt_cfg otherwise,
    or if the call raises Wait_again *)
let on_event_cfg evt_cfg ctrl f = () (*TODO*)
    
    
(* Control structures *)
let create_control kind body f_k ctrl cd =
  let new_ctrl = new_ctrl kind in
  let f = body (end_ctrl new_ctrl f_k) new_ctrl in
  match kind with
    | When ->
        fun evt other_cond ->
          let rec when_act _ =
            wake_up_ctrl new_ctrl cd;
            on_next_instant ctrl f_when
          and f_when _ =
            on_event evt ctrl when_act
          in
          new_ctrl.cond <- (fun () -> Event.status evt);
          fun () ->
            start_ctrl cd ctrl new_ctrl;
            new_ctrl.susp <- true;
            on_next_instant new_ctrl f;
            f_when ()
    | _ ->
        fun evt other_cond ->
          new_ctrl.cond <-
            (fun () -> Event.status_only_at_eoi true evt && other_cond (Event.value evt));
          fun () ->
            start_ctrl cd ctrl new_ctrl;
            f ()

let create_control_evt_conf kind body f_k ctrl cd =
  let new_ctrl = new_ctrl kind in
  let f = body (end_ctrl new_ctrl f_k) new_ctrl in
  fun evt_cfg ->
    new_ctrl.cond <- (fun () -> Event.cfg_status_only_at_eoi true evt_cfg);
    fun () ->
      start_ctrl cd ctrl new_ctrl;
      f ()


let rec schedule cd =
  match D.take_current cd.cd_current with
  | Some f -> f (); schedule cd
  | None -> ()

let eoi cd =
  cd.cd_eoi := true;
  eoi_control cd.cd_top;
  wake_up cd cd.cd_weoi;
  wake_up_all cd;
  schedule cd

let next_instant cd =
  E.next cd.cd_clock;
  (* next instant of child clock domains *)
  wake_up cd cd.cd_next_instant;
  schedule cd;
  (* next instant of this clock domain *)
  eval_control_and_next_to_current cd;
  cd.cd_eoi := false

let new_clock_domain cd ctrl p _ period f_k =
  Printf.eprintf "The backend does not support clock domains\n";
  raise Types.RML

(* the react function *)
let react cd =
  schedule cd;
  eoi cd;
  next_instant cd

(* Fake functions *)
let start_slave _ = ()
let is_master _ = true
    

 