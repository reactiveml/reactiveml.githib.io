---- Dependances -----
- OCaml >= 3.12
- ocamlfind
- MPI avec support de MPI_THREAD_MULTIPLE pour le moteur d'execution distribue


---- Contenu ---------

- compiler/ : sources du compilateur
- exemples/: exemples du manuscrit
- fsharp/: sources du moteur d'execution F#
- interpreter/ : sources des moteurs d'execution OCaml
- lib/ : bibliotheque standard
- mpi/ : bibliotheque d'interface avec MPI
- m4/ : script pour configuration
- tools/rpmldep/ : sources de l'outil rpmldep pour calculer les dependances (comme ocamldep)
- tools/rpmlbuild/ : sources de l'outil rpmbuild pour construire des programmes (comme ocamlbuild)
- toplevel-alt/ : sources du toplevel et de TryRML

---- Installation -------

Il faut d'abord appeler le script configure qui prend les options suivantes:
   - -enable-mpi : pour activer le moteur d'execution distribue. Il faut alors avoir une installation de
  MPI permettant l'utilisation de threads. C'est par exemple le cas de MPICH.
   - -enable-local-stdlib : Cette option permet de ne pas avoir a installer le compilateur et de l'utiliser
  directement dans le dossier source.

On lance donc par exemple pour une utilisation locale:
   > ./configure --enable-local-stdlib --enable-mpi
ou bien pour installer le compilateur dans /opt/local
   > ./configure --enable-mpi --prefix=/opt/local

On lance ensuite la compilation avec la commande habituelle:
   > make
Il faut ensuite installer le compilateur si jamais l'option '--enable-local-stdlib' n'a pas ete donnee
au script configure:
   > make install

Pour construire le toplevel, il faut entrer la commande:
     > make toplevel
Elle genere le fichier toplevel-alt/rmltop_alt qui est une version executable du toplevel et une page toplevel-alt/js/index.html contenant la version javascript du toplevel. Il faut lancer le toplevel par:
     > ./rmltop_alt -I ../interpreter/_build
si jamais on a utilise l'option '-enable-local-stdlib'.

--- Exemples ---------

Pour compiler les differents exemples, il suffit de faire:
     > cd exemples
     > make

--- Options du compilateur rpmlc ----

rpmlc <options> foo.{rml,rmli,mli}

Options principales:
        -v : Affiche la version
        -where : Affiche l'emplacement de la bibliotheque standard
        -c : Compile sans generer de fichier .ml
        -I <dir> : Ajoute un dossier de recherche
        -s <main> : Execute le processus main
        -i : Affiche les types
        -runtime <runtime> : Choix du moteur d'execution parmi: Lco (defaut), Lco_mpi, Fsharp_Lco,
        Fsharp_LcoRmlThread, Fsharp_LcoThread, Rpml2rml
        -no-clocking : Desactive le calcul d'horloges
        -row-clocking: Utilise le calcul d'horloge avec rangees
        -no_reactivity: Desactive l'analyse de reactivite
        -dreactivity : Affiche les comportements calcules par l'analyse de reactivite (si l'option
        '-i' est activee)

--- Options de rpmlbuild -----

rpmlbuild est une extension de ocamlbuild dont elle reprend les principes. Pour compiler un
programme dont le fichier principal est foo.rml, il suffit donc de taper:
          > rpmlbuild foo.rml.native

On utilise des tags, donnes soit sur la liste de commande avec l'option -tag, soit dans un fichier
_tags, pour choisir les optins de compilation. Par exemple:
lco, lco_mpi: choix du moteur d'execution
no_clocking, row_clocking: Configuration du calcul d'horloges

--- Options des programmes generes -----

Options generales:
        -n <nombre>  : Nombre d'instants maximum a executer
        -sampling <flottant> : Frequence d'echantillonage (en secondes)
        -bench : Affiche le temps d'execution du programme (en millisecondes)
        -debug : Affiche des informations de debug

Backend distribue:
        -load-balancer <name> : Choix de l'equilibreur de charge

