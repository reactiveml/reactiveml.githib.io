(**********************************************************************)
(*                                                                    *)
(*                           ReactiveML                               *)
(*                    http://reactiveML.org                           *)
(*                    http://rml.inria.fr                             *)
(*                                                                    *)
(*                          Louis Mandel                              *)
(*                                                                    *)
(*  Copyright 2002, 2007 Louis Mandel.  All rights reserved.          *)
(*  This file is distributed under the terms of the Q Public License  *)
(*  version 1.0.                                                      *)
(*                                                                    *)
(*  ReactiveML has been done in the following labs:                   *)
(*  - theme SPI, Laboratoire d'Informatique de Paris 6 (2002-2005)    *)
(*  - Verimag, CNRS Grenoble (2005-2006)                              *)
(*  - projet Moscova, INRIA Rocquencourt (2006-2007)                  *)
(*                                                                    *)
(**********************************************************************)

(* file: typing_errors.ml *)

(* Warning: *)
(* This file has been done from CamlLight, Lucid Synchrone and the book *)
(* "Le langage Caml" Pierre Weis Xavier Leroy *)

(* created: 2004-05-13  *)
(* author: Louis Mandel *)

(* $Id$ *)

(* Printing of error messages during typing *)

open Asttypes
open Misc
open Clocks
open Clocks_utils
open Reac

(* clock clash *)
let expr_wrong_clock_err exp actual_ty expected_ty =
  Format.eprintf
    "%aThis expression has clock %a,\n\
    but is used with clock %a.@."
    Location.print exp.e_loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let patt_wrong_clock_err patt actual_ty expected_ty =
  Format.eprintf
    "%aThis pattern has clock %a,\n\
    but is used with clock %a.@."
    Location.print patt.patt_loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let event_wrong_clock_err evt actual_ty expected_ty =
  Format.eprintf
    "The event %s has clock %a,\n\
    but is used with clock %a.@."
    (Ident.name evt)
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let emit_wrong_clock_err loc actual_ty expected_ty =
  Format.eprintf
    "%aThe emitted value has clock %a,\n\
    but is used with clock %a.@."
    Location.print loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let update_wrong_clock_err loc actual_ty expected_ty =
  Format.eprintf
    "%aThe assigned value has clock %a,\n\
    but is used with clock %a.@."
    Location.print loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let emit_wrong_clock_escape_err loc s actual_ty =
  Format.eprintf
    "%aThe emitted value has clock %a,\n\
    and would thus escape its scope '%s'.@."
    Location.print loc
    Clocks_printer.output actual_ty
    s;
  raise Error

let update_wrong_clock_escape_err loc s actual_ty =
  Format.eprintf
    "%aThe assigned value has clock %a,\n\
    and would thus escape its scope %s.@."
    Location.print loc
    Clocks_printer.output actual_ty
    s;
  raise Error

let run_wrong_clock_err loc actual_ty expected_ty =
  Format.eprintf
    "%aThis expression has clock %a,\n\
    but is used with clock %a.@."
    Location.print loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let var_wrong_clock_err loc actual_ty expected_ty =
  Format.eprintf
    "%aThis pattern has clock %a,\n\
    but is used with clock %a.@."
    Location.print loc
    Clocks_printer.output actual_ty
    Clocks_printer.output expected_ty;
  raise Error

let expr_wrong_clock_escape_err exp s actual_ck =
  Format.eprintf
           "%aThe clock of this expression, that is,\n\
            %a\n\
            depends on %s which escape its scope.@."
    Location.print exp.e_loc
    Clocks_printer.output actual_ck
    s;
  raise Error

let run_wrong_clock_escape_err loc s actual_ck =
  Format.eprintf
           "%aThe clock of this expression, that is,\n\
            %a\n\
            depends on %s which escape its scope.@."
    Location.print loc
    Clocks_printer.output actual_ck
    s;
  raise Error

let immediate_dep_escape_err loc s =
  Format.eprintf
           "%aThis immediate dependency would make '%s' escape its scope.@."
    Location.print loc
    s;
  raise Error

let application_of_non_function_err exp ty =
  begin try
    let _ = filter_arrow ty in
    Format.eprintf
      "%aThis function is applied to too many arguments.@."
      Location.print exp.e_loc
  with Unify ->
    Format.eprintf
      "%aThis expression is not a function, it cannot be applied (Found type: %a).@."
      Location.print exp.e_loc
      Clocks_printer.output ty
  end;
  raise Error

let non_event_err exp =
  Format.eprintf
    "%aThis expression is not an event.@."
    Location.print exp.e_loc;
  raise Error

let event_bad_clock_err exp ty sck =
  Format.eprintf
    "%aThis expression is not an event of clock '%a' (found '%a').@."
    Location.print exp.e_loc
    Clocks_printer.output_carrier sck
    Clocks_printer.output ty;
  raise Error

let non_event_err2 conf =
  Format.eprintf
    "%aThis expression is not an event.@."
    Location.print conf.conf_loc;
  raise Error

let non_memory_err exp =
  Format.eprintf
    "%aThis expression is not a memory.@."
    Location.print exp.e_loc;
  raise Error

let non_clock_err loc =
  Format.eprintf
    "%aThis expression is not a clock.@."
    Location.print loc;
  raise Error

(* typing errors *)
(* unbound *)
let unbound_clock_err name loc =
  Format.eprintf "%aThe type variable \'%s is unbound.@."
    Location.print loc name;
  raise Error

let unbound_carrier_err name loc =
  Format.eprintf "%aThe clock variable \'%s is unbound.@."
    Location.print loc name;
  raise Error

let unbound_effect_err name loc =
  Format.eprintf "%aThe effect variable \'%s is unbound.@."
    Location.print loc name;
  raise Error

let unbound_clock_constr_err gr loc =
  Format.eprintf "%aThe clock constructor %a is unbound.@."
    Location.print loc
    Global_ident.print gr;
  raise Error

let unbound_global_ident_err gr loc =
  Format.eprintf "%aThe name %a is unbound.@."
    Location.print loc
    Global_ident.print gr;
  raise Error

let unbound_ident_err n loc =
  Format.eprintf "%aThe name %s is unbound.@."
    Location.print loc
    (Ident.name n);
  raise Error

let unbound_constructor_err c loc =
  Format.eprintf "%aThe constructor %a is unbound.@."
    Location.print loc
    Global_ident.print c;
  raise Error

let unbound_label_err label loc =
  Format.eprintf "%aThe label %a is unbound.@."
    Location.print loc
    Global_ident.print label;
  raise Error

(* arity *)
let constr_arity_err gr loc =
  Format.eprintf "%aThe value constructor %a expects 1 argument, \
                     but is here applied to 0 argument.@."
    Location.print loc
    Global_ident.print gr;
  raise Error

let constr_arity_err_2 gr loc =
  Format.eprintf "%aThe value constructor %a expects 0 argument, \
                     but is here applied to 1 argument.@."
    Location.print loc
    Global_ident.print gr;
  raise Error

let clock_constr_arity_err gr arit' arit loc =
  Format.eprintf "%aThe clock constructor %a expects %d argument(s), \
                     but is here given %d argument(s).@."
    Location.print loc
    Global_ident.print gr
    arit'
    arit;
  raise Error

let print_arity ff ar =
  Format.fprintf ff "(%d, %d, %d, %d, %d, %d)"
    ar.k_clock ar.k_carrier ar.k_carrier_row
    ar.k_effect ar.k_effect_row ar.k_react

let clock_constr_arity_err gr
    found_arity exp_arity loc =
  Format.eprintf
    "%aThe constructor %a expects %a type variables, \
     but was given %a type variables.@."
    Location.print loc
    Global_ident.print gr
    print_arity exp_arity
    print_arity found_arity;
  raise Error

(* bound several times *)
let non_linear_pattern_err pat n =
  Format.eprintf
    "%aThe variable %s is bound several times in this pattern.@."
    Location.print pat.patt_loc n;
  raise Error

let non_linear_record_err label loc =
  Format.eprintf
    "%aThe label %a is defined several times@."
    Location.print loc
    Global_ident.print label;
  raise Error

let repeated_constructor_definition_err s loc =
  Format.eprintf "%aTwo constructors are named %s@."
    Location.print loc s;
  raise Error


let repeated_label_definition_err s loc =
  Format.eprintf "%aTwo labels are named %s@."
    Location.print loc s;
  raise Error

let orpat_vars loc s =
  Format.eprintf
    "%aVariable %s must occur on both sides of this | pattern.@."
    Location.print loc s;
  raise Error

(* Top level *)
let cannot_generalize_err expr =
  Format.eprintf
    "%aThe clock of this expression, %a,\n\
    contains clock variables that cannot be generalized.@."
    Location.print expr.e_loc
    Clocks_printer.output expr.e_clock;
  raise Error
;;

(* Warnings *)

(*
let partial_apply_warning loc =
  Printf.eprintf "%aWarning: this function application is partial,\n\
           maybe some arguments are missing.@."
    Location.print_oc loc

let not_unit_clock_warning expr =
  Printf.eprintf "%aWarning: this expression should have clock unit.@."
    Location.print_oc expr.e_loc

*)
