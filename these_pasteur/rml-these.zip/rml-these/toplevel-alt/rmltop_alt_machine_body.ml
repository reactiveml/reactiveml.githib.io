(* THIS FILE IS GENERATED. *)
(* ../compiler/rpmlc.native -row-clocking -I ../lib -I ../interpreter/_build rmltop_alt_machine_body.rml  *)

open Rml_machine.Lco_ctrl_tree_seq_interpreter;;
Interpreter.R.init ();;

let main () = Interpreter.rml_halt
;;
