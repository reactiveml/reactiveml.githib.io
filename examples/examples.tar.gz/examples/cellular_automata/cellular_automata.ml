(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc -dtypes -n 1000 -sampling -1.0 -s main cellular_automata.rml  *)

open Implem;;

type  status
= Status_Quiescent |  Status_Wall |  Status_Active ;;


type  fire_state
= Fire_empty |  Fire_ash |  Fire_fire |  Fire_tree ;;


type  dir
=
  Up | 
  Down |  Left |  Right |  Up_Left |  Up_Right |  Down_Left |  Down_Right
  ;;


let opposite =
      (function
        | dir__val_rml_2 ->
            (match dir__val_rml_2 with | Up -> Down | Down -> Up
             | Left -> Right | Right -> Left | Up_Left -> Down_Right
             | Up_Right -> Down_Left | Down_Left -> Up_Right
             | Down_Right -> Up_Left )
        ) 
;;


type 'a info
= {  origine: dir ;   status: status ;   info: 'a} ;;


type 'a neighborhood
= (('a) info) list ;;


let maxx = Pervasives.ref 400 
;;


let maxy = Pervasives.ref 400 
;;


let nox = Pervasives.ref false 
;;


let zoom = Pervasives.ref 2 
;;


type ('a,  'b) cell
= {
   cell_x: int ; 
   cell_y: int ; 
   cell_activation: (('a) info, (('a) info) list) Lco_ctrl_tree_record.event
  ; 
  mutable cell_status: status ; 
  mutable cell_neighborhood:
  ((dir * (('a) info, (('a) info) list) Lco_ctrl_tree_record.event)) list ; 
  mutable cell_ext: 'b} ;;


let make_info =
      (function
        | origine__val_rml_8 ->
            (function
              | cell__val_rml_9 ->
                  {origine=(origine__val_rml_8);
                   status=(cell__val_rml_9).cell_status;
                   info=(cell__val_rml_9).cell_ext}
              )
        ) 
;;


let new_cell =
      (function
        | x__val_rml_11 ->
            (function
              | y__val_rml_12 ->
                  (function
                    | activation__val_rml_13 ->
                        (function
                          | status__val_rml_14 ->
                              (function
                                | ext__val_rml_15 ->
                                    {cell_x=(x__val_rml_11);
                                     cell_y=(y__val_rml_12);
                                     cell_activation=(activation__val_rml_13);
                                     cell_status=(status__val_rml_14);
                                     cell_neighborhood=(([]));
                                     cell_ext=(ext__val_rml_15)}
                                )
                          )
                    )
              )
        ) 
;;


let no_draw = (function | c__val_rml_17 -> () ) 
;;


let draw_cell_gen =
      (function
        | color_of_cell__val_rml_19 ->
            (function
              | c__val_rml_20 ->
                  Graphics.set_color
                    (color_of_cell__val_rml_19 c__val_rml_20);
                    Graphics.fill_rect
                      (Pervasives.( * )
                        (c__val_rml_20).cell_x (Pervasives.(!) zoom))
                      (Pervasives.( * )
                        (c__val_rml_20).cell_y (Pervasives.(!) zoom))
                      (Pervasives.(!) zoom) (Pervasives.(!) zoom)
              )
        ) 
;;


let color_of_status =
      (function
        | s__val_rml_22 ->
            (match (s__val_rml_22).cell_status with
             | Status_Quiescent -> Graphics.red
             | Status_Wall -> Graphics.green | Status_Active -> Graphics.blue
             )
        ) 
;;


let color_of_fire_state =
      (function
        | c__val_rml_24 ->
            (match (c__val_rml_24).cell_ext with
             | Fire_empty -> Graphics.rgb 255 255 255
             | Fire_ash -> Graphics.rgb 173 173 173
             | Fire_fire -> Graphics.rgb 255 0 0
             | Fire_tree -> Graphics.rgb 0 255 0 )
        ) 
;;


let get_von_neumann_neighbors =
      (function
        | cell__val_rml_26 ->
            (function
              | cell_array__val_rml_27 ->
                  (let x__val_rml_28 = (cell__val_rml_26).cell_x  in
                    let y__val_rml_29 = (cell__val_rml_26).cell_y  in
                      let neighbors__val_rml_30 = Pervasives.ref ([])  in
                        if Pervasives.(<=) 0 (Pervasives.(-) x__val_rml_28 1)
                          then
                          Pervasives.(:=)
                            neighbors__val_rml_30
                            ((Left,
                              (Array.get
                                (Array.get
                                  cell_array__val_rml_27
                                  (Pervasives.(-) x__val_rml_28 1))
                                y__val_rml_29))
                              :: (Pervasives.(!) neighbors__val_rml_30))
                          else ();
                          if
                            Pervasives.(<)
                              (Pervasives.(+) x__val_rml_28 1)
                              (Pervasives.(!) maxx)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_30
                              ((Right,
                                (Array.get
                                  (Array.get
                                    cell_array__val_rml_27
                                    (Pervasives.(+) x__val_rml_28 1))
                                  y__val_rml_29))
                                :: (Pervasives.(!) neighbors__val_rml_30))
                            else ();
                          if
                            Pervasives.(<=)
                              0 (Pervasives.(-) y__val_rml_29 1)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_30
                              ((Down,
                                (Array.get
                                  (Array.get
                                    cell_array__val_rml_27 x__val_rml_28)
                                  (Pervasives.(-) y__val_rml_29 1)))
                                :: (Pervasives.(!) neighbors__val_rml_30))
                            else ();
                          if
                            Pervasives.(<)
                              (Pervasives.(+) y__val_rml_29 1)
                              (Pervasives.(!) maxy)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_30
                              ((Up,
                                (Array.get
                                  (Array.get
                                    cell_array__val_rml_27 x__val_rml_28)
                                  (Pervasives.(+) y__val_rml_29 1)))
                                :: (Pervasives.(!) neighbors__val_rml_30))
                            else ();
                          Pervasives.(!) neighbors__val_rml_30)
              )
        ) 
;;


let get_von_neumann_neighbors_circular =
      (function
        | cell__val_rml_32 ->
            (function
              | cell_array__val_rml_33 ->
                  (let maxx__val_rml_34 = Pervasives.(!) maxx  in
                    let maxy__val_rml_35 = Pervasives.(!) maxy  in
                      let x__val_rml_36 =
                            Pervasives.(+)
                              (cell__val_rml_32).cell_x maxx__val_rml_34
                         in
                        let y__val_rml_37 =
                              Pervasives.(+)
                                (cell__val_rml_32).cell_y maxy__val_rml_35
                           in
                          let neighbors__val_rml_38 = Pervasives.ref ([])  in
                            Pervasives.(:=)
                              neighbors__val_rml_38
                              ((Left,
                                (Array.get
                                  (Array.get
                                    cell_array__val_rml_33
                                    (Pervasives.(mod)
                                      (Pervasives.(-) x__val_rml_36 1)
                                      maxx__val_rml_34))
                                  y__val_rml_37))
                                :: (Pervasives.(!) neighbors__val_rml_38));
                              Pervasives.(:=)
                                neighbors__val_rml_38
                                ((Right,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_33
                                      (Pervasives.(mod)
                                        (Pervasives.(+) x__val_rml_36 1)
                                        maxx__val_rml_34))
                                    y__val_rml_37))
                                  :: (Pervasives.(!) neighbors__val_rml_38));
                              Pervasives.(:=)
                                neighbors__val_rml_38
                                ((Down,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_33 x__val_rml_36)
                                    (Pervasives.(mod)
                                      (Pervasives.(-) y__val_rml_37 1)
                                      maxy__val_rml_35)))
                                  :: (Pervasives.(!) neighbors__val_rml_38));
                              Pervasives.(:=)
                                neighbors__val_rml_38
                                ((Up,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_33 x__val_rml_36)
                                    (Pervasives.(mod)
                                      (Pervasives.(+) y__val_rml_37 1)
                                      maxy__val_rml_35)))
                                  :: (Pervasives.(!) neighbors__val_rml_38));
                              Pervasives.(!) neighbors__val_rml_38)
              )
        ) 
;;


let get_moore_neighbors =
      (function
        | cell__val_rml_40 ->
            (function
              | cell_array__val_rml_41 ->
                  (let maxx__val_rml_42 = Pervasives.(!) maxx  in
                    let maxy__val_rml_43 = Pervasives.(!) maxy  in
                      let x__val_rml_44 = (cell__val_rml_40).cell_x  in
                        let y__val_rml_45 = (cell__val_rml_40).cell_y  in
                          let neighbors__val_rml_46 = Pervasives.ref ([])  in
                            if
                              Pervasives.(&&)
                                (Pervasives.(<=)
                                  0 (Pervasives.(-) x__val_rml_44 1))
                                (Pervasives.(<)
                                  (Pervasives.(+) y__val_rml_45 1)
                                  maxy__val_rml_43)
                              then
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Up_Left,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_41
                                      (Pervasives.(-) x__val_rml_44 1))
                                    (Pervasives.(+) y__val_rml_45 1)))
                                  :: (Pervasives.(!) neighbors__val_rml_46))
                              else ();
                              if
                                Pervasives.(<)
                                  (Pervasives.(+) y__val_rml_45 1)
                                  maxy__val_rml_43
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Up,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41 x__val_rml_44)
                                      (Pervasives.(+) y__val_rml_45 1)))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<)
                                    (Pervasives.(+) x__val_rml_44 1)
                                    maxx__val_rml_42)
                                  (Pervasives.(<)
                                    (Pervasives.(+) y__val_rml_45 1)
                                    maxy__val_rml_43)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Up_Right,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41
                                        (Pervasives.(+) x__val_rml_44 1))
                                      (Pervasives.(+) y__val_rml_45 1)))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(<)
                                  (Pervasives.(+) x__val_rml_44 1)
                                  maxx__val_rml_42
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Right,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41
                                        (Pervasives.(+) x__val_rml_44 1))
                                      y__val_rml_45))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<)
                                    (Pervasives.(+) x__val_rml_44 1)
                                    maxx__val_rml_42)
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) y__val_rml_45 1))
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Down_Right,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41
                                        (Pervasives.(+) x__val_rml_44 1))
                                      (Pervasives.(-) y__val_rml_45 1)))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(<=)
                                  0 (Pervasives.(-) y__val_rml_45 1)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Down,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41 x__val_rml_44)
                                      (Pervasives.(-) y__val_rml_45 1)))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) x__val_rml_44 1))
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) y__val_rml_45 1))
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Down_Left,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41
                                        (Pervasives.(-) x__val_rml_44 1))
                                      (Pervasives.(-) y__val_rml_45 1)))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              if
                                Pervasives.(<=)
                                  0 (Pervasives.(-) x__val_rml_44 1)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_46
                                  ((Left,
                                    (Array.get
                                      (Array.get
                                        cell_array__val_rml_41
                                        (Pervasives.(-) x__val_rml_44 1))
                                      y__val_rml_45))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_46))
                                else ();
                              Pervasives.(!) neighbors__val_rml_46)
              )
        ) 
;;


let get_moore_neighbors_circular =
      (function
        | cell__val_rml_48 ->
            (function
              | cell_array__val_rml_49 ->
                  (let maxx__val_rml_50 = Pervasives.(!) maxx  in
                    let maxy__val_rml_51 = Pervasives.(!) maxy  in
                      let x__val_rml_52 =
                            Pervasives.(+)
                              (cell__val_rml_48).cell_x maxx__val_rml_50
                         in
                        let y__val_rml_53 =
                              Pervasives.(+)
                                (cell__val_rml_48).cell_y maxy__val_rml_51
                           in
                          let neighbors__val_rml_54 = Pervasives.ref ([])  in
                            Pervasives.(:=)
                              neighbors__val_rml_54
                              ((Up_Left,
                                (Array.get
                                  (Array.get
                                    cell_array__val_rml_49
                                    (Pervasives.(mod)
                                      (Pervasives.(-) x__val_rml_52 1)
                                      maxx__val_rml_50))
                                  (Pervasives.(mod)
                                    (Pervasives.(+) y__val_rml_53 1)
                                    maxy__val_rml_51)))
                                :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Up,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        x__val_rml_52 maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      (Pervasives.(+) y__val_rml_53 1)
                                      maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Up_Right,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        (Pervasives.(+) x__val_rml_52 1)
                                        maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      (Pervasives.(+) y__val_rml_53 1)
                                      maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Right,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        (Pervasives.(+) x__val_rml_52 1)
                                        maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      y__val_rml_53 maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Down_Right,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        (Pervasives.(+) x__val_rml_52 1)
                                        maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      (Pervasives.(-) y__val_rml_53 1)
                                      maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Down,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        x__val_rml_52 maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      (Pervasives.(-) y__val_rml_53 1)
                                      maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Down_Left,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        (Pervasives.(-) x__val_rml_52 1)
                                        maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      (Pervasives.(-) y__val_rml_53 1)
                                      maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(:=)
                                neighbors__val_rml_54
                                ((Left,
                                  (Array.get
                                    (Array.get
                                      cell_array__val_rml_49
                                      (Pervasives.(mod)
                                        (Pervasives.(-) x__val_rml_52 1)
                                        maxx__val_rml_50))
                                    (Pervasives.(mod)
                                      y__val_rml_53 maxy__val_rml_51)))
                                  :: (Pervasives.(!) neighbors__val_rml_54));
                              Pervasives.(!) neighbors__val_rml_54)
              )
        ) 
;;


let rec activate_neighborhood =
          (function
            | self__val_rml_56 ->
                (function
                  | neighbors__val_rml_57 ->
                      (match neighbors__val_rml_57 with | ([]) -> ()
                       | ((dir__val_rml_58, activation_sig__val_rml_59)) ::
                           (neighbors__val_rml_60) ->
                           (let info__val_rml_61 =
                                  make_info
                                    (opposite dir__val_rml_58)
                                    self__val_rml_56
                              in
                             Lco_ctrl_tree_record.rml_expr_emit_val
                               activation_sig__val_rml_59 info__val_rml_61;
                               activate_neighborhood
                                 self__val_rml_56 neighbors__val_rml_60)
                       )
                  )
            ) 
;;


let cell =
      (function
        | draw_cell__val_rml_63 ->
            (function
              | get_neighbors__val_rml_64 ->
                  (function
                    | cell_behavior__val_rml_65 ->
                        (function
                          | x__val_rml_66 ->
                              (function
                                | y__val_rml_67 ->
                                    (function
                                      | (status_init__val_rml_68,
                                         ext_init__val_rml_69) ->
                                          (function
                                            | cell_array__val_rml_70 ->
                                                ((function
                                                   | () ->
                                                       Lco_ctrl_tree_record.rml_signal
                                                         (function
                                                           | activation__sig_71 ->
                                                               Lco_ctrl_tree_record.rml_def
                                                                 (function
                                                                   | 
                                                                   () ->
                                                                    new_cell
                                                                    x__val_rml_66
                                                                    y__val_rml_67
                                                                    activation__sig_71
                                                                    status_init__val_rml_68
                                                                    ext_init__val_rml_69
                                                                   )
                                                                 (function
                                                                   | 
                                                                   self__val_rml_72 ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Array.set
                                                                    (Array.get
                                                                    cell_array__val_rml_70
                                                                    x__val_rml_66)
                                                                    y__val_rml_67
                                                                    activation__sig_71;
                                                                    draw_cell__val_rml_63
                                                                    self__val_rml_72
                                                                    ))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    self__val_rml_72.cell_neighborhood
                                                                    <-
                                                                    get_neighbors__val_rml_64
                                                                    self__val_rml_72
                                                                    cell_array__val_rml_70
                                                                    )))
                                                                    (Lco_ctrl_tree_record.rml_loop
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_if
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(<>)
                                                                    (self__val_rml_72).cell_status
                                                                    Status_Quiescent
                                                                    )
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    activate_neighborhood
                                                                    self__val_rml_72
                                                                    (self__val_rml_72).cell_neighborhood
                                                                    ))
                                                                    (Lco_ctrl_tree_record.rml_await_immediate'
                                                                    activation__sig_71))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    (let 
                                                                    neighbors__val_rml_73
                                                                    =
                                                                    Lco_ctrl_tree_record.rml_pre_value
                                                                    activation__sig_71
                                                                     in
                                                                    cell_behavior__val_rml_65
                                                                    self__val_rml_72
                                                                    neighbors__val_rml_73;
                                                                    draw_cell__val_rml_63
                                                                    self__val_rml_72)
                                                                    ))))
                                                                   )
                                                           )
                                                   ):
                                                  (_)
                                                    Lco_ctrl_tree_record.process)
                                            )
                                      )
                                )
                          )
                    )
              )
        ) 
;;


let fredkin =
      (function
        | cell__val_rml_75 ->
            (function
              | neighbors__val_rml_76 ->
                  (let cpt__val_rml_77 = Pervasives.ref 0  in
                    List.iter
                      (function
                        | info__val_rml_78 ->
                            if
                              Pervasives.(<>)
                                (info__val_rml_78).status Status_Quiescent
                              then Pervasives.incr cpt__val_rml_77 else 
                              ()
                        )
                      neighbors__val_rml_76;
                      cell__val_rml_75.cell_status <-
                        (if
                          Pervasives.(=)
                            (Pervasives.(mod)
                              (Pervasives.(!) cpt__val_rml_77) 2)
                            1
                          then Status_Active else Status_Quiescent))
              )
        ) 
;;


let game_of_life =
      (function
        | cell__val_rml_80 ->
            (function
              | neighbors__val_rml_81 ->
                  (let cpt__val_rml_82 = Pervasives.ref 0  in
                    List.iter
                      (function
                        | info__val_rml_83 ->
                            if
                              Pervasives.(<>)
                                (info__val_rml_83).status Status_Quiescent
                              then Pervasives.incr cpt__val_rml_82 else 
                              ()
                        )
                      neighbors__val_rml_81;
                      cell__val_rml_80.cell_status <-
                        (if
                          Pervasives.(&&)
                            (Pervasives.(=)
                              (cell__val_rml_80).cell_status Status_Quiescent)
                            (Pervasives.(=)
                              (Pervasives.(!) cpt__val_rml_82) 3)
                          then Status_Active else
                          if
                            Pervasives.(&&)
                              (Pervasives.(<>)
                                (cell__val_rml_80).cell_status
                                Status_Quiescent)
                              (Pervasives.(&&)
                                (Pervasives.(<>)
                                  (Pervasives.(!) cpt__val_rml_82) 2)
                                (Pervasives.(<>)
                                  (Pervasives.(!) cpt__val_rml_82) 3))
                            then Status_Quiescent else
                            (cell__val_rml_80).cell_status))
              )
        ) 
;;


let fire_behavior =
      (function
        | cell__val_rml_85 ->
            (function
              | neighbors__val_rml_86 ->
                  (match (cell__val_rml_85).cell_ext with
                   | Fire_empty ->
                       cell__val_rml_85.cell_status <- Status_Quiescent
                   | Fire_ash ->
                       cell__val_rml_85.cell_ext <- Fire_empty;
                         cell__val_rml_85.cell_status <- Status_Quiescent
                   | Fire_fire ->
                       cell__val_rml_85.cell_ext <- Fire_ash;
                         cell__val_rml_85.cell_status <- Status_Active
                   | Fire_tree ->
                       if
                         List.exists
                           (function
                             | info__val_rml_87 ->
                                 Pervasives.(=)
                                   (info__val_rml_87).info Fire_fire
                             )
                           neighbors__val_rml_86
                         then
                         (cell__val_rml_85.cell_ext <- Fire_fire;
                           cell__val_rml_85.cell_status <- Status_Active)
                         else
                         cell__val_rml_85.cell_status <- Status_Quiescent
                   )
              )
        ) 
;;


let cell_array_create =
      (function
        | tmp__val_rml_89 ->
            Array.make_matrix
              (Pervasives.(!) maxx) (Pervasives.(!) maxy) tmp__val_rml_89
        ) 
;;


let get_status_empty =
      (function
        | i__val_rml_91 ->
            (function | j__val_rml_92 -> (Status_Quiescent, ()) )
        ) 
;;


let get_status_center =
      (function
        | i__val_rml_94 ->
            (function
              | j__val_rml_95 ->
                  if
                    Pervasives.(&&)
                      (Pervasives.(=)
                        i__val_rml_94
                        (Pervasives.(/) (Pervasives.(!) maxx) 2))
                      (Pervasives.(=)
                        j__val_rml_95
                        (Pervasives.(/) (Pervasives.(!) maxy) 2))
                    then (Status_Active, ()) else (Status_Quiescent, ())
              )
        ) 
;;


let get_status_center_line =
      (function
        | i__val_rml_97 ->
            (function
              | j__val_rml_98 ->
                  if
                    Pervasives.(=)
                      i__val_rml_97 (Pervasives.(/) (Pervasives.(!) maxx) 2)
                    then (Status_Active, ()) else (Status_Quiescent, ())
              )
        ) 
;;


let get_status_center_line_wall =
      (function
        | i__val_rml_100 ->
            (function
              | j__val_rml_101 ->
                  if
                    Pervasives.(or)
                      (Pervasives.(=) i__val_rml_100 0)
                      (Pervasives.(or)
                        (Pervasives.(=)
                          i__val_rml_100
                          (Pervasives.(/) (Pervasives.(!) maxx) 2))
                        (Pervasives.(or)
                          (Pervasives.(=)
                            i__val_rml_100
                            (Pervasives.(-) (Pervasives.(!) maxx) 1))
                          (Pervasives.(or)
                            (Pervasives.(=) j__val_rml_101 0)
                            (Pervasives.(=)
                              j__val_rml_101
                              (Pervasives.(-) (Pervasives.(!) maxy) 1)))))
                    then (Status_Active, ()) else (Status_Quiescent, ())
              )
        ) 
;;


let get_status_fire =
      (function
        | i__val_rml_103 ->
            (function
              | j__val_rml_104 ->
                  if
                    Pervasives.(&&)
                      (Pervasives.(=)
                        i__val_rml_103
                        (Pervasives.(/) (Pervasives.(!) maxx) 2))
                      (Pervasives.(=)
                        j__val_rml_104
                        (Pervasives.(/) (Pervasives.(!) maxy) 2))
                    then (Status_Active, Fire_fire) else
                    if Pervasives.(<) (Random.float 1.) 0.6 then
                      (Status_Quiescent, Fire_tree) else
                      (Status_Quiescent, Fire_empty)
              )
        ) 
;;


let cellular_automaton_start =
      (function
        | draw_cell__val_rml_106 ->
            (function
              | get_neighbors__val_rml_107 ->
                  (function
                    | get_status__val_rml_108 ->
                        (function
                          | cell_behavior__val_rml_109 ->
                              (function
                                | cell_array__val_rml_110 ->
                                    ((function
                                       | () ->
                                           Lco_ctrl_tree_record.rml_fordopar
                                             (function | () -> 0 )
                                             (function
                                               | () ->
                                                   Pervasives.(-)
                                                     (Pervasives.(!) maxx) 1
                                               )
                                             true
                                             (function
                                               | i__val_rml_111 ->
                                                   Lco_ctrl_tree_record.rml_fordopar
                                                     (function | () -> 0 )
                                                     (function
                                                       | () ->
                                                           Pervasives.(-)
                                                             (Pervasives.(!)
                                                               maxy)
                                                             1
                                                       )
                                                     true
                                                     (function
                                                       | j__val_rml_112 ->
                                                           Lco_ctrl_tree_record.rml_run
                                                             (function
                                                               | () ->
                                                                   cell
                                                                    draw_cell__val_rml_106
                                                                    get_neighbors__val_rml_107
                                                                    cell_behavior__val_rml_109
                                                                    i__val_rml_111
                                                                    j__val_rml_112
                                                                    (get_status__val_rml_108
                                                                    i__val_rml_111
                                                                    j__val_rml_112)
                                                                    cell_array__val_rml_110
                                                               )
                                                       )
                                               )
                                       ):
                                      (_) Lco_ctrl_tree_record.process)
                                )
                          )
                    )
              )
        ) 
;;


let behavior = Pervasives.ref "fire" 
;;


let configure =
      (function
        | () ->
            Arg.parse
              (("-zoom", (Arg.Set_int zoom), "<n> set the size of a cell") ::
                (("-width",
                  (Arg.Set_int maxx),
                  "<n> set the number of cells in the width") ::
                  (("-w",
                    (Arg.Set_int maxx),
                    "<n> set the number of cells in the width") ::
                    (("-height",
                      (Arg.Set_int maxy),
                      "<n> set the number of cells in the height") ::
                      (("-h",
                        (Arg.Set_int maxy),
                        "<n> set the number of cells in the height") ::
                        (("-b",
                          (Arg.Set_string behavior),
                          "<s> select the behavior of the automaton") ::
                          (("-nox", (Arg.Set nox), "disable graphical output")
                            :: ([]))))))))
              (function
                | s__val_rml_121 ->
                    Pervasives.raise (Invalid_argument s__val_rml_121)
                )
              "Options are:"
        ) 
;;


let main =
      ((function
         | () ->
             Lco_ctrl_tree_record.rml_seq
               (Lco_ctrl_tree_record.rml_compute
                 (function
                   | () ->
                       Random.self_init (); configure ();
                         if Pervasives.(!) nox then () else
                           (Graphics.open_graph
                              (Pervasives.(^)
                                " "
                                (Pervasives.(^)
                                  (Pervasives.string_of_int
                                    (Pervasives.( * )
                                      (Pervasives.(!) maxx)
                                      (Pervasives.(!) zoom)))
                                  (Pervasives.(^)
                                    "x"
                                    (Pervasives.string_of_int
                                      (Pervasives.( * )
                                        (Pervasives.(!) maxy)
                                        (Pervasives.(!) zoom))))));
                             Graphics.auto_synchronize false)
                   ))
               (Lco_ctrl_tree_record.rml_par
                 (Lco_ctrl_tree_record.rml_match
                   (function | () -> Pervasives.(!) behavior )
                   (function
                     | "gol" ->
                         Lco_ctrl_tree_record.rml_signal
                           (function
                             | tmp__sig_123 ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_123 )
                                   (function
                                     | cell_array__val_rml_124 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_125 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_125
                                                           get_moore_neighbors_circular
                                                           get_status_center_line_wall
                                                           game_of_life
                                                           cell_array__val_rml_124
                                                     )
                                             )
                                     )
                             )
                     | "fredkin" ->
                         Lco_ctrl_tree_record.rml_signal
                           (function
                             | tmp__sig_126 ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_126 )
                                   (function
                                     | cell_array__val_rml_127 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_128 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_128
                                                           get_moore_neighbors_circular
                                                           get_status_center
                                                           fredkin
                                                           cell_array__val_rml_127
                                                     )
                                             )
                                     )
                             )
                     | "fredkin2" ->
                         Lco_ctrl_tree_record.rml_signal
                           (function
                             | tmp__sig_129 ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_129 )
                                   (function
                                     | cell_array__val_rml_130 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_131 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_131
                                                           get_von_neumann_neighbors
                                                           get_status_center
                                                           fredkin
                                                           cell_array__val_rml_130
                                                     )
                                             )
                                     )
                             )
                     | "fire" ->
                         Lco_ctrl_tree_record.rml_signal
                           (function
                             | tmp__sig_132 ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_132 )
                                   (function
                                     | cell_array__val_rml_133 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_fire_state
                                             )
                                           (function
                                             | draw__val_rml_134 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_134
                                                           get_von_neumann_neighbors
                                                           get_status_fire
                                                           fire_behavior
                                                           cell_array__val_rml_133
                                                     )
                                             )
                                     )
                             )
                     | s__val_rml_135 ->
                         Lco_ctrl_tree_record.rml_compute
                           (function
                             | () ->
                                 Pervasives.raise
                                   (Invalid_argument s__val_rml_135)
                             )
                     ))
                 (Lco_ctrl_tree_record.rml_if
                   (function | () -> Pervasives.(!) nox )
                   (Lco_ctrl_tree_record.rml_compute (function | () -> () ))
                   (Lco_ctrl_tree_record.rml_loop
                     (Lco_ctrl_tree_record.rml_seq
                       (Lco_ctrl_tree_record.rml_compute
                         (function | () -> Graphics.synchronize () ))
                       Lco_ctrl_tree_record.rml_pause))))
         ):
        (_) Lco_ctrl_tree_record.process) 
;;

module Rml_machine = Rml_machine.M(Lco_ctrl_tree_record);;
let _ = Rml_machine.rml_exec_n main 1000
