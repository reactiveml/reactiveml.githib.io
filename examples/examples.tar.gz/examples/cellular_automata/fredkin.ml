(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc -dtypes -n 1000 -sampling -1.0 -s main fredkin.rml  *)

open Implem;;

let maxx = Pervasives.ref 400 
;;


let maxy = Pervasives.ref 400 
;;


type  status
= Status_Quiescent |  Status_Active ;;


type  cell
= {
   cell_x: int ; 
   cell_y: int ; 
   cell_activation: (unit, int) Lco_ctrl_tree_record.event ; 
  mutable cell_status: status ;  mutable cell_neighborhood:
  ((unit, int) Lco_ctrl_tree_record.event) list} ;;


let new_cell =
      (function
        | x__val_rml_4 ->
            (function
              | y__val_rml_5 ->
                  (function
                    | activation__val_rml_6 ->
                        (function
                          | status__val_rml_7 ->
                              {cell_x=(x__val_rml_4);
                               cell_y=(y__val_rml_5);
                               cell_activation=(activation__val_rml_6);
                               cell_status=(status__val_rml_7);
                               cell_neighborhood=(([]))}
                          )
                    )
              )
        ) 
;;


let nox = Pervasives.ref false 
;;


let zoom = Pervasives.ref 2 
;;


let no_draw = (function | c__val_rml_11 -> () ) 
;;


let draw_cell_gen =
      (function
        | color_of_cell__val_rml_13 ->
            (function
              | c__val_rml_14 ->
                  Graphics.set_color
                    (color_of_cell__val_rml_13 c__val_rml_14);
                    Graphics.fill_rect
                      (Pervasives.( * )
                        (c__val_rml_14).cell_x (Pervasives.(!) zoom))
                      (Pervasives.( * )
                        (c__val_rml_14).cell_y (Pervasives.(!) zoom))
                      (Pervasives.(!) zoom) (Pervasives.(!) zoom)
              )
        ) 
;;


let color_of_status =
      (function
        | s__val_rml_16 ->
            (match (s__val_rml_16).cell_status with
             | Status_Quiescent -> Graphics.red
             | Status_Active -> Graphics.blue )
        ) 
;;


let get_von_neumann_neighbors =
      (function
        | cell__val_rml_18 ->
            (function
              | cell_array__val_rml_19 ->
                  (let x__val_rml_20 = (cell__val_rml_18).cell_x  in
                    let y__val_rml_21 = (cell__val_rml_18).cell_y  in
                      let neighbors__val_rml_22 = Pervasives.ref ([])  in
                        if Pervasives.(<=) 0 (Pervasives.(-) x__val_rml_20 1)
                          then
                          Pervasives.(:=)
                            neighbors__val_rml_22
                            ((Array.get
                               (Array.get
                                 cell_array__val_rml_19
                                 (Pervasives.(-) x__val_rml_20 1))
                               y__val_rml_21)
                              :: (Pervasives.(!) neighbors__val_rml_22))
                          else ();
                          if
                            Pervasives.(<)
                              (Pervasives.(+) x__val_rml_20 1)
                              (Pervasives.(!) maxx)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_22
                              ((Array.get
                                 (Array.get
                                   cell_array__val_rml_19
                                   (Pervasives.(+) x__val_rml_20 1))
                                 y__val_rml_21)
                                :: (Pervasives.(!) neighbors__val_rml_22))
                            else ();
                          if
                            Pervasives.(<=)
                              0 (Pervasives.(-) y__val_rml_21 1)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_22
                              ((Array.get
                                 (Array.get
                                   cell_array__val_rml_19 x__val_rml_20)
                                 (Pervasives.(-) y__val_rml_21 1))
                                :: (Pervasives.(!) neighbors__val_rml_22))
                            else ();
                          if
                            Pervasives.(<)
                              (Pervasives.(+) y__val_rml_21 1)
                              (Pervasives.(!) maxy)
                            then
                            Pervasives.(:=)
                              neighbors__val_rml_22
                              ((Array.get
                                 (Array.get
                                   cell_array__val_rml_19 x__val_rml_20)
                                 (Pervasives.(+) y__val_rml_21 1))
                                :: (Pervasives.(!) neighbors__val_rml_22))
                            else ();
                          Pervasives.(!) neighbors__val_rml_22)
              )
        ) 
;;


let get_von_neumann_neighbors_circular =
      (function
        | cell__val_rml_24 ->
            (function
              | cell_array__val_rml_25 ->
                  (let maxx__val_rml_26 = Pervasives.(!) maxx  in
                    let maxy__val_rml_27 = Pervasives.(!) maxy  in
                      let x__val_rml_28 =
                            Pervasives.(+)
                              (cell__val_rml_24).cell_x maxx__val_rml_26
                         in
                        let y__val_rml_29 =
                              Pervasives.(+)
                                (cell__val_rml_24).cell_y maxy__val_rml_27
                           in
                          let neighbors__val_rml_30 = Pervasives.ref ([])  in
                            Pervasives.(:=)
                              neighbors__val_rml_30
                              ((Array.get
                                 (Array.get
                                   cell_array__val_rml_25
                                   (Pervasives.(mod)
                                     (Pervasives.(-) x__val_rml_28 1)
                                     maxx__val_rml_26))
                                 y__val_rml_29)
                                :: (Pervasives.(!) neighbors__val_rml_30));
                              Pervasives.(:=)
                                neighbors__val_rml_30
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_25
                                     (Pervasives.(mod)
                                       (Pervasives.(+) x__val_rml_28 1)
                                       maxx__val_rml_26))
                                   y__val_rml_29)
                                  :: (Pervasives.(!) neighbors__val_rml_30));
                              Pervasives.(:=)
                                neighbors__val_rml_30
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_25 x__val_rml_28)
                                   (Pervasives.(mod)
                                     (Pervasives.(-) y__val_rml_29 1)
                                     maxy__val_rml_27))
                                  :: (Pervasives.(!) neighbors__val_rml_30));
                              Pervasives.(:=)
                                neighbors__val_rml_30
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_25 x__val_rml_28)
                                   (Pervasives.(mod)
                                     (Pervasives.(+) y__val_rml_29 1)
                                     maxy__val_rml_27))
                                  :: (Pervasives.(!) neighbors__val_rml_30));
                              Pervasives.(!) neighbors__val_rml_30)
              )
        ) 
;;


let get_moore_neighbors =
      (function
        | cell__val_rml_32 ->
            (function
              | cell_array__val_rml_33 ->
                  (let maxx__val_rml_34 = Pervasives.(!) maxx  in
                    let maxy__val_rml_35 = Pervasives.(!) maxy  in
                      let x__val_rml_36 = (cell__val_rml_32).cell_x  in
                        let y__val_rml_37 = (cell__val_rml_32).cell_y  in
                          let neighbors__val_rml_38 = Pervasives.ref ([])  in
                            if
                              Pervasives.(&&)
                                (Pervasives.(<=)
                                  0 (Pervasives.(-) x__val_rml_36 1))
                                (Pervasives.(<)
                                  (Pervasives.(+) y__val_rml_37 1)
                                  maxy__val_rml_35)
                              then
                              Pervasives.(:=)
                                neighbors__val_rml_38
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_33
                                     (Pervasives.(-) x__val_rml_36 1))
                                   (Pervasives.(+) y__val_rml_37 1))
                                  :: (Pervasives.(!) neighbors__val_rml_38))
                              else ();
                              if
                                Pervasives.(<)
                                  (Pervasives.(+) y__val_rml_37 1)
                                  maxy__val_rml_35
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33 x__val_rml_36)
                                     (Pervasives.(+) y__val_rml_37 1))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<)
                                    (Pervasives.(+) x__val_rml_36 1)
                                    maxx__val_rml_34)
                                  (Pervasives.(<)
                                    (Pervasives.(+) y__val_rml_37 1)
                                    maxy__val_rml_35)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33
                                       (Pervasives.(+) x__val_rml_36 1))
                                     (Pervasives.(+) y__val_rml_37 1))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(<)
                                  (Pervasives.(+) x__val_rml_36 1)
                                  maxx__val_rml_34
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33
                                       (Pervasives.(+) x__val_rml_36 1))
                                     y__val_rml_37)
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<)
                                    (Pervasives.(+) x__val_rml_36 1)
                                    maxx__val_rml_34)
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) y__val_rml_37 1))
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33
                                       (Pervasives.(+) x__val_rml_36 1))
                                     (Pervasives.(-) y__val_rml_37 1))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(<=)
                                  0 (Pervasives.(-) y__val_rml_37 1)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33 x__val_rml_36)
                                     (Pervasives.(-) y__val_rml_37 1))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) x__val_rml_36 1))
                                  (Pervasives.(<=)
                                    0 (Pervasives.(-) y__val_rml_37 1))
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33
                                       (Pervasives.(-) x__val_rml_36 1))
                                     (Pervasives.(-) y__val_rml_37 1))
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              if
                                Pervasives.(<=)
                                  0 (Pervasives.(-) x__val_rml_36 1)
                                then
                                Pervasives.(:=)
                                  neighbors__val_rml_38
                                  ((Array.get
                                     (Array.get
                                       cell_array__val_rml_33
                                       (Pervasives.(-) x__val_rml_36 1))
                                     y__val_rml_37)
                                    ::
                                    (Pervasives.(!) neighbors__val_rml_38))
                                else ();
                              Pervasives.(!) neighbors__val_rml_38)
              )
        ) 
;;


let get_moore_neighbors_circular =
      (function
        | cell__val_rml_40 ->
            (function
              | cell_array__val_rml_41 ->
                  (let maxx__val_rml_42 = Pervasives.(!) maxx  in
                    let maxy__val_rml_43 = Pervasives.(!) maxy  in
                      let x__val_rml_44 =
                            Pervasives.(+)
                              (cell__val_rml_40).cell_x maxx__val_rml_42
                         in
                        let y__val_rml_45 =
                              Pervasives.(+)
                                (cell__val_rml_40).cell_y maxy__val_rml_43
                           in
                          let neighbors__val_rml_46 = Pervasives.ref ([])  in
                            Pervasives.(:=)
                              neighbors__val_rml_46
                              ((Array.get
                                 (Array.get
                                   cell_array__val_rml_41
                                   (Pervasives.(mod)
                                     (Pervasives.(-) x__val_rml_44 1)
                                     maxx__val_rml_42))
                                 (Pervasives.(mod)
                                   (Pervasives.(+) y__val_rml_45 1)
                                   maxy__val_rml_43))
                                :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       x__val_rml_44 maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     (Pervasives.(+) y__val_rml_45 1)
                                     maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       (Pervasives.(+) x__val_rml_44 1)
                                       maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     (Pervasives.(+) y__val_rml_45 1)
                                     maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       (Pervasives.(+) x__val_rml_44 1)
                                       maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     y__val_rml_45 maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       (Pervasives.(+) x__val_rml_44 1)
                                       maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     (Pervasives.(-) y__val_rml_45 1)
                                     maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       x__val_rml_44 maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     (Pervasives.(-) y__val_rml_45 1)
                                     maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       (Pervasives.(-) x__val_rml_44 1)
                                       maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     (Pervasives.(-) y__val_rml_45 1)
                                     maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(:=)
                                neighbors__val_rml_46
                                ((Array.get
                                   (Array.get
                                     cell_array__val_rml_41
                                     (Pervasives.(mod)
                                       (Pervasives.(-) x__val_rml_44 1)
                                       maxx__val_rml_42))
                                   (Pervasives.(mod)
                                     y__val_rml_45 maxy__val_rml_43))
                                  :: (Pervasives.(!) neighbors__val_rml_46));
                              Pervasives.(!) neighbors__val_rml_46)
              )
        ) 
;;


let rec activate_neighborhood =
          (function
            | self__val_rml_48 ->
                (function
                  | neighbors__val_rml_49 ->
                      (match neighbors__val_rml_49 with | ([]) -> ()
                       | (activation_sig__val_rml_50) ::
                           (neighbors__val_rml_51) ->
                           Lco_ctrl_tree_record.rml_expr_emit
                             activation_sig__val_rml_50;
                             activate_neighborhood
                               self__val_rml_48 neighbors__val_rml_51
                       )
                  )
            ) 
;;


let cell =
      (function
        | draw_cell__val_rml_53 ->
            (function
              | get_neighbors__val_rml_54 ->
                  (function
                    | cell_behavior__val_rml_55 ->
                        (function
                          | x__val_rml_56 ->
                              (function
                                | y__val_rml_57 ->
                                    (function
                                      | status_init__val_rml_58 ->
                                          (function
                                            | cell_array__val_rml_59 ->
                                                ((function
                                                   | () ->
                                                       Lco_ctrl_tree_record.rml_signal_combine
                                                         (function | 
                                                           () -> 0 )
                                                         (function
                                                           | () ->
                                                               (function
                                                                 | x__val_rml_60 ->
                                                                    (function
                                                                    | y__val_rml_61 ->
                                                                    Pervasives.(+)
                                                                    y__val_rml_61
                                                                    1 )
                                                                 )
                                                           )
                                                         (function
                                                           | activation__sig_62 ->
                                                               Lco_ctrl_tree_record.rml_def
                                                                 (function
                                                                   | 
                                                                   () ->
                                                                    new_cell
                                                                    x__val_rml_56
                                                                    y__val_rml_57
                                                                    activation__sig_62
                                                                    status_init__val_rml_58
                                                                   )
                                                                 (function
                                                                   | 
                                                                   self__val_rml_63 ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Array.set
                                                                    (Array.get
                                                                    cell_array__val_rml_59
                                                                    x__val_rml_56)
                                                                    y__val_rml_57
                                                                    activation__sig_62;
                                                                    draw_cell__val_rml_53
                                                                    self__val_rml_63
                                                                    ))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    self__val_rml_63.cell_neighborhood
                                                                    <-
                                                                    get_neighbors__val_rml_54
                                                                    self__val_rml_63
                                                                    cell_array__val_rml_59
                                                                    )))
                                                                    (Lco_ctrl_tree_record.rml_loop
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_if
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(<>)
                                                                    (self__val_rml_63).cell_status
                                                                    Status_Quiescent
                                                                    )
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    activate_neighborhood
                                                                    self__val_rml_63
                                                                    (self__val_rml_63).cell_neighborhood
                                                                    ))
                                                                    (Lco_ctrl_tree_record.rml_await_immediate'
                                                                    activation__sig_62))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    (let 
                                                                    cpt__val_rml_64
                                                                    =
                                                                    Lco_ctrl_tree_record.rml_pre_value
                                                                    activation__sig_62
                                                                     in
                                                                    cell_behavior__val_rml_55
                                                                    self__val_rml_63
                                                                    cpt__val_rml_64;
                                                                    draw_cell__val_rml_53
                                                                    self__val_rml_63)
                                                                    ))))
                                                                   )
                                                           )
                                                   ):
                                                  (_)
                                                    Lco_ctrl_tree_record.process)
                                            )
                                      )
                                )
                          )
                    )
              )
        ) 
;;


let fredkin =
      (function
        | cell__val_rml_66 ->
            (function
              | cpt__val_rml_67 ->
                  cell__val_rml_66.cell_status <-
                    (if Pervasives.(=) (Pervasives.(mod) cpt__val_rml_67 2) 1
                      then Status_Active else Status_Quiescent)
              )
        ) 
;;


let game_of_life =
      (function
        | cell__val_rml_69 ->
            (function
              | cpt__val_rml_70 ->
                  cell__val_rml_69.cell_status <-
                    (if
                      Pervasives.(&&)
                        (Pervasives.(=)
                          (cell__val_rml_69).cell_status Status_Quiescent)
                        (Pervasives.(=) cpt__val_rml_70 3)
                      then Status_Active else
                      if
                        Pervasives.(&&)
                          (Pervasives.(<>)
                            (cell__val_rml_69).cell_status Status_Quiescent)
                          (Pervasives.(&&)
                            (Pervasives.(<>) cpt__val_rml_70 2)
                            (Pervasives.(<>) cpt__val_rml_70 3))
                        then Status_Quiescent else
                        (cell__val_rml_69).cell_status)
              )
        ) 
;;


let cell_array_create =
      (function
        | tmp__val_rml_72 ->
            Array.make_matrix
              (Pervasives.(!) maxx) (Pervasives.(!) maxy) tmp__val_rml_72
        ) 
;;


let get_status_empty =
      (function
        | i__val_rml_74 -> (function | j__val_rml_75 -> Status_Quiescent ) ) 
;;


let get_status_center =
      (function
        | i__val_rml_77 ->
            (function
              | j__val_rml_78 ->
                  if
                    Pervasives.(&&)
                      (Pervasives.(=)
                        i__val_rml_77
                        (Pervasives.(/) (Pervasives.(!) maxx) 2))
                      (Pervasives.(=)
                        j__val_rml_78
                        (Pervasives.(/) (Pervasives.(!) maxy) 2))
                    then Status_Active else Status_Quiescent
              )
        ) 
;;


let get_status_center_line =
      (function
        | i__val_rml_80 ->
            (function
              | j__val_rml_81 ->
                  if
                    Pervasives.(=)
                      i__val_rml_80 (Pervasives.(/) (Pervasives.(!) maxx) 2)
                    then Status_Active else Status_Quiescent
              )
        ) 
;;


let get_status_center_line_wall =
      (function
        | i__val_rml_83 ->
            (function
              | j__val_rml_84 ->
                  if
                    Pervasives.(or)
                      (Pervasives.(=) i__val_rml_83 0)
                      (Pervasives.(or)
                        (Pervasives.(=)
                          i__val_rml_83
                          (Pervasives.(/) (Pervasives.(!) maxx) 2))
                        (Pervasives.(or)
                          (Pervasives.(=)
                            i__val_rml_83
                            (Pervasives.(-) (Pervasives.(!) maxx) 1))
                          (Pervasives.(or)
                            (Pervasives.(=) j__val_rml_84 0)
                            (Pervasives.(=)
                              j__val_rml_84
                              (Pervasives.(-) (Pervasives.(!) maxy) 1)))))
                    then Status_Active else Status_Quiescent
              )
        ) 
;;


let cellular_automaton_start =
      (function
        | draw_cell__val_rml_86 ->
            (function
              | get_neighbors__val_rml_87 ->
                  (function
                    | get_status__val_rml_88 ->
                        (function
                          | cell_behavior__val_rml_89 ->
                              (function
                                | cell_array__val_rml_90 ->
                                    ((function
                                       | () ->
                                           Lco_ctrl_tree_record.rml_fordopar
                                             (function | () -> 0 )
                                             (function
                                               | () ->
                                                   Pervasives.(-)
                                                     (Pervasives.(!) maxx) 1
                                               )
                                             true
                                             (function
                                               | i__val_rml_91 ->
                                                   Lco_ctrl_tree_record.rml_fordopar
                                                     (function | () -> 0 )
                                                     (function
                                                       | () ->
                                                           Pervasives.(-)
                                                             (Pervasives.(!)
                                                               maxy)
                                                             1
                                                       )
                                                     true
                                                     (function
                                                       | j__val_rml_92 ->
                                                           Lco_ctrl_tree_record.rml_run
                                                             (function
                                                               | () ->
                                                                   cell
                                                                    draw_cell__val_rml_86
                                                                    get_neighbors__val_rml_87
                                                                    cell_behavior__val_rml_89
                                                                    i__val_rml_91
                                                                    j__val_rml_92
                                                                    (get_status__val_rml_88
                                                                    i__val_rml_91
                                                                    j__val_rml_92)
                                                                    cell_array__val_rml_90
                                                               )
                                                       )
                                               )
                                       ):
                                      (_) Lco_ctrl_tree_record.process)
                                )
                          )
                    )
              )
        ) 
;;


let behavior = Pervasives.ref "fredkin" 
;;


let configure =
      (function
        | () ->
            Arg.parse
              (("-zoom", (Arg.Set_int zoom), "<n> set the size of a cell") ::
                (("-width",
                  (Arg.Set_int maxx),
                  "<n> set the number of cells in the width") ::
                  (("-w",
                    (Arg.Set_int maxx),
                    "<n> set the number of cells in the width") ::
                    (("-height",
                      (Arg.Set_int maxy),
                      "<n> set the number of cells in the height") ::
                      (("-h",
                        (Arg.Set_int maxy),
                        "<n> set the number of cells in the height") ::
                        (("-b",
                          (Arg.Set_string behavior),
                          "<s> select the behavior of the automaton") ::
                          (("-nox", (Arg.Set nox), "disable graphical output")
                            :: ([]))))))))
              (function
                | s__val_rml_101 ->
                    Pervasives.raise (Invalid_argument s__val_rml_101)
                )
              "Options are:"
        ) 
;;


let main =
      ((function
         | () ->
             Lco_ctrl_tree_record.rml_seq
               (Lco_ctrl_tree_record.rml_compute
                 (function
                   | () ->
                       Random.self_init (); configure ();
                         if Pervasives.(!) nox then () else
                           (Graphics.open_graph
                              (Pervasives.(^)
                                " "
                                (Pervasives.(^)
                                  (Pervasives.string_of_int
                                    (Pervasives.( * )
                                      (Pervasives.(!) maxx)
                                      (Pervasives.(!) zoom)))
                                  (Pervasives.(^)
                                    "x"
                                    (Pervasives.string_of_int
                                      (Pervasives.( * )
                                        (Pervasives.(!) maxy)
                                        (Pervasives.(!) zoom))))));
                             Graphics.auto_synchronize false)
                   ))
               (Lco_ctrl_tree_record.rml_signal_combine
                 (function | () -> 0 )
                 (function
                   | () ->
                       (function
                         | x__val_rml_103 ->
                             (function
                               | y__val_rml_104 ->
                                   Pervasives.(+) y__val_rml_104 1
                               )
                         )
                   )
                 (function
                   | tmp__sig_105 ->
                       Lco_ctrl_tree_record.rml_par
                         (Lco_ctrl_tree_record.rml_match
                           (function | () -> Pervasives.(!) behavior )
                           (function
                             | "gol" ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_105 )
                                   (function
                                     | cell_array__val_rml_106 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_107 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_107
                                                           get_moore_neighbors_circular
                                                           get_status_center_line_wall
                                                           game_of_life
                                                           cell_array__val_rml_106
                                                     )
                                             )
                                     )
                             | "fredkin" ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_105 )
                                   (function
                                     | cell_array__val_rml_108 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_109 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_109
                                                           get_moore_neighbors_circular
                                                           get_status_center
                                                           fredkin
                                                           cell_array__val_rml_108
                                                     )
                                             )
                                     )
                             | "fredkin2" ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () -> cell_array_create tmp__sig_105 )
                                   (function
                                     | cell_array__val_rml_110 ->
                                         Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 if Pervasives.(!) nox then
                                                   no_draw else
                                                   draw_cell_gen
                                                     color_of_status
                                             )
                                           (function
                                             | draw__val_rml_111 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         cellular_automaton_start
                                                           draw__val_rml_111
                                                           get_von_neumann_neighbors
                                                           get_status_center
                                                           fredkin
                                                           cell_array__val_rml_110
                                                     )
                                             )
                                     )
                             | s__val_rml_112 ->
                                 Lco_ctrl_tree_record.rml_compute
                                   (function
                                     | () ->
                                         Pervasives.raise
                                           (Invalid_argument s__val_rml_112)
                                     )
                             ))
                         (Lco_ctrl_tree_record.rml_if
                           (function | () -> Pervasives.(!) nox )
                           (Lco_ctrl_tree_record.rml_compute
                             (function | () -> () ))
                           (Lco_ctrl_tree_record.rml_loop
                             (Lco_ctrl_tree_record.rml_seq
                               (Lco_ctrl_tree_record.rml_compute
                                 (function | () -> Graphics.synchronize () ))
                               Lco_ctrl_tree_record.rml_pause)))
                   ))
         ):
        (_) Lco_ctrl_tree_record.process) 
;;

module Rml_machine = Rml_machine.M(Lco_ctrl_tree_record);;
let _ = Rml_machine.rml_exec_n main 1000
