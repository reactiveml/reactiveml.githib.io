(**********************************************************************)
(*                        ReactiveML                                  *)
(*                                                                    *)
(* Auteur : Louis Mandel                                              *) 
(* Date de creation : 06/12/2006                                      *)
(* Fichier : rec_implantation.ml                                      *)
(*                                                                    *)
(**********************************************************************)

module Lco_rewrite_record = Lco_rewrite.Rml_interpreter(Sig_env.Record)

