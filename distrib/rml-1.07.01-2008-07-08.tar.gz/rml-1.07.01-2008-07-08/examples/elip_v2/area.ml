(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc area.rml  *)

open Implem;;

open Global
;;


let get_area =
      (function
        | posx__val_rml_2 ->
            (function
              | posy__val_rml_3 ->
                  ((Pervasives.truncate
                     (Pervasives.(/.) posx__val_rml_2 Global.area_size_x)),
                   (Pervasives.truncate
                     (Pervasives.(/.) posy__val_rml_3 Global.area_size_y)))
              )
        ) 
;;


let get_areas =
      (function
        | posx__val_rml_5 ->
            (function
              | posy__val_rml_6 ->
                  (let neighbor_areas__val_rml_7 = Pervasives.ref ([])  in
                    let (center_i__val_rml_8, center_j__val_rml_9) =
                          get_area posx__val_rml_5 posy__val_rml_6
                       in
                      let left__val_rml_10 =
                            Pervasives.truncate
                              (Pervasives.(/.)
                                (Pervasives.(-.)
                                  posx__val_rml_5 Global.coverage_range)
                                Global.area_size_x)
                         in
                        let right__val_rml_11 =
                              Pervasives.truncate
                                (Pervasives.(/.)
                                  (Pervasives.(+.)
                                    posx__val_rml_5 Global.coverage_range)
                                  Global.area_size_x)
                           in
                          let up__val_rml_12 =
                                Pervasives.truncate
                                  (Pervasives.(/.)
                                    (Pervasives.(+.)
                                      posy__val_rml_6 Global.coverage_range)
                                    Global.area_size_y)
                             in
                            let down__val_rml_13 =
                                  Pervasives.truncate
                                    (Pervasives.(/.)
                                      (Pervasives.(-.)
                                        posy__val_rml_6 Global.coverage_range)
                                      Global.area_size_y)
                               in
                              for i__val_ml_14 = left__val_rml_10 to
                                right__val_rml_11 do
                                (if
                                  Pervasives.(&&)
                                    (Pervasives.(<=) 0 i__val_ml_14)
                                    (Pervasives.(<)
                                      i__val_ml_14 Global.nb_area_x)
                                  then
                                  for j__val_ml_15 = down__val_rml_13 to
                                    up__val_rml_12 do
                                    (if
                                      Pervasives.(&&)
                                        (Pervasives.(<=) 0 j__val_ml_15)
                                        (Pervasives.(<)
                                          j__val_ml_15 Global.nb_area_y)
                                      then
                                      if
                                        Pervasives.not
                                          (Pervasives.(&&)
                                            (Pervasives.(=)
                                              i__val_ml_14
                                              center_i__val_rml_8)
                                            (Pervasives.(=)
                                              j__val_ml_15
                                              center_j__val_rml_9))
                                        then
                                        Pervasives.(:=)
                                          neighbor_areas__val_rml_7
                                          ((i__val_ml_14, j__val_ml_15) ::
                                            (Pervasives.(!)
                                              neighbor_areas__val_rml_7))
                                        else ()
                                      else ())
                                    done
                                  else ())
                                done;
                                ((center_i__val_rml_8, center_j__val_rml_9),
                                 (Pervasives.(!) neighbor_areas__val_rml_7)))
              )
        ) 
;;


let make_areas =
      for i__val_ml_17 = 0 to Pervasives.(-) Global.nb_area_x 1 do
        for j__val_ml_18 = 0 to Pervasives.(-) Global.nb_area_y 1 do
          (let msg_hello__sig_19 = Lco_ctrl_tree_record.rml_global_signal () 
            in
            Array.set
              (Array.get Global.hello_array i__val_ml_17)
              j__val_ml_18 msg_hello__sig_19)
          done
        done 
;;

