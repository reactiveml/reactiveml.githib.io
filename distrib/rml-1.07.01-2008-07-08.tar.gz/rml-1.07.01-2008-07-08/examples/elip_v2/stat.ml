(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc stat.rml  *)

open Implem;;

open Global
;;


let instant = Pervasives.ref 0 
;;


let le_packet_cpt = Pervasives.ref 0 
;;


let le_packet_fail_cpt = Pervasives.ref 0 
;;


let le_packet_success_cpt = Pervasives.ref 0 
;;


let elip_packet_cpt = Pervasives.ref 0 
;;


let elip_packet_fail_cpt = Pervasives.ref 0 
;;


let elip_packet_success_cpt = Pervasives.ref 0 
;;


let le_overhead = Pervasives.ref 0. 
;;


let elip_overhead = Pervasives.ref 0. 
;;


let le_route_len = Pervasives.ref 0 
;;


let elip_route_len = Pervasives.ref 0 
;;


let le_nb_anchor = Pervasives.ref 0 
;;


let le_nb_ask = Pervasives.ref 0 
;;


let le_search_level = Pervasives.ref 0 
;;


let elip_nb_anchor = Pervasives.ref 0 
;;


let elip_nb_ask = Pervasives.ref 0 
;;


let elip_search_level = Pervasives.ref 0 
;;


let compute_anchor =
      (function
        | p__val_rml_19 ->
            List.fold_left
              (function
                | (anchor_cpt__val_rml_20,
                   level_cpt__val_rml_21, ask_cpt__val_rml_22) ->
                    (function
                      | (anchor__val_rml_23,
                         info_node_opt__val_rml_24,
                         level__val_rml_25, nb_ask__val_rml_26) ->
                          ((Pervasives.(+) anchor_cpt__val_rml_20 1),
                           (Pervasives.(+)
                             level_cpt__val_rml_21 level__val_rml_25),
                           (Pervasives.(+)
                             ask_cpt__val_rml_22 nb_ask__val_rml_26))
                      )
                )
              (0, 0, 0) (p__val_rml_19).Global.anchors
        ) 
;;


let packet_stat =
      (function
        | p__val_rml_28 ->
            (let (nb_anchor__val_rml_29,
                  level_sum__val_rml_30, nb_ask__val_rml_31) =
                   compute_anchor p__val_rml_28
               in
              match (p__val_rml_28).Global.header with
              | Global.H_LE ->
                  Pervasives.incr le_packet_cpt;
                    Pervasives.(:=)
                      le_route_len
                      (Pervasives.(+)
                        (Pervasives.(!) le_route_len)
                        (List.length (p__val_rml_28).Global.route));
                    Pervasives.(:=)
                      le_overhead
                      (Pervasives.(+.)
                        (Pervasives.(!) le_overhead)
                        (Pervasives.float_of_int
                          (Pervasives.( * )
                            Global.search_overhead
                            (p__val_rml_28).Global.overhead)));
                    Pervasives.(:=)
                      le_nb_anchor
                      (Pervasives.(+)
                        (Pervasives.(!) le_nb_anchor) nb_anchor__val_rml_29);
                    Pervasives.(:=)
                      le_nb_ask
                      (Pervasives.(+)
                        (Pervasives.(!) le_nb_ask) nb_ask__val_rml_31);
                    Pervasives.(:=)
                      le_search_level
                      (Pervasives.(+)
                        (Pervasives.(!) le_search_level)
                        level_sum__val_rml_30)
              | Global.H_ELIP info_opt__val_rml_32 ->
                  Pervasives.incr elip_packet_cpt;
                    Pervasives.(:=)
                      elip_route_len
                      (Pervasives.(+)
                        (Pervasives.(!) elip_route_len)
                        (List.length (p__val_rml_28).Global.route));
                    Pervasives.(:=)
                      elip_overhead
                      (Pervasives.(+.)
                        (Pervasives.(!) elip_overhead)
                        (Pervasives.float_of_int
                          (Pervasives.( * )
                            Global.search_overhead
                            (p__val_rml_28).Global.overhead)));
                    Pervasives.(:=)
                      elip_nb_anchor
                      (Pervasives.(+)
                        (Pervasives.(!) elip_nb_anchor) nb_anchor__val_rml_29);
                    Pervasives.(:=)
                      elip_nb_ask
                      (Pervasives.(+)
                        (Pervasives.(!) elip_nb_ask) nb_ask__val_rml_31);
                    Pervasives.(:=)
                      elip_search_level
                      (Pervasives.(+)
                        (Pervasives.(!) elip_search_level)
                        level_sum__val_rml_30);
                    (match info_opt__val_rml_32 with | None -> ()
                     | Some info__val_rml_33 ->
                         Pervasives.(:=)
                           elip_overhead
                           (Pervasives.(+.)
                             (Pervasives.(!) elip_overhead)
                             (Pervasives.float_of_int
                               (info__val_rml_33).Global.elip_overhead))
                     )
              )
        ) 
;;


let packet_success_stat =
      (function
        | p__val_rml_35 ->
            (match (p__val_rml_35).Global.header with
             | Global.H_LE -> Pervasives.incr le_packet_success_cpt
             | Global.H_ELIP (_) -> Pervasives.incr elip_packet_success_cpt );
              packet_stat p__val_rml_35
        ) 
;;


let packet_fail_stat =
      (function
        | p__val_rml_37 ->
            (match (p__val_rml_37).Global.header with
             | Global.H_LE -> Pervasives.incr le_packet_fail_cpt
             | Global.H_ELIP (_) -> Pervasives.incr elip_packet_fail_cpt );
              packet_stat p__val_rml_37
        ) 
;;


let reset =
      (function
        | () ->
            Pervasives.(:=) le_packet_cpt 0;
              Pervasives.(:=) le_packet_fail_cpt 0;
              Pervasives.(:=) le_packet_success_cpt 0;
              Pervasives.(:=) elip_packet_cpt 0;
              Pervasives.(:=) elip_packet_fail_cpt 0;
              Pervasives.(:=) elip_packet_success_cpt 0;
              Pervasives.(:=) le_route_len 0;
              Pervasives.(:=) elip_route_len 0;
              Pervasives.(:=) le_nb_anchor 0; Pervasives.(:=) le_nb_ask 0;
              Pervasives.(:=) le_search_level 0;
              Pervasives.(:=) elip_nb_anchor 0; Pervasives.(:=) elip_nb_ask 0;
              Pervasives.(:=) elip_search_level 0
        ) 
;;


let output_overhead =
      (function
        | overhead_ch__val_rml_40 ->
            Pervasives.output_string
              overhead_ch__val_rml_40
              (Pervasives.(^)
                (Pervasives.string_of_int (Pervasives.(!) instant))
                (Pervasives.(^)
                  "\t"
                  (Pervasives.(^)
                    (Pervasives.string_of_float (Pervasives.(!) le_overhead))
                    (Pervasives.(^)
                      "\t"
                      (Pervasives.(^)
                        (Pervasives.string_of_float
                          (Pervasives.(!) elip_overhead))
                        (Pervasives.(^)
                          "\t"
                          (Pervasives.(^)
                            (Pervasives.string_of_float
                              (Pervasives.(-.)
                                (Pervasives.(!) elip_overhead)
                                (Pervasives.(!) le_overhead)))
                            (Pervasives.(^)
                              "\t"
                              (Pervasives.(^)
                                (Pervasives.string_of_float
                                  (Pervasives.(/.)
                                    (Pervasives.(!) elip_overhead)
                                    (Pervasives.(!) le_overhead)))
                                "\n")))))))));
              Pervasives.flush overhead_ch__val_rml_40
        ) 
;;


let output_route_len =
      (function
        | route_len_ch__val_rml_42 ->
            (let le_avg__val_rml_43 =
                   Pervasives.(/.)
                     (Pervasives.float_of_int (Pervasives.(!) le_route_len))
                     (Pervasives.float_of_int (Pervasives.(!) le_packet_cpt))
               in
              let elip_avg__val_rml_44 =
                    Pervasives.(/.)
                      (Pervasives.float_of_int
                        (Pervasives.(!) elip_route_len))
                      (Pervasives.float_of_int
                        (Pervasives.(!) elip_packet_cpt))
                 in
                Pervasives.output_string
                  route_len_ch__val_rml_42
                  (Pervasives.(^)
                    (Pervasives.string_of_int (Pervasives.(!) instant))
                    (Pervasives.(^)
                      "\t"
                      (Pervasives.(^)
                        (Pervasives.string_of_float le_avg__val_rml_43)
                        (Pervasives.(^)
                          "\t"
                          (Pervasives.(^)
                            (Pervasives.string_of_float elip_avg__val_rml_44)
                            "\n")))));
                  Pervasives.flush route_len_ch__val_rml_42)
        ) 
;;


let output_anchor =
      (function
        | anchor_ch__val_rml_46 ->
            (let le_nb_anchor_avg__val_rml_47 =
                   Pervasives.(/.)
                     (Pervasives.float_of_int (Pervasives.(!) le_nb_anchor))
                     (Pervasives.float_of_int (Pervasives.(!) le_packet_cpt))
               in
              let elip_nb_anchor_avg__val_rml_48 =
                    Pervasives.(/.)
                      (Pervasives.float_of_int
                        (Pervasives.(!) elip_nb_anchor))
                      (Pervasives.float_of_int
                        (Pervasives.(!) elip_packet_cpt))
                 in
                Pervasives.output_string
                  anchor_ch__val_rml_46
                  (Pervasives.(^)
                    (Pervasives.string_of_int (Pervasives.(!) instant))
                    (Pervasives.(^)
                      "\t"
                      (Pervasives.(^)
                        (Pervasives.string_of_float
                          (Pervasives.(/.)
                            elip_nb_anchor_avg__val_rml_48
                            le_nb_anchor_avg__val_rml_47))
                        (Pervasives.(^)
                          "\t"
                          (Pervasives.(^)
                            (Pervasives.string_of_float
                              (Pervasives.(/.)
                                (Pervasives.float_of_int
                                  (Pervasives.(!) elip_nb_ask))
                                (Pervasives.float_of_int
                                  (Pervasives.(!) le_nb_ask))))
                            (Pervasives.(^)
                              "\t"
                              (Pervasives.(^)
                                (Pervasives.string_of_float
                                  (Pervasives.(/.)
                                    (Pervasives.float_of_int
                                      (Pervasives.(!) elip_search_level))
                                    (Pervasives.float_of_int
                                      (Pervasives.(!) le_search_level))))
                                "\n")))))));
                  Pervasives.flush anchor_ch__val_rml_46)
        ) 
;;


let output_age_nb =
      (function
        | ch__val_rml_50 ->
            (function
              | l__val_rml_51 ->
                  Pervasives.output_string
                    ch__val_rml_50
                    (Pervasives.(^)
                      (Pervasives.string_of_int (Pervasives.(!) instant))
                      "\t");
                    List.iter
                      (function
                        | (dist__val_rml_52, age__val_rml_53, nb__val_rml_54) ->
                            Pervasives.output_string
                              ch__val_rml_50
                              (Pervasives.(^)
                                (Pervasives.string_of_int age__val_rml_53)
                                (Pervasives.(^)
                                  "\t"
                                  (Pervasives.(^)
                                    (Pervasives.string_of_int nb__val_rml_54)
                                    "\t")))
                        )
                      l__val_rml_51;
                    Pervasives.output_string ch__val_rml_50 "\n";
                    Pervasives.flush ch__val_rml_50
              )
        ) 
;;


let instant_stat =
      (function
        | overhead_ch__val_rml_56 ->
            (function
              | route_len_ch__val_rml_57 ->
                  (function
                    | anchor_ch__val_rml_58 ->
                        output_overhead overhead_ch__val_rml_56;
                          output_route_len route_len_ch__val_rml_57;
                          output_anchor anchor_ch__val_rml_58;
                          Pervasives.incr instant; reset ()
                    )
              )
        ) 
;;


let stat =
      (function
        | start__val_rml_60 ->
            ((function
               | () ->
                   Lco_ctrl_tree_record.rml_def
                     (function
                       | () ->
                           Pervasives.open_out
                             (Pervasives.(^) Global.prefix "overhead")
                       )
                     (function
                       | overhead_ch__val_rml_61 ->
                           Lco_ctrl_tree_record.rml_def
                             (function
                               | () ->
                                   Pervasives.open_out
                                     (Pervasives.(^)
                                       Global.prefix "route_len")
                               )
                             (function
                               | route_len_ch__val_rml_62 ->
                                   Lco_ctrl_tree_record.rml_def
                                     (function
                                       | () ->
                                           Pervasives.open_out
                                             (Pervasives.(^)
                                               Global.prefix "anchor")
                                       )
                                     (function
                                       | anchor_ch__val_rml_63 ->
                                           Lco_ctrl_tree_record.rml_loop
                                             (Lco_ctrl_tree_record.rml_seq
                                               (Lco_ctrl_tree_record.rml_seq
                                                 Lco_ctrl_tree_record.rml_pause
                                                 (Lco_ctrl_tree_record.rml_await_immediate'
                                                   start__val_rml_60))
                                               (Lco_ctrl_tree_record.rml_compute
                                                 (function
                                                   | () ->
                                                       instant_stat
                                                         overhead_ch__val_rml_61
                                                         route_len_ch__val_rml_62
                                                         anchor_ch__val_rml_63
                                                   )))
                                       )
                               )
                       )
               ):
              (_) Lco_ctrl_tree_record.process)
        ) 
;;

