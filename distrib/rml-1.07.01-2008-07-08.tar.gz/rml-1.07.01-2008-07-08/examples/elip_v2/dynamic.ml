(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc dynamic.rml  *)

open Implem;;

open Position
;;


open Global
;;


open Node
;;


let rec kill_me =
          (function
            | id__val_rml_2 ->
                (function
                  | kill__val_rml_3 ->
                      (function
                        | local_kill__val_rml_4 ->
                            ((function
                               | () ->
                                   Lco_ctrl_tree_record.rml_await_all
                                     (function | () -> kill__val_rml_3 )
                                     (function
                                       | k__val_rml_5 ->
                                           Lco_ctrl_tree_record.rml_if
                                             (function
                                               | () ->
                                                   List.mem
                                                     id__val_rml_2
                                                     k__val_rml_5
                                               )
                                             (Lco_ctrl_tree_record.rml_compute
                                               (function
                                                 | () ->
                                                     Lco_ctrl_tree_record.rml_expr_emit
                                                       local_kill__val_rml_4
                                                 ))
                                             (Lco_ctrl_tree_record.rml_run
                                               (function
                                                 | () ->
                                                     kill_me
                                                       id__val_rml_2
                                                       kill__val_rml_3
                                                       local_kill__val_rml_4
                                                 ))
                                       )
                               ):
                              (_) Lco_ctrl_tree_record.process)
                        )
                  )
            ) 
;;


let preemptible_node =
      (function
        | id__val_rml_7 ->
            (function
              | pos_init__val_rml_8 ->
                  (function
                    | kill__val_rml_9 ->
                        ((function
                           | () ->
                               Lco_ctrl_tree_record.rml_signal
                                 (function
                                   | local_kill__sig_10 ->
                                       Lco_ctrl_tree_record.rml_par
                                         (Lco_ctrl_tree_record.rml_until'
                                           local_kill__sig_10
                                           (Lco_ctrl_tree_record.rml_run
                                             (function
                                               | () ->
                                                   Node.node
                                                     id__val_rml_7
                                                     pos_init__val_rml_8
                                               )))
                                         (Lco_ctrl_tree_record.rml_run
                                           (function
                                             | () ->
                                                 kill_me
                                                   id__val_rml_7
                                                   kill__val_rml_9
                                                   local_kill__sig_10
                                             ))
                                   )
                           ):
                          (_) Lco_ctrl_tree_record.process)
                    )
              )
        ) 
;;


let rec add =
          (function
            | new_node__val_rml_12 ->
                (function
                  | start__val_rml_13 ->
                      ((function
                         | () ->
                             Lco_ctrl_tree_record.rml_await_one
                               (function | () -> new_node__val_rml_12 )
                               (function
                                 | pos__val_rml_14 ->
                                     Lco_ctrl_tree_record.rml_par
                                       (Lco_ctrl_tree_record.rml_run
                                         (function
                                           | () ->
                                               add
                                                 new_node__val_rml_12
                                                 start__val_rml_13
                                           ))
                                       (Lco_ctrl_tree_record.rml_seq
                                         (Lco_ctrl_tree_record.rml_await_immediate'
                                           start__val_rml_13)
                                         (Lco_ctrl_tree_record.rml_def
                                           (function
                                             | () ->
                                                 {Position.x=(if
                                                               Pervasives.(>)
                                                                 (pos__val_rml_14).Position.x
                                                                 0.
                                                               then
                                                               Pervasives.min
                                                                 (pos__val_rml_14).Position.x
                                                                 Global.max_x
                                                               else 0.);
                                                  Position.y=(if
                                                               Pervasives.(>)
                                                                 (pos__val_rml_14).Position.y
                                                                 0.
                                                               then
                                                               Pervasives.min
                                                                 (pos__val_rml_14).Position.y
                                                                 Global.max_y
                                                               else 0.)}
                                             )
                                           (function
                                             | pos__val_rml_15 ->
                                                 Lco_ctrl_tree_record.rml_run
                                                   (function
                                                     | () ->
                                                         Node.node
                                                           (Global.get_new_id
                                                             ())
                                                           pos__val_rml_15
                                                     )
                                             )))
                                 )
                         ):
                        (_) Lco_ctrl_tree_record.process)
                  )
            ) 
;;

