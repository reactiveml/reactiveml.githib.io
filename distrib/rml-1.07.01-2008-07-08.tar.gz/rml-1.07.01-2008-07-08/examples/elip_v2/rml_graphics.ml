(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc rml_graphics.rml  *)

open Implem;;

let read_click =
      (function
        | click__val_rml_2 ->
            ((function
               | () ->
                   Lco_ctrl_tree_record.rml_loop
                     (Lco_ctrl_tree_record.rml_def
                       (function | () -> Graphics.mouse_pos () )
                       (function
                         | (pos_x__val_rml_3, pos_y__val_rml_4) ->
                             Lco_ctrl_tree_record.rml_seq
                               (Lco_ctrl_tree_record.rml_compute
                                 (function
                                   | () ->
                                       if Graphics.button_down () then
                                         Lco_ctrl_tree_record.rml_expr_emit_val
                                           click__val_rml_2
                                           ((Pervasives.float_of_int
                                              pos_x__val_rml_3),
                                            (Pervasives.float_of_int
                                              pos_y__val_rml_4))
                                         else ()
                                   ))
                               Lco_ctrl_tree_record.rml_pause
                         ))
               ):
              (_) Lco_ctrl_tree_record.process)
        ) 
;;


let read_key =
      (function
        | key__val_rml_6 ->
            ((function
               | () ->
                   Lco_ctrl_tree_record.rml_loop
                     (Lco_ctrl_tree_record.rml_seq
                       (Lco_ctrl_tree_record.rml_compute
                         (function
                           | () ->
                               if Graphics.key_pressed () then
                                 Lco_ctrl_tree_record.rml_expr_emit_val
                                   key__val_rml_6 (Graphics.read_key ())
                                 else ()
                           ))
                       Lco_ctrl_tree_record.rml_pause)
               ):
              (_) Lco_ctrl_tree_record.process)
        ) 
;;

