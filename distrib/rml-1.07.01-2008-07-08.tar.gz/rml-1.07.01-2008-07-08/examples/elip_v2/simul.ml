(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc -s main -n -1 -sampling -1 simul.rml  *)

open Implem;;

open Position
;;


open Global
;;


open Node
;;


open Draw
;;


Pervasives.(:=)
  Global.init_make_move
  (function
    | pos__val_rml_1 ->
        Move.rwp (Pervasives.( *. ) 4. Global.coverage_range) pos__val_rml_1
    );
  Pervasives.(:=) Global.init_make_make_msg (function | () -> Msg.make_msg );
  Pervasives.(:=)
    Global.init_make_insert_elip_info
    (function | pos__val_rml_2 -> Msg.insert_proba )
;;


let make_nodes =
      (function
        | n__val_rml_4 ->
            ((function
               | () ->
                   Lco_ctrl_tree_record.rml_fordopar
                     (function | () -> 1 )
                     (function | () -> n__val_rml_4 )
                     true
                     (function
                       | i__val_rml_5 ->
                           Lco_ctrl_tree_record.rml_def
                             (function
                               | () ->
                                   {Position.x=(Random.float Global.max_x);
                                    Position.y=(Random.float Global.max_y)}
                               )
                             (function
                               | pos__val_rml_6 ->
                                   Lco_ctrl_tree_record.rml_run
                                     (function
                                       | () ->
                                           Node.node
                                             (Global.get_new_id ())
                                             pos__val_rml_6
                                       )
                               )
                       )
               ):
              (_) Lco_ctrl_tree_record.process)
        ) 
;;


let make_preemptible_nodes =
      (function
        | n__val_rml_8 ->
            (function
              | kill__val_rml_9 ->
                  ((function
                     | () ->
                         Lco_ctrl_tree_record.rml_fordopar
                           (function | () -> 1 )
                           (function | () -> n__val_rml_8 )
                           true
                           (function
                             | i__val_rml_10 ->
                                 Lco_ctrl_tree_record.rml_def
                                   (function
                                     | () ->
                                         {Position.x=(Random.float
                                                       Global.max_x);
                                          Position.y=(Random.float
                                                       Global.max_y)}
                                     )
                                   (function
                                     | pos__val_rml_11 ->
                                         Lco_ctrl_tree_record.rml_run
                                           (function
                                             | () ->
                                                 Dynamic.preemptible_node
                                                   (Global.get_new_id ())
                                                   pos__val_rml_11
                                                   kill__val_rml_9
                                             )
                                     )
                             )
                     ):
                    (_) Lco_ctrl_tree_record.process)
              )
        ) 
;;


let main =
      ((function
         | () ->
             Lco_ctrl_tree_record.rml_seq
               (Lco_ctrl_tree_record.rml_compute
                 (function | () -> Area.make_areas ))
               (Lco_ctrl_tree_record.rml_signal
                 (function
                   | suspend__sig_13 ->
                       Lco_ctrl_tree_record.rml_signal
                         (function
                           | start__sig_14 ->
                               Lco_ctrl_tree_record.rml_signal
                                 (function
                                   | new_node__sig_15 ->
                                       Lco_ctrl_tree_record.rml_signal
                                         (function
                                           | kill__sig_16 ->
                                               Lco_ctrl_tree_record.rml_par_n
                                                 ((Lco_ctrl_tree_record.rml_control'
                                                    suspend__sig_13
                                                    (Lco_ctrl_tree_record.rml_par_n
                                                      ((Lco_ctrl_tree_record.rml_seq
                                                         (Lco_ctrl_tree_record.rml_run
                                                           (function
                                                             | () ->
                                                                 make_preemptible_nodes
                                                                   Global.nb_nodes
                                                                   kill__sig_16
                                                             ))
                                                         Lco_ctrl_tree_record.rml_nothing)
                                                        ::
                                                        ((Lco_ctrl_tree_record.rml_seq
                                                           (Lco_ctrl_tree_record.rml_run
                                                             (function
                                                               | () ->
                                                                   Dynamic.add
                                                                    new_node__sig_15
                                                                    start__sig_14
                                                               ))
                                                           Lco_ctrl_tree_record.rml_nothing)
                                                          ::
                                                          ((Lco_ctrl_tree_record.rml_loop
                                                             (Lco_ctrl_tree_record.rml_seq
                                                               (Lco_ctrl_tree_record.rml_seq
                                                                 (Lco_ctrl_tree_record.rml_seq
                                                                   (Lco_ctrl_tree_record.rml_emit'
                                                                    start__sig_14)
                                                                   Lco_ctrl_tree_record.rml_pause)
                                                                 Lco_ctrl_tree_record.rml_pause)
                                                               Lco_ctrl_tree_record.rml_pause))
                                                            ::
                                                            ((Lco_ctrl_tree_record.rml_seq
                                                               (Lco_ctrl_tree_record.rml_if
                                                                 (function
                                                                   | 
                                                                   () ->
                                                                    Global.with_stat
                                                                   )
                                                                 (Lco_ctrl_tree_record.rml_run
                                                                   (function
                                                                    | 
                                                                    () ->
                                                                    Stat.stat
                                                                    start__sig_14
                                                                    ))
                                                                 (Lco_ctrl_tree_record.rml_compute
                                                                   (function
                                                                    | 
                                                                    () -> 
                                                                    () )))
                                                               Lco_ctrl_tree_record.rml_nothing)
                                                              :: ([])))))))
                                                   ::
                                                   ((Lco_ctrl_tree_record.rml_seq
                                                      (Lco_ctrl_tree_record.rml_if
                                                        (function
                                                          | () ->
                                                              Global.with_graphics
                                                          )
                                                        (Lco_ctrl_tree_record.rml_run
                                                          (function
                                                            | () ->
                                                                Draw.draw_simul
                                                                  Global.draw
                                                                  suspend__sig_13
                                                                  new_node__sig_15
                                                                  kill__sig_16
                                                            ))
                                                        (Lco_ctrl_tree_record.rml_compute
                                                          (function
                                                            | () -> () )))
                                                      Lco_ctrl_tree_record.rml_nothing)
                                                     ::
                                                     ((Lco_ctrl_tree_record.rml_seq
                                                        (Lco_ctrl_tree_record.rml_if
                                                          (function
                                                            | () ->
                                                                Pervasives.(>)
                                                                  Global.nb_instants
                                                                  0
                                                            )
                                                          (Lco_ctrl_tree_record.rml_def
                                                            (function
                                                              | () ->
                                                                  Unix.time
                                                                    ()
                                                              )
                                                            (function
                                                              | t_init__val_rml_17 ->
                                                                  Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_loop_n
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(+)
                                                                    (Pervasives.(-)
                                                                    (Pervasives.( * )
                                                                    Global.nb_instants
                                                                    3) 
                                                                    1) 
                                                                    1 )
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    (let 
                                                                    t_fin__val_rml_19
                                                                    =
                                                                    Unix.time
                                                                    ()  in
                                                                    let 
                                                                    proc_time__val_rml_20
                                                                    =
                                                                    Sys.time
                                                                    ()  in
                                                                    let 
                                                                    gc_stat__val_rml_21
                                                                    =
                                                                    Gc.stat
                                                                    ()  in
                                                                    Pervasives.print_int
                                                                    Global.nb_nodes;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    Global.max_x;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    Global.coverage_range;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    Global.area_size_x;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    (Pervasives.(-.)
                                                                    t_fin__val_rml_19
                                                                    t_init__val_rml_17);
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    proc_time__val_rml_20;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_int
                                                                    (gc_stat__val_rml_21).Gc.top_heap_words;
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    (Pervasives.(/.)
                                                                    (Pervasives.(-.)
                                                                    t_fin__val_rml_19
                                                                    t_init__val_rml_17)
                                                                    (Pervasives.float_of_int
                                                                    Global.nb_instants));
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_float
                                                                    (Pervasives.(/.)
                                                                    proc_time__val_rml_20
                                                                    (Pervasives.float_of_int
                                                                    Global.nb_instants));
                                                                    Pervasives.print_char
                                                                    '	';
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.exit
                                                                    0) ))
                                                              ))
                                                          (Lco_ctrl_tree_record.rml_compute
                                                            (function
                                                              | () -> () )))
                                                        Lco_ctrl_tree_record.rml_nothing)
                                                       :: ([]))))
                                           )
                                   )
                           )
                   ))
         ):
        (_) Lco_ctrl_tree_record.process) 
;;

module Rml_machine = Rml_machine.M(Lco_ctrl_tree_record);;
let _ = Rml_machine.rml_exec main
