(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc init.rml  *)

open Implem;;

let nb_instants = Pervasives.ref (-1) 
;;


let max_x = Pervasives.ref 1000. 
;;


let max_y = Pervasives.ref 1000. 
;;


let area_size_x = Pervasives.ref 80. 
;;


let area_size_y = Pervasives.ref 80. 
;;


let nb_nodes = Pervasives.ref 500 
;;


let coverage_range = Pervasives.ref 80. 
;;


let speed = Pervasives.ref 1. 
;;


let speed_min = Pervasives.ref 1.3889 
;;


let speed_max = Pervasives.ref 5.5556 
;;


let pause_min = Pervasives.ref 0 
;;


let pause_max = Pervasives.ref 10 
;;


let elip_proba = Pervasives.ref 100. 
;;


let elip_forecast = Pervasives.ref 0 
;;


let elip_min_insert_dist = Pervasives.ref 1. 
;;


let elip_min_insert_angle = Pervasives.ref 90. 
;;


let msg_proba = Pervasives.ref 50. 
;;


let msg_len = Pervasives.ref 1 
;;


let search_overhead = Pervasives.ref 1 
;;


let with_graphics = Pervasives.ref true 
;;


let zoom = Pervasives.ref 1. 
;;


let prefix = Pervasives.ref "simul" 
;;


let with_stat = Pervasives.ref false 
;;


let option_set =
      (function
        | r__val_rml_25 ->
            (function
              | v__val_rml_26 ->
                  Pervasives.(:=) r__val_rml_25 (Some v__val_rml_26)
              )
        ) 
;;


let set_option =
      (function
        | r__val_rml_28 ->
            (function
              | v_opt__val_rml_29 ->
                  (match v_opt__val_rml_29 with | None -> ()
                   | Some v__val_rml_30 ->
                       Pervasives.(:=) r__val_rml_28 v__val_rml_30
                   )
              )
        ) 
;;


let set_size =
      (function
        | t__val_rml_32 ->
            set_option max_x t__val_rml_32; set_option max_y t__val_rml_32
        ) 
;;


let set_prefix =
      (function
        | s__val_rml_34 ->
            (match s__val_rml_34 with
             | Some pref__val_rml_35 ->
                 Pervasives.(:=) with_stat true;
                   Pervasives.(:=) prefix pref__val_rml_35
             | None -> () )
        ) 
;;


let set_density =
      (function
        | d__val_rml_37 ->
            (let surface__val_rml_38 =
                   Pervasives.( *. )
                     (Pervasives.(!) max_x) (Pervasives.(!) max_y)
               in
              let range__val_rml_39 =
                    Pervasives.sqrt
                      (Pervasives.(/.)
                        (Pervasives.( *. ) d__val_rml_37 surface__val_rml_38)
                        (Pervasives.( *. )
                          3.14
                          (Pervasives.float_of_int (Pervasives.(!) nb_nodes))))
                 in Pervasives.(:=) coverage_range range__val_rml_39)
        ) 
;;


let set_with_graphics =
      (function
        | r__val_rml_41 ->
            (function
              | v_opt__val_rml_42 ->
                  (match v_opt__val_rml_42 with | None -> ()
                   | Some v__val_rml_43 ->
                       Pervasives.(:=)
                         r__val_rml_41 (Pervasives.not v__val_rml_43)
                   )
              )
        ) 
;;


let set_area =
      (function
        | t_opt__val_rml_45 ->
            (match t_opt__val_rml_45 with
             | None ->
                 Pervasives.(:=)
                   area_size_x
                   (Pervasives.( *. ) 2. (Pervasives.(!) coverage_range));
                   Pervasives.(:=)
                     area_size_y
                     (Pervasives.( *. ) 2. (Pervasives.(!) coverage_range))
             | Some t__val_rml_46 ->
                 Pervasives.(:=) area_size_x t__val_rml_46;
                   Pervasives.(:=) area_size_y t__val_rml_46
             )
        ) 
;;


let set_speed =
      (function
        | s__val_rml_48 ->
            (function
              | delta__val_rml_49 ->
                  (let av_speed__val_rml_50 =
                         Pervasives.(/.)
                           (Pervasives.(+.)
                             (Pervasives.(!) speed_max)
                             (Pervasives.(!) speed_min))
                           2.
                     in
                    let delta__val_rml_51 =
                          (match delta__val_rml_49 with
                           | None ->
                               Pervasives.(/.)
                                 (Pervasives.(-.)
                                   (Pervasives.(!) speed_max)
                                   (Pervasives.(!) speed_min))
                                 2.
                           | Some d__val_rml_52 -> d__val_rml_52 )
                       in
                      match s__val_rml_48 with
                      | None ->
                          Pervasives.(:=) speed av_speed__val_rml_50;
                            Pervasives.(:=)
                              speed_min
                              (Pervasives.(-.)
                                av_speed__val_rml_50 delta__val_rml_51);
                            Pervasives.(:=)
                              speed_max
                              (Pervasives.(+.)
                                av_speed__val_rml_50 delta__val_rml_51)
                      | Some s__val_rml_53 ->
                          Pervasives.(:=) speed s__val_rml_53;
                            Pervasives.(:=)
                              speed_min
                              (Pervasives.(-.)
                                s__val_rml_53 delta__val_rml_51);
                            Pervasives.(:=)
                              speed_max
                              (Pervasives.(+.)
                                s__val_rml_53 delta__val_rml_51)
                      )
              )
        ) 
;;


let set_pause =
      (function
        | p__val_rml_55 ->
            (function
              | delta__val_rml_56 ->
                  (let av_pause__val_rml_57 =
                         Pervasives.(/)
                           (Pervasives.(+)
                             (Pervasives.(!) pause_max)
                             (Pervasives.(!) pause_min))
                           2
                     in
                    let delta__val_rml_58 =
                          (match delta__val_rml_56 with
                           | None ->
                               Pervasives.(/)
                                 (Pervasives.(-)
                                   (Pervasives.(!) pause_max)
                                   (Pervasives.(!) pause_min))
                                 2
                           | Some d__val_rml_59 -> d__val_rml_59 )
                       in
                      match p__val_rml_55 with
                      | None ->
                          Pervasives.(:=)
                            pause_min
                            (Pervasives.(-)
                              av_pause__val_rml_57 delta__val_rml_58);
                            Pervasives.(:=)
                              pause_max
                              (Pervasives.(+)
                                av_pause__val_rml_57 delta__val_rml_58)
                      | Some p__val_rml_60 ->
                          Pervasives.(:=)
                            pause_min
                            (Pervasives.(-) p__val_rml_60 delta__val_rml_58);
                            Pervasives.(:=)
                              pause_max
                              (Pervasives.(+)
                                p__val_rml_60 delta__val_rml_58)
                      )
              )
        ) 
;;


let configure =
      (function
        | () ->
            (let var_N__val_rml_83 = Pervasives.ref None  and
                 var_D__val_rml_84 = Pervasives.ref None  and
                 var_n__val_rml_85 = Pervasives.ref None  and
                 var_t__val_rml_86 = Pervasives.ref None  and
                 var_range__val_rml_87 = Pervasives.ref None  and
                 var_area__val_rml_88 = Pervasives.ref None  and
                 var_o__val_rml_89 = Pervasives.ref None  and
                 var_msg_proba__val_rml_90 = Pervasives.ref None  and
                 var_msg_len__val_rml_91 = Pervasives.ref None  and
                 var_elip_proba__val_rml_92 = Pervasives.ref None  and
                 var_elip_min_insert_dist__val_rml_93 = Pervasives.ref None 
                 and
                 var_elip_min_insert_angle__val_rml_94 = Pervasives.ref None 
                 and
                 var_node__val_rml_95 = Pervasives.ref None  and
                 var_seed__val_rml_96 = Pervasives.ref None  and
                 var_zoom__val_rml_97 = Pervasives.ref None  and
                 var_speed__val_rml_98 = Pervasives.ref None  and
                 var_delta_speed__val_rml_99 = Pervasives.ref None  and
                 var_pause__val_rml_100 = Pervasives.ref None  and
                 var_delta_pause__val_rml_101 = Pervasives.ref None 
              in
              Arg.parse
                (("-N",
                  (Arg.Int (option_set var_N__val_rml_83)),
                  "<nb> nombre d'instant de smulation") ::
                  (("-n",
                    (Arg.Int (option_set var_n__val_rml_85)),
                    "<nb> nombre de noeuds dans la topologie") ::
                    (("-t",
                      (Arg.Float (option_set var_t__val_rml_86)),
                      "<longueur> longueur d'un cote") ::
                      (("-range",
                        (Arg.Float (option_set var_range__val_rml_87)),
                        "<r> rayon de couverture") ::
                        (("-D",
                          (Arg.Float (option_set var_D__val_rml_84)),
                          "<density> densit\233 par zone de couverture") ::
                          (("-area",
                            (Arg.Float (option_set var_area__val_rml_88)),
                            "<longueur> longueur d'un cote d'une area") ::
                            (("-msg_proba",
                              (Arg.Float
                                (option_set var_msg_proba__val_rml_90)),
                              "<p> probabilit\233 d'\233mission d'un message")
                              ::
                              (("-msg_len",
                                (Arg.Int
                                  (option_set var_msg_len__val_rml_91)),
                                "<n> longueur max d'un message") ::
                                (("-elip_proba",
                                  (Arg.Float
                                    (option_set var_elip_proba__val_rml_92)),
                                  "<f> probabilit\233 d'insertion d'une info de elip")
                                  ::
                                  (("-elip_min_insert_dist",
                                    (Arg.Float
                                      (option_set
                                        var_elip_min_insert_dist__val_rml_93)),
                                    "<n> distance minimale d'insertion d'une info de \n\telip en nb de rayons de couverture")
                                    ::
                                    (("-elip_min_insert_angle",
                                      (Arg.Float
                                        (option_set
                                          var_elip_min_insert_angle__val_rml_94)),
                                      "<n> angle minimal d'insertion d'une info de elip")
                                      ::
                                      (("-o",
                                        (Arg.String
                                          (option_set var_o__val_rml_89)),
                                        "<pref> calcul des stats (<pref> est le pr\233fixe des fichiers de sortie)")
                                        ::
                                        (("-nox",
                                          (Arg.Clear with_graphics),
                                          " sans mode graphique") ::
                                          (("-node",
                                            (Arg.Int
                                              (option_set
                                                var_node__val_rml_95)),
                                            "<n> numero du noeud observ\233")
                                            ::
                                            (("-seed",
                                              (Arg.Int
                                                (option_set
                                                  var_seed__val_rml_96)),
                                              "<n> initialisation du random")
                                              ::
                                              (("-z",
                                                (Arg.Float
                                                  (option_set
                                                    var_zoom__val_rml_97)),
                                                "<f> zoom lors de l'affichage")
                                                ::
                                                (("-speed",
                                                  (Arg.Float
                                                    (option_set
                                                      var_speed__val_rml_98)),
                                                  "<f> vitesse rwp") ::
                                                  (("-pause",
                                                    (Arg.Int
                                                      (option_set
                                                        var_pause__val_rml_100)),
                                                    "<n> pause rwp") ::
                                                    (("-delta_speed",
                                                      (Arg.Float
                                                        (option_set
                                                          var_delta_speed__val_rml_99)),
                                                      "<f> diff\233rence vitesse rwp")
                                                      ::
                                                      (("-delta_pause",
                                                        (Arg.Int
                                                          (option_set
                                                            var_delta_pause__val_rml_101)),
                                                        "<n> diff\233rence pause rwp")
                                                        :: ([])))))))))))))))))))))
                (function
                  | s__val_rml_102 ->
                      Pervasives.raise (Invalid_argument s__val_rml_102)
                  )
                "Options are:";
                if
                  Pervasives.(&&)
                    (Pervasives.(<>) (Pervasives.(!) var_D__val_rml_84) None)
                    (Pervasives.(<>)
                      (Pervasives.(!) var_range__val_rml_87) None)
                  then Pervasives.failwith "-D and -range are not compatible"
                  else ();
                set_option nb_instants (Pervasives.(!) var_N__val_rml_83);
                set_option nb_nodes (Pervasives.(!) var_n__val_rml_85);
                set_size (Pervasives.(!) var_t__val_rml_86);
                set_option
                  coverage_range (Pervasives.(!) var_range__val_rml_87);
                (match Pervasives.(!) var_D__val_rml_84 with | None -> ()
                 | Some d__val_rml_103 -> set_density d__val_rml_103 );
                set_area (Pervasives.(!) var_area__val_rml_88);
                set_option
                  elip_proba (Pervasives.(!) var_elip_proba__val_rml_92);
                set_prefix (Pervasives.(!) var_o__val_rml_89);
                set_option
                  msg_proba (Pervasives.(!) var_msg_proba__val_rml_90);
                set_option msg_len (Pervasives.(!) var_msg_len__val_rml_91);
                set_option
                  elip_min_insert_dist
                  (Pervasives.(!) var_elip_min_insert_dist__val_rml_93);
                set_option
                  elip_min_insert_angle
                  (Pervasives.(!) var_elip_min_insert_angle__val_rml_94);
                set_option zoom (Pervasives.(!) var_zoom__val_rml_97);
                set_speed
                  (Pervasives.(!) var_speed__val_rml_98)
                  (Pervasives.(!) var_delta_speed__val_rml_99);
                set_pause
                  (Pervasives.(!) var_pause__val_rml_100)
                  (Pervasives.(!) var_delta_pause__val_rml_101);
                (match Pervasives.(!) var_seed__val_rml_96 with
                 | None -> Random.self_init ()
                 | Some seed__val_rml_104 -> Random.init seed__val_rml_104 ))
        ) 
;;

