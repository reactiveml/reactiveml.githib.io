(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc move.rml  *)

open Implem;;

open Position
;;


open Global
;;


let translate =
      (function
        | pos__val_rml_2 ->
            (function
              | dir__val_rml_3 ->
                  (function
                    | speed__val_rml_4 ->
                        (let x__val_rml_5 = (pos__val_rml_2).Position.x  in
                          let y__val_rml_6 = (pos__val_rml_2).Position.y  in
                            match dir__val_rml_3 with
                            | 0 ->
                                {Position.x=(x__val_rml_5);
                                 Position.y=(Pervasives.min
                                              (Pervasives.(+.)
                                                y__val_rml_6 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_y 1.))}
                            | 1 ->
                                {Position.x=(Pervasives.min
                                              (Pervasives.(+.)
                                                x__val_rml_5 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_x 1.));
                                 Position.y=(Pervasives.min
                                              (Pervasives.(+.)
                                                y__val_rml_6 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_y 1.))}
                            | 2 ->
                                {Position.x=(Pervasives.min
                                              (Pervasives.(+.)
                                                x__val_rml_5 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_x 1.));
                                 Position.y=(y__val_rml_6)}
                            | 3 ->
                                {Position.x=(Pervasives.min
                                              (Pervasives.(+.)
                                                x__val_rml_5 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_x 1.));
                                 Position.y=(Pervasives.max
                                              (Pervasives.(-.)
                                                y__val_rml_6 speed__val_rml_4)
                                              0.)}
                            | 4 ->
                                {Position.x=(x__val_rml_5);
                                 Position.y=(Pervasives.max
                                              (Pervasives.(-.)
                                                y__val_rml_6 speed__val_rml_4)
                                              0.)}
                            | 5 ->
                                {Position.x=(Pervasives.max
                                              (Pervasives.(-.)
                                                x__val_rml_5 speed__val_rml_4)
                                              0.);
                                 Position.y=(Pervasives.max
                                              (Pervasives.(-.)
                                                y__val_rml_6 speed__val_rml_4)
                                              0.)}
                            | 6 ->
                                {Position.x=(Pervasives.max
                                              (Pervasives.(-.)
                                                x__val_rml_5 speed__val_rml_4)
                                              0.);
                                 Position.y=(y__val_rml_6)}
                            | 7 ->
                                {Position.x=(Pervasives.max
                                              (Pervasives.(-.)
                                                x__val_rml_5 speed__val_rml_4)
                                              0.);
                                 Position.y=(Pervasives.min
                                              (Pervasives.(+.)
                                                y__val_rml_6 speed__val_rml_4)
                                              (Pervasives.(-.)
                                                Global.max_y 1.))}
                            | _ -> pos__val_rml_2 )
                    )
              )
        ) 
;;


let no_move = (function | pos__val_rml_8 -> pos__val_rml_8 ) 
;;


let random =
      (function
        | pos__val_rml_10 ->
            translate pos__val_rml_10 (Random.int 8) Global.speed
        ) 
;;


let same_dir =
      (function
        | dir_init__val_rml_12 ->
            (let dir__val_rml_13 = Pervasives.ref dir_init__val_rml_12  in
              function
                | pos__val_rml_14 ->
                    (match Random.int 100 with
                     | p__val_rml_15 when Pervasives.(<) p__val_rml_15 80 ->
                         ()
                     | p__val_rml_16 when
                         Pervasives.(&)
                           (Pervasives.(<=) 80 p__val_rml_16)
                           (Pervasives.(<) p__val_rml_16 85) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 1)
                             8)
                     | p__val_rml_17 when
                         Pervasives.(&)
                           (Pervasives.(<=) 85 p__val_rml_17)
                           (Pervasives.(<) p__val_rml_17 90) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 7)
                             8)
                     | p__val_rml_18 when
                         Pervasives.(&)
                           (Pervasives.(<=) 90 p__val_rml_18)
                           (Pervasives.(<) p__val_rml_18 92) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 2)
                             8)
                     | p__val_rml_19 when
                         Pervasives.(&)
                           (Pervasives.(<=) 92 p__val_rml_19)
                           (Pervasives.(<) p__val_rml_19 94) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 6)
                             8)
                     | p__val_rml_20 when
                         Pervasives.(&)
                           (Pervasives.(<=) 94 p__val_rml_20)
                           (Pervasives.(<) p__val_rml_20 96) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 3)
                             8)
                     | p__val_rml_21 when
                         Pervasives.(&)
                           (Pervasives.(<=) 96 p__val_rml_21)
                           (Pervasives.(<) p__val_rml_21 98) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 5)
                             8)
                     | p__val_rml_22 when
                         Pervasives.(&)
                           (Pervasives.(<=) 98 p__val_rml_22)
                           (Pervasives.(<) p__val_rml_22 100) ->
                         Pervasives.(:=)
                           dir__val_rml_13
                           (Pervasives.(mod)
                             (Pervasives.(+)
                               (Pervasives.(!) dir__val_rml_13) 4)
                             8)
                     | _ -> () );
                      translate
                        pos__val_rml_14
                        (Pervasives.(!) dir__val_rml_13) Global.speed
                )
        ) 
;;


let random_pos =
      (function
        | r__val_rml_24 ->
            (function
              | pos__val_rml_25 ->
                  (let x__val_rml_26 =
                         Pervasives.(-.)
                           (Pervasives.(+.)
                             (pos__val_rml_25).Position.x
                             (Random.float
                               (Pervasives.( *. ) 2. r__val_rml_24)))
                           r__val_rml_24
                     in
                    let y__val_rml_27 =
                          Pervasives.(-.)
                            (Pervasives.(+.)
                              (pos__val_rml_25).Position.y
                              (Random.float
                                (Pervasives.( *. ) 2. r__val_rml_24)))
                            r__val_rml_24
                       in
                      {Position.x=(if Pervasives.(<) x__val_rml_26 0. then 
                                    0. else
                                    if
                                      Pervasives.(>=)
                                        x__val_rml_26 Global.max_x
                                      then Pervasives.(-.) Global.max_x 1.
                                      else x__val_rml_26);
                       Position.y=(if Pervasives.(<) y__val_rml_27 0. then 
                                    0. else
                                    if
                                      Pervasives.(>=)
                                        y__val_rml_27 Global.max_y
                                      then Pervasives.(-.) Global.max_y 1.
                                      else y__val_rml_27)})
              )
        ) 
;;


let local_rwp =
      (function
        | r__val_rml_29 ->
            (function
              | pos_init__val_rml_30 ->
                  (let waypoint__val_rml_31 =
                         Pervasives.ref pos_init__val_rml_30
                     in
                    function
                      | pos__val_rml_32 ->
                          (let dx__val_rml_33 =
                                 Pervasives.(-.)
                                   (Pervasives.(!) waypoint__val_rml_31).Position.x
                                   (pos__val_rml_32).Position.x
                             in
                            let dy__val_rml_34 =
                                  Pervasives.(-.)
                                    (Pervasives.(!) waypoint__val_rml_31).Position.y
                                    (pos__val_rml_32).Position.y
                               in
                              if
                                Pervasives.(&&)
                                  (Pervasives.(<)
                                    (Pervasives.abs_float dx__val_rml_33)
                                    Global.speed)
                                  (Pervasives.(<)
                                    (Pervasives.abs_float dy__val_rml_34)
                                    Global.speed)
                                then
                                Pervasives.(:=)
                                  waypoint__val_rml_31
                                  (random_pos r__val_rml_29 pos__val_rml_32)
                                else ();
                                (let distance__val_rml_35 =
                                       Pervasives.sqrt
                                         (Position.distance2
                                           pos__val_rml_32
                                           (Pervasives.(!)
                                             waypoint__val_rml_31))
                                   in
                                  let vx__val_rml_36 =
                                        Pervasives.(/.)
                                          (Pervasives.( *. )
                                            dx__val_rml_33 Global.speed)
                                          distance__val_rml_35
                                     in
                                    let vy__val_rml_37 =
                                          Pervasives.(/.)
                                            (Pervasives.( *. )
                                              dy__val_rml_34 Global.speed)
                                            distance__val_rml_35
                                       in
                                      {Position.x=(Pervasives.min
                                                    Global.max_x
                                                    (Pervasives.max
                                                      (Pervasives.(+.)
                                                        (pos__val_rml_32).Position.x
                                                        vx__val_rml_36)
                                                      0.));
                                       Position.y=(Pervasives.min
                                                    Global.max_y
                                                    (Pervasives.max
                                                      (Pervasives.(+.)
                                                        (pos__val_rml_32).Position.y
                                                        vy__val_rml_37)
                                                      0.))}))
                      )
              )
        ) 
;;


let rwp =
      (function
        | r__val_rml_39 ->
            (function
              | pos_init__val_rml_40 ->
                  (let waypoint__val_rml_41 =
                         Pervasives.ref pos_init__val_rml_40
                     in
                    let pause_cpt__val_rml_42 = Pervasives.ref 0  in
                      let speed__val_rml_43 = Pervasives.ref 1.  in
                        function
                          | pos__val_rml_44 ->
                              (let dx__val_rml_45 =
                                     Pervasives.(-.)
                                       (Pervasives.(!) waypoint__val_rml_41).Position.x
                                       (pos__val_rml_44).Position.x
                                 in
                                let dy__val_rml_46 =
                                      Pervasives.(-.)
                                        (Pervasives.(!) waypoint__val_rml_41).Position.y
                                        (pos__val_rml_44).Position.y
                                   in
                                  if
                                    Pervasives.(&&)
                                      (Pervasives.(<)
                                        (Pervasives.abs_float dx__val_rml_45)
                                        (Pervasives.(!) speed__val_rml_43))
                                      (Pervasives.(<)
                                        (Pervasives.abs_float dy__val_rml_46)
                                        (Pervasives.(!) speed__val_rml_43))
                                    then
                                    (match Pervasives.(!)
                                             pause_cpt__val_rml_42 with
                                     | x__val_rml_47 when
                                         Pervasives.(<) x__val_rml_47 0 ->
                                         Pervasives.(:=)
                                           pause_cpt__val_rml_42
                                           (Pervasives.(+)
                                             (Random.int
                                               (Pervasives.(-)
                                                 Global.pause_max
                                                 Global.pause_min))
                                             Global.pause_min);
                                           pos__val_rml_44
                                     | x__val_rml_48 when
                                         Pervasives.(>) x__val_rml_48 0 ->
                                         Pervasives.(:=)
                                           pause_cpt__val_rml_42
                                           (Pervasives.(-)
                                             (Pervasives.(!)
                                               pause_cpt__val_rml_42)
                                             1);
                                           pos__val_rml_44
                                     | _ ->
                                         Pervasives.(:=)
                                           pause_cpt__val_rml_42 (-1);
                                           Pervasives.(:=)
                                             speed__val_rml_43
                                             (Pervasives.(+.)
                                               (Random.float
                                                 (Pervasives.(-.)
                                                   Global.speed_max
                                                   Global.speed_min))
                                               Global.speed_min);
                                           Pervasives.(:=)
                                             waypoint__val_rml_41
                                             (random_pos
                                               r__val_rml_39 pos__val_rml_44);
                                           pos__val_rml_44
                                     )
                                    else
                                    (let distance__val_rml_49 =
                                           Pervasives.sqrt
                                             (Position.distance2
                                               pos__val_rml_44
                                               (Pervasives.(!)
                                                 waypoint__val_rml_41))
                                       in
                                      let vx__val_rml_50 =
                                            Pervasives.(/.)
                                              (Pervasives.( *. )
                                                dx__val_rml_45
                                                (Pervasives.(!)
                                                  speed__val_rml_43))
                                              distance__val_rml_49
                                         in
                                        let vy__val_rml_51 =
                                              Pervasives.(/.)
                                                (Pervasives.( *. )
                                                  dy__val_rml_46
                                                  (Pervasives.(!)
                                                    speed__val_rml_43))
                                                distance__val_rml_49
                                           in
                                          {Position.x=(Pervasives.min
                                                        Global.max_x
                                                        (Pervasives.max
                                                          (Pervasives.(+.)
                                                            (pos__val_rml_44).Position.x
                                                            vx__val_rml_50)
                                                          0.));
                                           Position.y=(Pervasives.min
                                                        Global.max_y
                                                        (Pervasives.max
                                                          (Pervasives.(+.)
                                                            (pos__val_rml_44).Position.y
                                                            vy__val_rml_51)
                                                          0.))}))
                          )
              )
        ) 
;;

