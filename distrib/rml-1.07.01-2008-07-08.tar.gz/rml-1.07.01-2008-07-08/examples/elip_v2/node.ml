(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc node.rml  *)

open Implem;;

open Position
;;


open Area
;;


open Global
;;


let update_pos_tbl =
      (function
        | self__val_rml_2 ->
            (function
              | neighbors__val_rml_3 ->
                  List.iter
                    (function
                      | node__val_rml_4 ->
                          Pos_tbl.set
                            (self__val_rml_2).Global.pos_tbl_le
                            (node__val_rml_4).Global.id
                            (node__val_rml_4).Global.pos
                            (self__val_rml_2).Global.date;
                            Pos_tbl.set
                              (self__val_rml_2).Global.pos_tbl_elip
                              (node__val_rml_4).Global.id
                              (node__val_rml_4).Global.pos
                              (self__val_rml_2).Global.date
                      )
                    neighbors__val_rml_3
              )
        ) 
;;


let get_neighbors =
      (let rec get_neighbors__val_rml_6 =
                 (function
                   | n1__val_rml_7 ->
                       (function
                         | others__val_rml_8 ->
                             (function
                               | acc__val_rml_9 ->
                                   (match others__val_rml_8 with
                                    | ([]) -> acc__val_rml_9
                                    | (n2__val_rml_10) :: (tl__val_rml_11) ->
                                        if
                                          Pervasives.(<)
                                            (Position.distance2
                                              (n1__val_rml_7).Global.pos
                                              (n2__val_rml_10).Global.pos)
                                            Global.coverage_range2
                                          then
                                          get_neighbors__val_rml_6
                                            n1__val_rml_7
                                            tl__val_rml_11
                                            (n2__val_rml_10 ::
                                              acc__val_rml_9)
                                          else
                                          get_neighbors__val_rml_6
                                            n1__val_rml_7
                                            tl__val_rml_11 acc__val_rml_9
                                    )
                               )
                         )
                   )
         in
        function
          | n1__val_rml_12 ->
              (function
                | others__val_rml_13 ->
                    get_neighbors__val_rml_6
                      n1__val_rml_12 others__val_rml_13 ([])
                )
          ) 
;;


let node =
      (function
        | id__val_rml_15 ->
            (function
              | pos_init__val_rml_16 ->
                  ((function
                     | () ->
                         Lco_ctrl_tree_record.rml_def
                           (function
                             | () ->
                                 Global.make_node
                                   id__val_rml_15 pos_init__val_rml_16
                             )
                           (function
                             | self__val_rml_17 ->
                                 Lco_ctrl_tree_record.rml_loop
                                   (Lco_ctrl_tree_record.rml_seq
                                     (Lco_ctrl_tree_record.rml_compute
                                       (function
                                         | () ->
                                             self__val_rml_17.Global.date <-
                                               Pervasives.(+)
                                                 (self__val_rml_17).Global.date
                                                 1;
                                               self__val_rml_17.Global.pos <-
                                                 (self__val_rml_17).Global.move
                                                   (self__val_rml_17).Global.pos;
                                               Lco_ctrl_tree_record.rml_expr_emit_val
                                                 Global.draw self__val_rml_17
                                         ))
                                     (Lco_ctrl_tree_record.rml_def
                                       (function
                                         | () ->
                                             Area.get_areas
                                               (self__val_rml_17).Global.pos.Position.x
                                               (self__val_rml_17).Global.pos.Position.y
                                         )
                                       (function
                                         | ((i__val_rml_18, j__val_rml_19) as
                                              local_area__val_rml_20,
                                            neighbor_areas__val_rml_21) ->
                                             Lco_ctrl_tree_record.rml_seq
                                               (Lco_ctrl_tree_record.rml_compute
                                                 (function
                                                   | () ->
                                                       List.iter
                                                         (function
                                                           | (i__val_rml_22,
                                                              j__val_rml_23) ->
                                                               Lco_ctrl_tree_record.rml_expr_emit_val
                                                                 (Array.get
                                                                   (Array.get
                                                                    Global.hello_array
                                                                    i__val_rml_22)
                                                                   j__val_rml_23)
                                                                 self__val_rml_17
                                                           )
                                                         (local_area__val_rml_20
                                                           ::
                                                           neighbor_areas__val_rml_21)
                                                   ))
                                               (Lco_ctrl_tree_record.rml_await_all
                                                 (function
                                                   | () ->
                                                       Array.get
                                                         (Array.get
                                                           Global.hello_array
                                                           i__val_rml_18)
                                                         j__val_rml_19
                                                   )
                                                 (function
                                                   | all__val_rml_24 ->
                                                       Lco_ctrl_tree_record.rml_seq
                                                         (Lco_ctrl_tree_record.rml_seq
                                                           (Lco_ctrl_tree_record.rml_seq
                                                             (Lco_ctrl_tree_record.rml_compute
                                                               (function
                                                                 | () ->
                                                                    self__val_rml_17.Global.neighbors
                                                                    <-
                                                                    get_neighbors
                                                                    self__val_rml_17
                                                                    all__val_rml_24;
                                                                    update_pos_tbl
                                                                    self__val_rml_17
                                                                    (self__val_rml_17).Global.neighbors
                                                                 ))
                                                             Lco_ctrl_tree_record.rml_pause)
                                                           (Lco_ctrl_tree_record.rml_compute
                                                             (function
                                                               | () ->
                                                                   List.iter
                                                                    (function
                                                                    | dest_id__val_rml_25 ->
                                                                    Routing.route
                                                                    Global.LE
                                                                    self__val_rml_17
                                                                    (Global.make_le_packet
                                                                    self__val_rml_17
                                                                    dest_id__val_rml_25);
                                                                    Routing.route
                                                                    Global.ELIP
                                                                    self__val_rml_17
                                                                    (Global.make_elip_packet
                                                                    self__val_rml_17
                                                                    dest_id__val_rml_25)
                                                                    )
                                                                    ((self__val_rml_17).Global.make_msg
                                                                    self__val_rml_17)
                                                               )))
                                                         Lco_ctrl_tree_record.rml_pause
                                                   ))
                                         )))
                             )
                     ):
                    (_) Lco_ctrl_tree_record.process)
              )
        ) 
;;

