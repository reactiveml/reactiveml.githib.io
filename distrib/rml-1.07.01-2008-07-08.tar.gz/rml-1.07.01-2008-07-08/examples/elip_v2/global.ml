(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc global.rml  *)

open Implem;;

open Position
;;


type  routage_kind
= LE |  ELIP ;;


type  id
= int ;;


type  node
     = {
        id: id ; 
       mutable pos: Position.position ; 
       mutable date: int ; 
        pos_tbl_le: Pos_tbl.t ; 
        pos_tbl_elip: Pos_tbl.t ; 
       mutable neighbors: (node) list ; 
        move: (Position.position -> Position.position) ; 
        insert_elip_info: (node -> (packet -> unit)) ; 
        make_msg: (node -> (id) list) ;  mutable visited: bool} and
        packet_header
       = H_LE |  H_ELIP of (elip_header) option and
          elip_header
         = {
            elip_id: id ; 
            elip_pos: Position.position ;  mutable elip_overhead: int} and 
           packet
           = {
             mutable header: packet_header ; 
              src_id: id ; 
              dest_id: id ; 
             mutable dest_pos: Position.position ; 
             mutable dest_pos_age: int ; 
             mutable route: (node) list ; 
             mutable anchors: ((node * (node) option * int * int)) list ; 
             mutable overhead: int}
         ;;


let (draw: (node, (node) list) Lco_ctrl_tree_record.event) =
      Lco_ctrl_tree_record.rml_global_signal_combine
        ([])
        (function
          | x__val_rml_2 ->
              (function | y__val_rml_3 -> x__val_rml_2 :: y__val_rml_3 )
          ) 
;;


let () = Init.configure () 
;;


let nb_instants = Pervasives.(!) Init.nb_instants 
;;


let pi = 3.14159265359 
;;


let max_x = Pervasives.(!) Init.max_x 
;;


let max_y = Pervasives.(!) Init.max_y 
;;


let area_size_x = Pervasives.(!) Init.area_size_x 
;;


let area_size_y = Pervasives.(!) Init.area_size_y 
;;


let nb_area_x =
      (let n__val_rml_11 = Pervasives.(/.) max_x area_size_x  in
        Pervasives.int_of_float (Pervasives.ceil n__val_rml_11)) 
;;


let nb_area_y =
      (let n__val_rml_13 = Pervasives.(/.) max_y area_size_y  in
        Pervasives.int_of_float (Pervasives.ceil n__val_rml_13)) 
;;


let hello_array =
      Array.make_matrix
        nb_area_x
        nb_area_y
        (Obj.magic (): (node, (node) list) Lco_ctrl_tree_record.event) 
;;


let nb_nodes = Pervasives.(!) Init.nb_nodes 
;;


let coverage_range = Pervasives.(!) Init.coverage_range 
;;


let coverage_range2 = Pervasives.( *. ) coverage_range coverage_range 
;;


let speed = Pervasives.(!) Init.speed 
;;


let speed_max = Pervasives.(!) Init.speed_max 
;;


let speed_min = Pervasives.(!) Init.speed_min 
;;


let pause_max = Pervasives.(!) Init.pause_max 
;;


let pause_min = Pervasives.(!) Init.pause_min 
;;


let main_node = Pervasives.ref 0 
;;


let search_overhead = Pervasives.(!) Init.search_overhead 
;;


let elip_proba = Pervasives.(!) Init.elip_proba 
;;


let elip_forecast = Pervasives.(!) Init.elip_forecast 
;;


let elip_min_insert_dist = Pervasives.(!) Init.elip_min_insert_dist 
;;


let elip_min_insert_dist2 =
      Pervasives.( *. )
        (Pervasives.( *. ) elip_min_insert_dist coverage_range)
        coverage_range 
;;


let elip_min_insert_angle =
      Pervasives.(/.)
        (Pervasives.( *. ) (Pervasives.(!) Init.elip_min_insert_angle) pi)
        180. 
;;


let msg_proba = Pervasives.(!) Init.msg_proba 
;;


let msg_len = Pervasives.(!) Init.msg_len 
;;


let with_graphics = Pervasives.(!) Init.with_graphics 
;;


let zoom = Pervasives.(!) Init.zoom 
;;


let with_stat = Pervasives.(!) Init.with_stat 
;;


let prefix =
      Pervasives.(^)
        (Pervasives.(!) Init.prefix)
        (Pervasives.(^)
          "-nb_node_"
          (Pervasives.(^)
            (Pervasives.string_of_int nb_nodes)
            (Pervasives.(^)
              "-maxx_"
              (Pervasives.(^)
                (Pervasives.string_of_float max_x)
                (Pervasives.(^)
                  "-dist_couv_"
                  (Pervasives.(^)
                    (Pervasives.string_of_float coverage_range)
                    (Pervasives.(^)
                      "-msg_proba_"
                      (Pervasives.(^)
                        (Pervasives.string_of_float msg_proba)
                        (Pervasives.(^)
                          "-msg_len_"
                          (Pervasives.(^)
                            (Pervasives.string_of_int msg_len)
                            (Pervasives.(^)
                              "-elip_proba_"
                              (Pervasives.(^)
                                (Pervasives.string_of_int
                                  (Pervasives.int_of_float elip_proba))
                                (Pervasives.(^)
                                  "-locality_val_"
                                  (Pervasives.(^)
                                    (Pervasives.string_of_float
                                      elip_min_insert_dist)
                                    (Pervasives.(^)
                                      "-angle_val_"
                                      (Pervasives.(^)
                                        (Pervasives.string_of_float
                                          elip_min_insert_angle)
                                        "_")))))))))))))))) 
;;


let get_new_id =
      (let cpt__val_rml_37 = Pervasives.ref (-1)  in
        function
          | () ->
              Pervasives.incr cpt__val_rml_37; Pervasives.(!) cpt__val_rml_37
          ) 
;;


let init_make_insert_elip_info =
      Pervasives.ref (function | _ -> (function | _ -> assert false ) ) 
;;


let init_make_move = Pervasives.ref (function | _ -> assert false ) 
;;


let init_make_make_msg = Pervasives.ref (function | _ -> assert false ) 
;;


let make_node =
      (function
        | id__val_rml_42 ->
            (function
              | pos__val_rml_43 ->
                  {id=(id__val_rml_42);
                   date=(0);
                   pos_tbl_le=(Pos_tbl.make nb_nodes);
                   pos_tbl_elip=(Pos_tbl.make nb_nodes);
                   neighbors=(([]));
                   pos=(pos__val_rml_43);
                   move=(Pervasives.(!) init_make_move pos__val_rml_43);
                   make_msg=(Pervasives.(!) init_make_make_msg ());
                   insert_elip_info=(Pervasives.(!)
                                       init_make_insert_elip_info
                                      pos__val_rml_43);
                   visited=(false)}
              )
        ) 
;;


let make_packet =
      (function
        | header__val_rml_45 ->
            (function
              | src_node__val_rml_46 ->
                  (function
                    | dest__val_rml_47 ->
                        (let (dest_pos__val_rml_48, dest_pos_date__val_rml_49)
                               =
                               (match header__val_rml_45 with
                                | H_LE ->
                                    Pos_tbl.get
                                      (src_node__val_rml_46).pos_tbl_le
                                      dest__val_rml_47
                                | H_ELIP (_) ->
                                    Pos_tbl.get
                                      (src_node__val_rml_46).pos_tbl_elip
                                      dest__val_rml_47
                                )
                           in
                          {header=(header__val_rml_45);
                           src_id=(src_node__val_rml_46).id;
                           dest_id=(dest__val_rml_47);
                           dest_pos=(dest_pos__val_rml_48);
                           dest_pos_age=(Pervasives.abs
                                          (Pervasives.(-)
                                            (src_node__val_rml_46).date
                                            dest_pos_date__val_rml_49));
                           route=(([])); anchors=(([])); overhead=(0)})
                    )
              )
        ) 
;;


let make_elip_header =
      (function
        | id__val_rml_51 ->
            (function
              | pos__val_rml_52 ->
                  {elip_id=(id__val_rml_51);
                   elip_pos=(pos__val_rml_52); elip_overhead=(0)}
              )
        ) 
;;


let make_le_packet = make_packet H_LE 
;;


let make_elip_packet =
      (function
        | src_node__val_rml_55 ->
            (function
              | dest__val_rml_56 ->
                  make_packet
                    (H_ELIP None) src_node__val_rml_55 dest__val_rml_56
              )
        ) 
;;

