(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc msg.rml  *)

open Implem;;

open Position
;;


open Global
;;


let angle =
      (function
        | p1__val_rml_2 ->
            (function
              | p2__val_rml_3 ->
                  (let alpha__val_rml_4 =
                         Pervasives.atan
                           (Pervasives.(/.)
                             (Pervasives.(-.)
                               (p2__val_rml_3).Position.y
                               (p1__val_rml_2).Position.y)
                             (Pervasives.(-.)
                               (p2__val_rml_3).Position.x
                               (p1__val_rml_2).Position.x))
                     in
                    if
                      Pervasives.(or)
                        (Pervasives.(&&)
                          (Pervasives.(>=) alpha__val_rml_4 0.)
                          (Pervasives.(<=)
                            (p2__val_rml_3).Position.y
                            (p1__val_rml_2).Position.y))
                        (Pervasives.(&&)
                          (Pervasives.(<=) alpha__val_rml_4 0.)
                          (Pervasives.(>=)
                            (p2__val_rml_3).Position.y
                            (p1__val_rml_2).Position.y))
                      then Pervasives.(+.) alpha__val_rml_4 Global.pi else
                      if
                        Pervasives.(&&)
                          (Pervasives.(<=) alpha__val_rml_4 0.)
                          (Pervasives.(&&)
                            (Pervasives.(<=)
                              (p2__val_rml_3).Position.y
                              (p1__val_rml_2).Position.y)
                            (Pervasives.(>=)
                              (p2__val_rml_3).Position.x
                              (p1__val_rml_2).Position.x))
                        then
                        Pervasives.(+.)
                          alpha__val_rml_4 (Pervasives.( *. ) 2. Global.pi)
                        else alpha__val_rml_4)
              )
        ) 
;;


let diff_angle =
      (function
        | angle1__val_rml_6 ->
            (function
              | angle2__val_rml_7 ->
                  (let diff__val_rml_8 =
                         Pervasives.abs_float
                           (Pervasives.(-.)
                             angle1__val_rml_6 angle2__val_rml_7)
                     in
                    if Pervasives.(>) diff__val_rml_8 Global.pi then
                      Pervasives.(-.)
                        (Pervasives.( *. ) 2. Global.pi) diff__val_rml_8
                      else diff__val_rml_8)
              )
        ) 
;;


let make_msg =
      (function
        | src__val_rml_10 ->
            if Pervasives.(<) (Random.float 100.) Global.msg_proba then
              (let msg__val_rml_11 = Pervasives.ref ([])  in
                let dest__val_rml_12 = Random.int Global.nb_nodes  in
                  let len__val_rml_13 =
                        Pervasives.(+) (Random.int Global.msg_len) 1
                     in
                    for i__val_ml_14 = 1 to len__val_rml_13 do
                      Pervasives.(:=)
                        msg__val_rml_11
                        (dest__val_rml_12 ::
                          (Pervasives.(!) msg__val_rml_11))
                      done; Pervasives.(!) msg__val_rml_11)
              else ([])
        ) 
;;


let criterion_proba =
      (function | () -> Pervasives.(<) (Random.float 100.) Global.elip_proba
        ) 
;;


let criterion_locality =
      (function
        | self__val_rml_17 ->
            (function
              | last_insert_pos__val_rml_18 ->
                  Pervasives.(>)
                    (Position.distance2
                      (self__val_rml_17).Global.pos
                      last_insert_pos__val_rml_18)
                    Global.elip_min_insert_dist2
              )
        ) 
;;


let criterion_angle =
      (function
        | last_insert_ang__val_rml_20 ->
            (function
              | current_angle__val_rml_21 ->
                  Pervasives.(>)
                    (diff_angle
                      last_insert_ang__val_rml_20 current_angle__val_rml_21)
                    Global.elip_min_insert_angle
              )
        ) 
;;


let insert_elip_info =
      (function
        | self__val_rml_23 ->
            (function
              | p__val_rml_24 ->
                  (function
                    | criterion__val_rml_25 ->
                        (match (p__val_rml_24).Global.header with
                         | Global.H_ELIP info__val_rml_26 ->
                             (match info__val_rml_26 with
                              | None ->
                                  if
                                    criterion__val_rml_25
                                      self__val_rml_23 p__val_rml_24
                                    then
                                    p__val_rml_24.Global.header <-
                                      Global.H_ELIP
                                        (Some
                                          (Global.make_elip_header
                                            (self__val_rml_23).Global.id
                                            (self__val_rml_23).Global.pos))
                                    else ()
                              | Some pos__val_rml_27 -> () )
                         | _ -> () )
                    )
              )
        ) 
;;


let insert_proba =
      (function
        | self__val_rml_29 ->
            (function
              | p__val_rml_30 ->
                  insert_elip_info
                    self__val_rml_29
                    p__val_rml_30
                    (function | _ -> (function | _ -> criterion_proba () ) )
              )
        ) 
;;


let insert_proba_locality =
      (function
        | pos_init__val_rml_32 ->
            (let last_insert_pos__val_rml_33 =
                   Pervasives.ref pos_init__val_rml_32
               in
              function
                | self__val_rml_34 ->
                    (function
                      | p__val_rml_35 ->
                          insert_elip_info
                            self__val_rml_34
                            p__val_rml_35
                            (function
                              | node__val_rml_36 ->
                                  (function
                                    | p__val_rml_37 ->
                                        if
                                          Pervasives.(or)
                                            (criterion_proba ())
                                            (criterion_locality
                                              node__val_rml_36
                                              (Pervasives.(!)
                                                last_insert_pos__val_rml_33))
                                          then
                                          (Pervasives.(:=)
                                             last_insert_pos__val_rml_33
                                             (node__val_rml_36).Global.pos;
                                            true)
                                          else false
                                    )
                              )
                      )
                )
        ) 
;;


let insert_locality =
      (function
        | pos_init__val_rml_39 ->
            (let last_insert_pos__val_rml_40 =
                   Pervasives.ref pos_init__val_rml_39
               in
              function
                | self__val_rml_41 ->
                    (function
                      | p__val_rml_42 ->
                          insert_elip_info
                            self__val_rml_41
                            p__val_rml_42
                            (function
                              | node__val_rml_43 ->
                                  (function
                                    | p__val_rml_44 ->
                                        if
                                          criterion_locality
                                            node__val_rml_43
                                            (Pervasives.(!)
                                              last_insert_pos__val_rml_40)
                                          then
                                          (Pervasives.(:=)
                                             last_insert_pos__val_rml_40
                                             (node__val_rml_43).Global.pos;
                                            true)
                                          else false
                                    )
                              )
                      )
                )
        ) 
;;


let insert_angle =
      (function
        | () ->
            (let last_insert_ang__val_rml_46 =
                   Pervasives.ref
                     (Random.float (Pervasives.( *. ) 2. Global.pi))
               in
              function
                | self__val_rml_47 ->
                    (function
                      | p__val_rml_48 ->
                          insert_elip_info
                            self__val_rml_47
                            p__val_rml_48
                            (function
                              | node__val_rml_49 ->
                                  (function
                                    | p__val_rml_50 ->
                                        (let current_angle__val_rml_51 =
                                               angle
                                                 (node__val_rml_49).Global.pos
                                                 (p__val_rml_50).Global.dest_pos
                                           in
                                          if
                                            criterion_angle
                                              (Pervasives.(!)
                                                last_insert_ang__val_rml_46)
                                              current_angle__val_rml_51
                                            then
                                            (Pervasives.(:=)
                                               last_insert_ang__val_rml_46
                                               current_angle__val_rml_51;
                                              true)
                                            else false)
                                    )
                              )
                      )
                )
        ) 
;;

