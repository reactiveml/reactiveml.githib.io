(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc position.rml  *)

open Implem;;

type  position
= {  x: float ;   y: float} ;;


let distance2 =
      (function
        | pos1__val_rml_2 ->
            (function
              | pos2__val_rml_3 ->
                  Pervasives.(+.)
                    (Pervasives.( *. )
                      (Pervasives.(-.)
                        (pos2__val_rml_3).x (pos1__val_rml_2).x)
                      (Pervasives.(-.)
                        (pos2__val_rml_3).x (pos1__val_rml_2).x))
                    (Pervasives.( *. )
                      (Pervasives.(-.)
                        (pos2__val_rml_3).y (pos1__val_rml_2).y)
                      (Pervasives.(-.)
                        (pos2__val_rml_3).y (pos1__val_rml_2).y))
              )
        ) 
;;


let print_pos =
      (function
        | pos__val_rml_5 ->
            Pervasives.print_string "(";
              Pervasives.print_float (pos__val_rml_5).x;
              Pervasives.print_string ", ";
              Pervasives.print_float (pos__val_rml_5).y;
              Pervasives.print_string ")"
        ) 
;;

