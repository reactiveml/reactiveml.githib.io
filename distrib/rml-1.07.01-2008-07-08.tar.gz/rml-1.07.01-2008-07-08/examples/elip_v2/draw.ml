(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc draw.rml  *)

open Implem;;

open Position
;;


open Global
;;


open Graphics
;;


let with_history = Pervasives.ref false 
;;


let history = Pervasives.ref ([]) 
;;


let draw_route =
      (function
        | p__val_rml_4 ->
            (let (c1__val_rml_5, c2__val_rml_6, c3__val_rml_7, dr__val_rml_8)
                   =
                   (match (p__val_rml_4).Global.header with
                    | Global.H_LE ->
                        (Graphics.red, Graphics.red, Graphics.magenta, 2)
                    | Global.H_ELIP (_) ->
                        (Graphics.blue, Graphics.blue, Graphics.cyan, 1)
                    )
               in
              (match (p__val_rml_4).Global.route with
               | (n__val_rml_9) :: (_) ->
                   Graphics.moveto
                     (Pervasives.int_of_float
                       (Pervasives.( *. )
                         (n__val_rml_9).Global.pos.Position.x Global.zoom))
                     (Pervasives.int_of_float
                       (Pervasives.( *. )
                         (n__val_rml_9).Global.pos.Position.y Global.zoom));
                     if
                       Pervasives.(=)
                         (n__val_rml_9).Global.id
                         (p__val_rml_4).Global.dest_id
                       then Graphics.set_color c1__val_rml_5 else
                       Graphics.set_color c3__val_rml_7
               | _ -> () );
                List.iter
                  (function
                    | n__val_rml_10 ->
                        Graphics.lineto
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_10).Global.pos.Position.x
                              Global.zoom))
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_10).Global.pos.Position.y
                              Global.zoom))
                    )
                  (p__val_rml_4).Global.route;
                List.iter
                  (function
                    | (src__val_rml_11, Some info__val_rml_12, _, _) ->
                        (let r__val_rml_13 =
                               Pervasives.sqrt
                                 (Position.distance2
                                   (src__val_rml_11).Global.pos
                                   (info__val_rml_12).Global.pos)
                           in
                          Graphics.set_color c2__val_rml_6;
                            Graphics.draw_circle
                              (Pervasives.int_of_float
                                (Pervasives.( *. )
                                  (src__val_rml_11).Global.pos.Position.x
                                  Global.zoom))
                              (Pervasives.int_of_float
                                (Pervasives.( *. )
                                  (src__val_rml_11).Global.pos.Position.y
                                  Global.zoom))
                              (Pervasives.(+)
                                (Pervasives.int_of_float
                                  (Pervasives.( *. )
                                    r__val_rml_13 Global.zoom))
                                dr__val_rml_8))
                    | (src__val_rml_14, None, level__val_rml_15, _) ->
                        (let r__val_rml_16 =
                               Pervasives.( * )
                                 level__val_rml_15
                                 (Pervasives.int_of_float
                                   (Pervasives.( *. )
                                     Global.coverage_range Global.zoom))
                           in
                          Graphics.set_color c3__val_rml_7;
                            Graphics.draw_circle
                              (Pervasives.int_of_float
                                (Pervasives.( *. )
                                  (src__val_rml_14).Global.pos.Position.x
                                  Global.zoom))
                              (Pervasives.int_of_float
                                (Pervasives.( *. )
                                  (src__val_rml_14).Global.pos.Position.y
                                  Global.zoom))
                              (Pervasives.(+) r__val_rml_16 dr__val_rml_8))
                    )
                  (p__val_rml_4).Global.anchors)
        ) 
;;


let draw_node =
      (function
        | kind__val_rml_18 ->
            (function
              | n__val_rml_19 ->
                  (let pos_tbl__val_rml_20 =
                         (match kind__val_rml_18 with
                          | Global.LE -> (n__val_rml_19).Global.pos_tbl_le
                          | Global.ELIP ->
                              (n__val_rml_19).Global.pos_tbl_elip
                          )
                     in
                    let (_, date__val_rml_21) =
                          Pos_tbl.get
                            pos_tbl__val_rml_20
                            (Pervasives.(!) Global.main_node)
                       in
                      if Pervasives.(=) date__val_rml_21 Pos_tbl.no_info then
                        Graphics.set_color Graphics.green else
                        if
                          Pervasives.(<)
                            (Pervasives.(-)
                              (n__val_rml_19).Global.date date__val_rml_21)
                            0
                          then Graphics.set_color Graphics.blue else
                          if
                            Pervasives.(<)
                              (Pervasives.(-)
                                (n__val_rml_19).Global.date date__val_rml_21)
                              50
                            then Graphics.set_color Graphics.red else
                            if
                              Pervasives.(<)
                                (Pervasives.(-)
                                  (n__val_rml_19).Global.date
                                  date__val_rml_21)
                                100
                              then Graphics.set_color Graphics.magenta else
                              if
                                Pervasives.(<)
                                  (Pervasives.(-)
                                    (n__val_rml_19).Global.date
                                    date__val_rml_21)
                                  150
                                then Graphics.set_color Graphics.cyan else
                                Graphics.set_color Graphics.black;
                        Graphics.moveto
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_19).Global.pos.Position.x
                              Global.zoom))
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_19).Global.pos.Position.y
                              Global.zoom));
                        Graphics.draw_string
                          (Pervasives.string_of_int
                            (n__val_rml_19).Global.id);
                        Graphics.set_color Graphics.black;
                        if
                          Pervasives.(=)
                            (n__val_rml_19).Global.id
                            (Pervasives.(!) Global.main_node)
                          then
                          (Graphics.draw_circle
                             (Pervasives.int_of_float
                               (Pervasives.( *. )
                                 (n__val_rml_19).Global.pos.Position.x
                                 Global.zoom))
                             (Pervasives.int_of_float
                               (Pervasives.( *. )
                                 (n__val_rml_19).Global.pos.Position.y
                                 Global.zoom))
                             (Pervasives.int_of_float
                               (Pervasives.( *. )
                                 Global.coverage_range Global.zoom));
                            if Pervasives.(!) with_history then
                              (Pervasives.(:=)
                                 history
                                 ((n__val_rml_19).Global.pos ::
                                   (Pervasives.(!) history));
                                 (match Pervasives.(!) history with
                                  | (pos__val_rml_22) :: (_) ->
                                      Graphics.moveto
                                        (Pervasives.int_of_float
                                          (Pervasives.( *. )
                                            (pos__val_rml_22).Position.x
                                            Global.zoom))
                                        (Pervasives.int_of_float
                                          (Pervasives.( *. )
                                            (pos__val_rml_22).Position.y
                                            Global.zoom))
                                  | _ -> () );
                                List.iter
                                  (function
                                    | pos__val_rml_23 ->
                                        Graphics.lineto
                                          (Pervasives.int_of_float
                                            (Pervasives.( *. )
                                              (pos__val_rml_23).Position.x
                                              Global.zoom))
                                          (Pervasives.int_of_float
                                            (Pervasives.( *. )
                                              (pos__val_rml_23).Position.y
                                              Global.zoom))
                                    )
                                  (Pervasives.(!) history))
                              else ())
                          else ())
              )
        ) 
;;


let draw_info_ascii =
      (function
        | kind__val_rml_25 ->
            (function
              | n__val_rml_26 ->
                  Graphics.set_color Graphics.black;
                    (let pos_tbl__val_rml_27 =
                           (match kind__val_rml_25 with
                            | Global.LE -> (n__val_rml_26).Global.pos_tbl_le
                            | Global.ELIP ->
                                (n__val_rml_26).Global.pos_tbl_elip
                            )
                       in
                      let (_, date__val_rml_28) =
                            Pos_tbl.get
                              pos_tbl__val_rml_27
                              (Pervasives.(!) Global.main_node)
                         in
                        Graphics.moveto
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_26).Global.pos.Position.x
                              Global.zoom))
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (n__val_rml_26).Global.pos.Position.y
                              Global.zoom));
                          if Pervasives.(=) date__val_rml_28 Pos_tbl.no_info
                            then Graphics.draw_string "." else
                            if
                              Pervasives.(<)
                                (Pervasives.(-)
                                  (n__val_rml_26).Global.date
                                  date__val_rml_28)
                                0
                              then Graphics.draw_string "#" else
                              if
                                Pervasives.(<)
                                  (Pervasives.(-)
                                    (n__val_rml_26).Global.date
                                    date__val_rml_28)
                                  50
                                then Graphics.draw_string "@" else
                                if
                                  Pervasives.(<)
                                    (Pervasives.(-)
                                      (n__val_rml_26).Global.date
                                      date__val_rml_28)
                                    100
                                  then Graphics.draw_string "*" else
                                  if
                                    Pervasives.(<)
                                      (Pervasives.(-)
                                        (n__val_rml_26).Global.date
                                        date__val_rml_28)
                                      150
                                    then Graphics.draw_string "+" else
                                    Graphics.draw_string "-";
                          if
                            Pervasives.(=)
                              (n__val_rml_26).Global.id
                              (Pervasives.(!) Global.main_node)
                            then
                            (Graphics.draw_circle
                               (Pervasives.int_of_float
                                 (Pervasives.( *. )
                                   (n__val_rml_26).Global.pos.Position.x
                                   Global.zoom))
                               (Pervasives.int_of_float
                                 (Pervasives.( *. )
                                   (n__val_rml_26).Global.pos.Position.y
                                   Global.zoom))
                               (Pervasives.int_of_float
                                 (Pervasives.( *. )
                                   Global.coverage_range Global.zoom));
                              if Pervasives.(!) with_history then
                                (Pervasives.(:=)
                                   history
                                   ((n__val_rml_26).Global.pos ::
                                     (Pervasives.(!) history));
                                   (match Pervasives.(!) history with
                                    | (pos__val_rml_29) :: (_) ->
                                        Graphics.moveto
                                          (Pervasives.int_of_float
                                            (Pervasives.( *. )
                                              (pos__val_rml_29).Position.x
                                              Global.zoom))
                                          (Pervasives.int_of_float
                                            (Pervasives.( *. )
                                              (pos__val_rml_29).Position.y
                                              Global.zoom))
                                    | _ -> () );
                                  List.iter
                                    (function
                                      | pos__val_rml_30 ->
                                          Graphics.lineto
                                            (Pervasives.int_of_float
                                              (Pervasives.( *. )
                                                (pos__val_rml_30).Position.x
                                                Global.zoom))
                                            (Pervasives.int_of_float
                                              (Pervasives.( *. )
                                                (pos__val_rml_30).Position.y
                                                Global.zoom))
                                      )
                                    (Pervasives.(!) history))
                                else ())
                            else ())
              )
        ) 
;;


let draw_neighborhood =
      (function
        | self__val_rml_32 ->
            Graphics.set_color Graphics.green;
              List.iter
                (function
                  | info__val_rml_33 ->
                      Graphics.moveto
                        (Pervasives.int_of_float
                          (Pervasives.( *. )
                            (self__val_rml_32).Global.pos.Position.x
                            Global.zoom))
                        (Pervasives.int_of_float
                          (Pervasives.( *. )
                            (self__val_rml_32).Global.pos.Position.y
                            Global.zoom));
                        Graphics.lineto
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (info__val_rml_33).Global.pos.Position.x
                              Global.zoom))
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              (info__val_rml_33).Global.pos.Position.y
                              Global.zoom))
                  )
                (self__val_rml_32).Global.neighbors;
              Graphics.set_color Graphics.black
        ) 
;;


let draw_areas =
      (function
        | () ->
            (let x__val_rml_35 = Pervasives.ref 0  in
              let y__val_rml_36 = Pervasives.ref 0  in
                Graphics.set_color Graphics.black;
                  while
                    Pervasives.(<)
                      (Pervasives.(!) x__val_rml_35)
                      (Pervasives.int_of_float
                        (Pervasives.( *. ) Global.max_x Global.zoom))
                    do
                    (Graphics.moveto (Pervasives.(!) x__val_rml_35) 0;
                       Graphics.lineto
                         (Pervasives.(!) x__val_rml_35)
                         (Pervasives.int_of_float
                           (Pervasives.( *. ) Global.max_y Global.zoom));
                      Pervasives.(:=)
                        x__val_rml_35
                        (Pervasives.(+)
                          (Pervasives.(!) x__val_rml_35)
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              Global.area_size_x Global.zoom))))
                    done;
                  while
                    Pervasives.(<)
                      (Pervasives.(!) y__val_rml_36)
                      (Pervasives.int_of_float
                        (Pervasives.( *. ) Global.max_y Global.zoom))
                    do
                    (Graphics.moveto 0 (Pervasives.(!) y__val_rml_36);
                       Graphics.lineto
                         (Pervasives.int_of_float
                           (Pervasives.( *. ) Global.max_x Global.zoom))
                         (Pervasives.(!) y__val_rml_36);
                      Pervasives.(:=)
                        y__val_rml_36
                        (Pervasives.(+)
                          (Pervasives.(!) y__val_rml_36)
                          (Pervasives.int_of_float
                            (Pervasives.( *. )
                              Global.area_size_y Global.zoom))))
                    done)
        ) 
;;


let search_closer =
      (function
        | (x__val_rml_38, y__val_rml_39) ->
            (function
              | all__val_rml_40 ->
                  (let pos__val_rml_41 =
                         {Position.x=(x__val_rml_38);
                          Position.y=(y__val_rml_39)}
                     in
                    let (d2_min__val_rml_42, best_info__val_rml_43) =
                          List.fold_left
                            (function
                              | (d2min__val_rml_44, info_min__val_rml_45) ->
                                  (function
                                    | info__val_rml_46 ->
                                        (let d2__val_rml_47 =
                                               Position.distance2
                                                 (info__val_rml_46).Global.pos
                                                 pos__val_rml_41
                                           in
                                          if
                                            Pervasives.(<)
                                              d2__val_rml_47
                                              d2min__val_rml_44
                                            then
                                            (d2__val_rml_47,
                                             (Some info__val_rml_46))
                                            else
                                            (d2min__val_rml_44,
                                             info_min__val_rml_45))
                                    )
                              )
                            (Pervasives.max_float, None) all__val_rml_40
                       in
                      match best_info__val_rml_43 with
                      | None -> Pervasives.(!) Global.main_node
                      | Some info__val_rml_48 -> (info__val_rml_48).Global.id )
              )
        ) 
;;


let draw_simul =
      (function
        | draw__val_rml_50 ->
            (function
              | suspend__val_rml_51 ->
                  (function
                    | new_node__val_rml_52 ->
                        (function
                          | kill__val_rml_53 ->
                              ((function
                                 | () ->
                                     Lco_ctrl_tree_record.rml_seq
                                       (Lco_ctrl_tree_record.rml_compute
                                         (function
                                           | () ->
                                               Graphics.open_graph
                                                 (Pervasives.(^)
                                                   " "
                                                   (Pervasives.(^)
                                                     (Pervasives.string_of_int
                                                       (Pervasives.int_of_float
                                                         (Pervasives.( *. )
                                                           Global.max_x
                                                           Global.zoom)))
                                                     (Pervasives.(^)
                                                       "x"
                                                       (Pervasives.string_of_int
                                                         (Pervasives.int_of_float
                                                           (Pervasives.( *. )
                                                             Global.max_y
                                                             Global.zoom))))));
                                                 Graphics.set_window_title
                                                   (Pervasives.(^)
                                                     "Simulation of "
                                                     (Pervasives.(^)
                                                       (Pervasives.string_of_int
                                                         Global.nb_nodes)
                                                       " nodes"));
                                                 Graphics.auto_synchronize
                                                   false
                                           ))
                                       (Lco_ctrl_tree_record.rml_def
                                         (function
                                           | () -> Pervasives.ref false )
                                         (function
                                           | with_neighborhood__val_rml_54 ->
                                               Lco_ctrl_tree_record.rml_def
                                                 (function
                                                   | () ->
                                                       Pervasives.ref false
                                                   )
                                                 (function
                                                   | with_areas__val_rml_55 ->
                                                       Lco_ctrl_tree_record.rml_def
                                                         (function
                                                           | () ->
                                                               Pervasives.ref
                                                                 Global.ELIP
                                                           )
                                                         (function
                                                           | routage__val_rml_56 ->
                                                               Lco_ctrl_tree_record.rml_def
                                                                 (function
                                                                   | 
                                                                   () ->
                                                                    Pervasives.ref
                                                                    ([])
                                                                   )
                                                                 (function
                                                                   | 
                                                                   all_infos__val_rml_57 ->
                                                                    Lco_ctrl_tree_record.rml_signal
                                                                    (function
                                                                    | refresh__sig_58 ->
                                                                    Lco_ctrl_tree_record.rml_signal
                                                                    (function
                                                                    | key__sig_59 ->
                                                                    Lco_ctrl_tree_record.rml_signal
                                                                    (function
                                                                    | click__sig_60 ->
                                                                    Lco_ctrl_tree_record.rml_par_n
                                                                    ((Lco_ctrl_tree_record.rml_control'
                                                                    suspend__val_rml_51
                                                                    (Lco_ctrl_tree_record.rml_loop
                                                                    (Lco_ctrl_tree_record.rml_await_all
                                                                    (function
                                                                    | () ->
                                                                    draw__val_rml_50
                                                                    )
                                                                    (function
                                                                    | all__val_rml_67 ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(:=)
                                                                    all_infos__val_rml_57
                                                                    all__val_rml_67;
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    ) )))) ::
                                                                    ((Lco_ctrl_tree_record.rml_loop
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_seq
                                                                    Lco_ctrl_tree_record.rml_pause
                                                                    (Lco_ctrl_tree_record.rml_await_immediate'
                                                                    refresh__sig_58))
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Graphics.clear_graph
                                                                    ();
                                                                    List.iter
                                                                    (draw_node
                                                                    (Pervasives.(!)
                                                                    routage__val_rml_56))
                                                                    (Pervasives.(!)
                                                                    all_infos__val_rml_57);
                                                                    if
                                                                    Pervasives.(!)
                                                                    with_neighborhood__val_rml_54
                                                                    then
                                                                    List.iter
                                                                    draw_neighborhood
                                                                    (Pervasives.(!)
                                                                    all_infos__val_rml_57)
                                                                    else 
                                                                    ();
                                                                    if
                                                                    Pervasives.(!)
                                                                    with_areas__val_rml_55
                                                                    then
                                                                    draw_areas
                                                                    () else
                                                                    ();
                                                                    Graphics.synchronize
                                                                    () )))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Graphics.synchronize
                                                                    () )))
                                                                    Lco_ctrl_tree_record.rml_pause)
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Graphics.synchronize
                                                                    () ))))
                                                                    ::
                                                                    ((Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.print_string
                                                                    "Press";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\th: to display main node's path";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tn: to display the neighborhood";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tm: to change main node";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tp: to suspend the simulation";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tr: to change protocol location distribution";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\ta: to create a new node";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tk: to kill a node";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tg: to display areas";
                                                                    Pervasives.print_newline
                                                                    ();
                                                                    Pervasives.print_string
                                                                    "\tq: to quit";
                                                                    Pervasives.print_newline
                                                                    () ))
                                                                    (Lco_ctrl_tree_record.rml_loop
                                                                    (Lco_ctrl_tree_record.rml_await_immediate_one
                                                                    (function
                                                                    | () ->
                                                                    key__sig_59
                                                                    )
                                                                    (function
                                                                    | c__val_rml_61 ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_match
                                                                    (function
                                                                    | () ->
                                                                    c__val_rml_61
                                                                    )
                                                                    (function
                                                                    | 'N'|'n' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(:=)
                                                                    with_neighborhood__val_rml_54
                                                                    (Pervasives.not
                                                                    (Pervasives.(!)
                                                                    with_neighborhood__val_rml_54));
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    )
                                                                    | 'P'|'p' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    suspend__val_rml_51
                                                                    )
                                                                    | 'M'|'m' ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.print_string
                                                                    "click on a node";
                                                                    Pervasives.print_newline
                                                                    () ))
                                                                    (Lco_ctrl_tree_record.rml_await_immediate_one
                                                                    (function
                                                                    | () ->
                                                                    click__sig_60
                                                                    )
                                                                    (function
                                                                    | p__val_rml_62 ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(:=)
                                                                    Global.main_node
                                                                    (search_closer
                                                                    p__val_rml_62
                                                                    (Pervasives.(!)
                                                                    all_infos__val_rml_57));
                                                                    Pervasives.(:=)
                                                                    history
                                                                    ([]);
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    ) ))
                                                                    | 'R'|'r' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    (match 
                                                                    Pervasives.(!)
                                                                    routage__val_rml_56 with
                                                                    | 
                                                                    Global.LE ->
                                                                    Pervasives.(:=)
                                                                    routage__val_rml_56
                                                                    Global.ELIP
                                                                    | 
                                                                    Global.ELIP ->
                                                                    Pervasives.(:=)
                                                                    routage__val_rml_56
                                                                    Global.LE
                                                                    );
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    )
                                                                    | 'H'|'h' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(:=)
                                                                    with_history
                                                                    (Pervasives.not
                                                                    (Pervasives.(!)
                                                                    with_history));
                                                                    Pervasives.(:=)
                                                                    history
                                                                    ([]);
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    )
                                                                    | 'A'|'a' ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.print_string
                                                                    "click to create a new node";
                                                                    Pervasives.print_newline
                                                                    () ))
                                                                    (Lco_ctrl_tree_record.rml_await_immediate_one
                                                                    (function
                                                                    | () ->
                                                                    click__sig_60
                                                                    )
                                                                    (function
                                                                    | (x__val_rml_63,
                                                                    y__val_rml_64) ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Lco_ctrl_tree_record.rml_expr_emit_val
                                                                    new_node__val_rml_52
                                                                    {Position.x=
                                                                    (x__val_rml_63);
                                                                    Position.y=
                                                                    (y__val_rml_64)};
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    ) ))
                                                                    | 'K'|'k' ->
                                                                    Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.print_string
                                                                    "click on a node";
                                                                    Pervasives.print_newline
                                                                    () ))
                                                                    (Lco_ctrl_tree_record.rml_await_immediate_one
                                                                    (function
                                                                    | () ->
                                                                    click__sig_60
                                                                    )
                                                                    (function
                                                                    | p__val_rml_65 ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    (let 
                                                                    node__val_rml_66
                                                                    =
                                                                    search_closer
                                                                    p__val_rml_65
                                                                    (Pervasives.(!)
                                                                    all_infos__val_rml_57)
                                                                     in
                                                                    Lco_ctrl_tree_record.rml_expr_emit_val
                                                                    kill__val_rml_53
                                                                    node__val_rml_66;
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58)
                                                                    ) ))
                                                                    | 'G'|'g' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.(:=)
                                                                    with_areas__val_rml_55
                                                                    (Pervasives.not
                                                                    (Pervasives.(!)
                                                                    with_areas__val_rml_55));
                                                                    Lco_ctrl_tree_record.rml_expr_emit
                                                                    refresh__sig_58
                                                                    )
                                                                    | 'Q'|'q' ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    Pervasives.exit
                                                                    0 )
                                                                    | _ ->
                                                                    Lco_ctrl_tree_record.rml_compute
                                                                    (function
                                                                    | () ->
                                                                    () ) ))
                                                                    Lco_ctrl_tree_record.rml_pause
                                                                    )))) ::
                                                                    ((Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_run
                                                                    (function
                                                                    | () ->
                                                                    Rml_graphics.read_key
                                                                    key__sig_59
                                                                    ))
                                                                    Lco_ctrl_tree_record.rml_nothing)
                                                                    ::
                                                                    ((Lco_ctrl_tree_record.rml_seq
                                                                    (Lco_ctrl_tree_record.rml_run
                                                                    (function
                                                                    | () ->
                                                                    Rml_graphics.read_click
                                                                    click__sig_60
                                                                    ))
                                                                    Lco_ctrl_tree_record.rml_nothing)
                                                                    :: 
                                                                    ([]))))))
                                                                    ) ) )
                                                                   )
                                                           )
                                                   )
                                           ))
                                 ):
                                (_) Lco_ctrl_tree_record.process)
                          )
                    )
              )
        ) 
;;

