(* THIS FILE IS GENERATED. *)
(* /Users/louis/ReactiveML/rml/local/bin/rmlc routing.rml  *)

open Implem;;

open Position
;;


open Global
;;


let routing_success =
      (function
        | p__val_rml_2 ->
            if
              Pervasives.(&&)
                Global.with_graphics
                (Pervasives.(=)
                  (p__val_rml_2).Global.src_id
                  (Pervasives.(!) Global.main_node))
              then Draw.draw_route p__val_rml_2 else ();
              Stat.packet_success_stat p__val_rml_2
        ) 
;;


let routing_fail =
      (function
        | p__val_rml_4 ->
            if
              Pervasives.(&&)
                Global.with_graphics
                (Pervasives.(=)
                  (p__val_rml_4).Global.src_id
                  (Pervasives.(!) Global.main_node))
              then Draw.draw_route p__val_rml_4 else ();
              Stat.packet_fail_stat p__val_rml_4
        ) 
;;


let forward =
      (function
        | self__val_rml_6 ->
            (function
              | p__val_rml_7 ->
                  (let d__val_rml_8 =
                         Position.distance2
                           (self__val_rml_6).Global.pos
                           (p__val_rml_7).Global.dest_pos
                     in
                    let (d_min__val_rml_9, best_node__val_rml_10) =
                          List.fold_left
                            (function
                              | (d_min__val_rml_11, current_best__val_rml_12) ->
                                  (function
                                    | node__val_rml_13 ->
                                        if
                                          Pervasives.(=)
                                            (node__val_rml_13).Global.id
                                            (p__val_rml_7).Global.dest_id
                                          then ((-1.), node__val_rml_13) else
                                          (let d__val_rml_14 =
                                                 Position.distance2
                                                   (node__val_rml_13).Global.pos
                                                   (p__val_rml_7).Global.dest_pos
                                             in
                                            if
                                              Pervasives.(<)
                                                d__val_rml_14
                                                d_min__val_rml_11
                                              then
                                              (d__val_rml_14,
                                               node__val_rml_13)
                                              else
                                              (d_min__val_rml_11,
                                               current_best__val_rml_12))
                                    )
                              )
                            (d__val_rml_8, self__val_rml_6)
                            (self__val_rml_6).Global.neighbors
                       in
                      if
                        Pervasives.(=)
                          (self__val_rml_6).Global.id
                          (best_node__val_rml_10).Global.id
                        then None else Some best_node__val_rml_10)
              )
        ) 
;;


let search_best_age = Search_best_age.search_best_age 
;;


let anchor =
      (function
        | kind__val_rml_17 ->
            (function
              | self__val_rml_18 ->
                  (function
                    | p__val_rml_19 ->
                        (let pos_tbl__val_rml_20 =
                               (match kind__val_rml_17 with
                                | Global.LE ->
                                    (self__val_rml_18).Global.pos_tbl_le
                                | Global.ELIP ->
                                    (self__val_rml_18).Global.pos_tbl_elip
                                )
                           in
                          let (pos_dest__val_rml_21, date__val_rml_22) =
                                Pos_tbl.get
                                  pos_tbl__val_rml_20
                                  (p__val_rml_19).Global.dest_id
                             in
                            if
                              Pervasives.(<)
                                (Pervasives.abs
                                  (Pervasives.(-)
                                    (self__val_rml_18).Global.date
                                    date__val_rml_22))
                                (Pervasives.(/)
                                  (p__val_rml_19).Global.dest_pos_age 2)
                              then
                              (p__val_rml_19.Global.anchors <-
                                 (self__val_rml_18,
                                  (Some self__val_rml_18), 0, 0) ::
                                   (p__val_rml_19).Global.anchors;
                                Some
                                  (pos_dest__val_rml_21,
                                   (Pervasives.abs
                                     (Pervasives.(-)
                                       (self__val_rml_18).Global.date
                                       date__val_rml_22))))
                              else
                              (match search_best_age
                                       kind__val_rml_17
                                       self__val_rml_18
                                       (p__val_rml_19).Global.dest_id
                                       (Pervasives.(/)
                                         (p__val_rml_19).Global.dest_pos_age
                                         2)
                                       (self__val_rml_18).Global.neighbors with
                               | (Some
                                    (node__val_rml_23,
                                     (pos__val_rml_24, age__val_rml_25)),
                                  level__val_rml_26,
                                  nb_nodes__val_rml_27, overhead__val_rml_28) ->
                                   p__val_rml_19.Global.anchors <-
                                     (self__val_rml_18,
                                      (Some node__val_rml_23),
                                      level__val_rml_26, nb_nodes__val_rml_27)
                                       :: (p__val_rml_19).Global.anchors;
                                     p__val_rml_19.Global.overhead <-
                                       Pervasives.(+)
                                         (p__val_rml_19).Global.overhead
                                         overhead__val_rml_28;
                                     Pos_tbl.set
                                       pos_tbl__val_rml_20
                                       (p__val_rml_19).Global.dest_id
                                       pos__val_rml_24
                                       (Pervasives.(-)
                                         (self__val_rml_18).Global.date
                                         age__val_rml_25);
                                     Some (pos__val_rml_24, age__val_rml_25)
                               | (None,
                                  level__val_rml_29,
                                  nb_nodes__val_rml_30, overhead__val_rml_31) ->
                                   p__val_rml_19.Global.anchors <-
                                     (self__val_rml_18,
                                      None,
                                      level__val_rml_29, nb_nodes__val_rml_30)
                                       :: (p__val_rml_19).Global.anchors;
                                     p__val_rml_19.Global.overhead <-
                                       Pervasives.(+)
                                         (p__val_rml_19).Global.overhead
                                         overhead__val_rml_31;
                                     None
                               ))
                    )
              )
        ) 
;;


let pos_tbl_update =
      (function
        | kind__val_rml_33 ->
            (function
              | self__val_rml_34 ->
                  (function
                    | p__val_rml_35 ->
                        (let pos_tbl__val_rml_36 =
                               (match kind__val_rml_33 with
                                | Global.LE ->
                                    (self__val_rml_34).Global.pos_tbl_le
                                | Global.ELIP ->
                                    (self__val_rml_34).Global.pos_tbl_elip
                                )
                           in
                          (match (p__val_rml_35).Global.header with
                           | Global.H_ELIP Some info__val_rml_37 ->
                               info__val_rml_37.Global.elip_overhead <-
                                 Pervasives.(+)
                                   (info__val_rml_37).Global.elip_overhead 1;
                                 Pos_tbl.update
                                   pos_tbl__val_rml_36
                                   (info__val_rml_37).Global.elip_id
                                   (info__val_rml_37).Global.elip_pos
                                   (self__val_rml_34).Global.date
                           | _ -> () );
                            Pos_tbl.update
                              pos_tbl__val_rml_36
                              (p__val_rml_35).Global.dest_id
                              (p__val_rml_35).Global.dest_pos
                              (Pervasives.(-)
                                (self__val_rml_34).Global.date
                                (p__val_rml_35).Global.dest_pos_age))
                    )
              )
        ) 
;;


let rec routing =
          (function
            | kind__val_rml_39 ->
                (function
                  | self__val_rml_40 ->
                      (function
                        | p__val_rml_41 ->
                            p__val_rml_41.Global.route <-
                              self__val_rml_40 ::
                                (p__val_rml_41).Global.route;
                              pos_tbl_update
                                kind__val_rml_39
                                self__val_rml_40 p__val_rml_41;
                              if
                                Pervasives.(=)
                                  (self__val_rml_40).Global.id
                                  (p__val_rml_41).Global.dest_id
                                then routing_success p__val_rml_41 else
                                ((self__val_rml_40).Global.insert_elip_info
                                   self__val_rml_40 p__val_rml_41;
                                  (match forward
                                           self__val_rml_40 p__val_rml_41 with
                                   | Some next_node__val_rml_42 ->
                                       routing
                                         kind__val_rml_39
                                         next_node__val_rml_42 p__val_rml_41
                                   | None ->
                                       if
                                         Pervasives.(=)
                                           (p__val_rml_41).Global.dest_pos_age
                                           0
                                         then routing_fail p__val_rml_41 else
                                         (match anchor
                                                  kind__val_rml_39
                                                  self__val_rml_40
                                                  p__val_rml_41 with
                                          | None ->
                                              routing_fail p__val_rml_41
                                          | Some
                                              (pos__val_rml_43,
                                               age__val_rml_44) ->
                                              p__val_rml_41.Global.dest_pos
                                                <- pos__val_rml_43;
                                                p__val_rml_41.Global.dest_pos_age
                                                  <- age__val_rml_44;
                                                routing
                                                  kind__val_rml_39
                                                  self__val_rml_40
                                                  p__val_rml_41
                                          )
                                   ))
                        )
                  )
            ) 
;;


let route =
      (function
        | kind__val_rml_46 ->
            (function
              | src_node__val_rml_47 ->
                  (function
                    | packet__val_rml_48 ->
                        (let pos_tbl__val_rml_49 =
                               (match kind__val_rml_46 with
                                | Global.LE ->
                                    (src_node__val_rml_47).Global.pos_tbl_le
                                | Global.ELIP ->
                                    (src_node__val_rml_47).Global.pos_tbl_elip
                                )
                           in
                          let (_, pos_dest_date__val_rml_50) =
                                Pos_tbl.get
                                  pos_tbl__val_rml_49
                                  (packet__val_rml_48).Global.dest_id
                             in
                            if
                              Pervasives.(<>)
                                pos_dest_date__val_rml_50 Pos_tbl.no_info
                              then
                              routing
                                kind__val_rml_46
                                src_node__val_rml_47 packet__val_rml_48
                              else
                              if
                                Pervasives.(=)
                                  (packet__val_rml_48).Global.dest_pos_age 0
                                then routing_fail packet__val_rml_48 else
                                (match anchor
                                         kind__val_rml_46
                                         src_node__val_rml_47
                                         packet__val_rml_48 with
                                 | None -> routing_fail packet__val_rml_48
                                 | Some (pos__val_rml_51, age__val_rml_52) ->
                                     packet__val_rml_48.Global.dest_pos <-
                                       pos__val_rml_51;
                                       packet__val_rml_48.Global.dest_pos_age
                                         <- age__val_rml_52;
                                       routing
                                         kind__val_rml_46
                                         src_node__val_rml_47
                                         packet__val_rml_48
                                 ))
                    )
              )
        ) 
;;

