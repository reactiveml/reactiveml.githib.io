open Bmp;;
open Graphic_image;;


type t = Image.t;;

type load_option = Image.load_option;;

let misc_load = Bmp.load;;

let misc_draw_image = Graphic_image.draw_image;;


