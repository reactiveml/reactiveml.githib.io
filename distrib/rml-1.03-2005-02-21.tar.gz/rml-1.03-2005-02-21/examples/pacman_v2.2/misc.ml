open Bmp;;
open Graphic_image;;


type t = Images.t;;

type load_option = Images.load_option;;

let misc_load = Bmp.load;;

let misc_draw_image = Graphic_image.draw_image;;


