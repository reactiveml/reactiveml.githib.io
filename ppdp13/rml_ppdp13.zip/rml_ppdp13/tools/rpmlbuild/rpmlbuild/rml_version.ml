open Command

let rmlc = A"/Users/ccpasteur/Documents/work/these/dev/rml_icfp13/compiler/rpmlc.byte";;
let rmldep = A "/Users/ccpasteur/Documents/work/these/dev/rml_icfp13/tools/rpmldep/rpmldep.byte";;

let rpmllib_dir = "/Users/ccpasteur/Documents/work/these/dev/rml_icfp13/interpreter/_build"
let mlmpilib_dir = "@mlmpi_libdir@"

let mpicc = "@MPICC@"
