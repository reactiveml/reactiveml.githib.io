

let impl p =
  p
