**** Contents *************

- compiler/:  the ReactiveML compiler
- lib/: the standard library
- interpreter/ : the ReactiveML runtime
- tools/rpmldep/: the equivalent of ocamldep
- tools/rpmlbuild/: the equivalent of ocamlbuild
- examples/: Several examples from the article

**** Installing *************

Requirements: OCaml >= 3.12 (including the Graphics module for the nbody example), ocamlfind

- Run './configure --enable-local-stdlib'
The option configures the compiler to use the standard library directly from the source tree.
It is not necessary to install the compiler.

- Run 'make'
This will build the compiler, the runtime and the different tools. It will also build the examples.

**** Examples ***********

- Go in the examples/nbody or examples/server directory
   and run one of the .rml.byte file.

- Description:
        - examples/nbody/planets.rml.byte: n-body simulation using Euler semi-implicit method
        - examples/nbody/planets_heun.rml.byte: n-body simulation using Heun method
        - examples/nbody/planets_switch.rml.byte: n-body simulation with dynamic switch of
        methods. The currently used method is printed in the bottom-left corner of the window.
        To change the integration method, press one of the following keys:
             * 'e' for Euler
             * 's' for Euler semi-implicit
             * 'h' for Heun
             * 'r' for Runge-Kutta 4th order

        - examples/radio/radio.rml.byte: The sensor network example from the paper. By default, it
        uses the model with refined power consumption. It is possible to use the approximate model
        by giving the '-no-power' option on the command line.

        - examples/server/server.rml.byte: A small example of client/server
        - examples/server/twoservers.rml.byte: The same example with two servers accessing the same
        resource. It illustrates the fact that reactive domains can be used to hide local steps
        introduced by local communications.

        - examples/paper: this directory contains the code of the examples from the paper

